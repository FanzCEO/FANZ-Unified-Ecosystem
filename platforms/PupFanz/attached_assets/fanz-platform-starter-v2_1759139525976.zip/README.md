# FUN Platform (GirlFanz, PupFanz, DaddyFanz) — Starter Monorepo

This is a scaffold for a multi-tenant creator network: shared core + brand tenants.
Includes:
- API Gateway with OpenAPI (REST)
- gRPC protos for internal microservices
- SQL schema for Postgres
- Local dev via Docker Compose
- Terraform stubs for AWS (VPC, RDS, S3, KMS, NATS/Kafka, WAF, CloudFront)
- Event contracts (JSON Schemas)

> ⚠️ This is a skeleton for engineering teams to extend. Replace placeholders and wire services as needed.

**Tenants:** girlfanz, pupfanz, daddyfanz, boyfanz, cougarfanz, taboofanz
