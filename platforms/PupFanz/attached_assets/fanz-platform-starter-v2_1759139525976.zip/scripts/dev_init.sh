#!/usr/bin/env bash
set -euo pipefail
echo "Bootstrapping local dev..."
docker compose -f deploy/docker-compose.yml up -d db nats minio
echo "Apply schema... (compose init already loads schema.sql)"
echo "Done ✅"
