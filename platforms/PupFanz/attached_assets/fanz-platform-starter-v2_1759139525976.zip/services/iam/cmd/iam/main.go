package main

import (
	"fmt"
	"net/http"
)

func main() {
	fmt.Println("IAM service placeholder - wire gRPC here")
	http.ListenAndServe(":9002", nil)
}
