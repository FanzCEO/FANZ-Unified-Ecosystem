-- Core schema (trimmed). Use UUID generation in app or Postgres gen_random_uuid()
create extension if not exists pgcrypto;
create table if not exists tenant(
  id uuid primary key,
  slug text unique not null,
  name text not null,
  settings jsonb default '{}'::jsonb
);
create table if not exists account(
  id uuid primary key,
  email citext unique,
  phone text,
  password_hash text,
  status text check (status in ('active','disabled','pending')) default 'active',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create table if not exists profile(
  id uuid primary key,
  account_id uuid references account(id),
  handle citext unique not null,
  display_name text,
  bio text,
  type text check (type in ('creator','fan','staff')) not null,
  flags jsonb default '{}'::jsonb,
  created_at timestamptz default now()
);
create table if not exists profile_tenant(
  id uuid primary key,
  profile_id uuid references profile(id),
  tenant_id uuid references tenant(id),
  is_visible boolean default true,
  settings jsonb default '{}'::jsonb,
  unique(profile_id, tenant_id)
);
create table if not exists content(
  id uuid primary key,
  creator_profile_id uuid references profile(id),
  title text,
  caption text,
  price_cents int default 0,
  visibility text check (visibility in ('public','subscribers','ppv')),
  canonical_tenant uuid references tenant(id),
  tags text[],
  created_at timestamptz default now()
);
create table if not exists media_asset(
  id uuid primary key,
  content_id uuid references content(id),
  storage_key text,
  mime text,
  bytes bigint,
  duration_sec int,
  width int,
  height int,
  checksum_sha256 text,
  perceptual_hash text,
  forensic_watermark jsonb,
  moderation_state text check (moderation_state in ('pending','approved','rejected')) default 'pending',
  created_at timestamptz default now()
);
create table if not exists content_tenant_map(
  id uuid primary key,
  content_id uuid references content(id),
  tenant_id uuid references tenant(id),
  status text check (status in ('published','scheduled','hidden')) default 'scheduled',
  unique(content_id, tenant_id)
);
create table if not exists model_release(
  id uuid primary key,
  content_id uuid references content(id),
  performer_profile_id uuid references profile(id),
  signed_at timestamptz,
  documents jsonb,
  jurisdiction text
);
create table if not exists record_2257(
  id uuid primary key,
  content_id uuid references content(id),
  custodian_account_id uuid references account(id),
  location_uri text,
  index_metadata jsonb,
  created_at timestamptz default now()
);
create table if not exists audit_log(
  id bigserial primary key,
  actor_account_id uuid,
  tenant_id uuid,
  action text,
  subject_table text,
  subject_id uuid,
  ip inet,
  user_agent text,
  at timestamptz default now(),
  data jsonb
);
