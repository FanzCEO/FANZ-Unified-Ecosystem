-- Seed tenants for all six brands
insert into tenant (id, slug, name) values
  (gen_random_uuid(), 'girlfanz', 'GirlFanz'),
  (gen_random_uuid(), 'pupfanz', 'PupFanz'),
  (gen_random_uuid(), 'daddyfanz', 'DaddyFanz'),
  (gen_random_uuid(), 'boyfanz', 'BoyFanz'),
  (gen_random_uuid(), 'cougarfanz', 'CougarFanz'),
  (gen_random_uuid(), 'taboofanz', 'TabooFanz')
on conflict (slug) do nothing;
