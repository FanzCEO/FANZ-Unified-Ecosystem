#!/bin/bash
set -euo pipefail

# Fanz OS Deployment Script
# Production-ready deployment with comprehensive checks and rollback capabilities

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
ENVIRONMENT="${1:-staging}"
VERSION="${2:-latest}"
DRY_RUN="${3:-false}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Validate environment
validate_environment() {
    local env="$1"
    if [[ "$env" != "staging" && "$env" != "production" ]]; then
        log_error "Invalid environment: $env. Must be 'staging' or 'production'"
        exit 1
    fi
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    local missing_tools=()
    
    # Check required tools
    command -v kubectl >/dev/null 2>&1 || missing_tools+=("kubectl")
    command -v helm >/dev/null 2>&1 || missing_tools+=("helm")
    command -v docker >/dev/null 2>&1 || missing_tools+=("docker")
    command -v jq >/dev/null 2>&1 || missing_tools+=("jq")
    
    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        log_error "Missing required tools: ${missing_tools[*]}"
        log_info "Please install missing tools and try again"
        exit 1
    fi
    
    # Check Kubernetes connection
    if ! kubectl cluster-info >/dev/null 2>&1; then
        log_error "Unable to connect to Kubernetes cluster"
        log_info "Please check your kubeconfig and try again"
        exit 1
    fi
    
    # Check Helm repositories
    if ! helm repo list | grep -q bitnami; then
        log_info "Adding required Helm repositories..."
        helm repo add bitnami https://charts.bitnami.com/bitnami
        helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
        helm repo add jetstack https://charts.jetstack.io
        helm repo update
    fi
    
    log_success "Prerequisites check passed"
}

# Pre-deployment checks
pre_deployment_checks() {
    local env="$1"
    local namespace="fanz-os$([ "$env" = "staging" ] && echo "-staging" || echo "")"
    
    log_info "Running pre-deployment checks for $env..."
    
    # Check namespace exists
    if ! kubectl get namespace "$namespace" >/dev/null 2>&1; then
        log_warning "Namespace $namespace does not exist. It will be created."
    fi
    
    # Check secrets exist
    local required_secrets=("fanz-os-secrets" "tls-certificates" "registry-credentials")
    for secret in "${required_secrets[@]}"; do
        if ! kubectl get secret "$secret" -n "$namespace" >/dev/null 2>&1; then
            log_warning "Secret $secret does not exist in namespace $namespace"
            log_warning "Make sure to create all required secrets before deployment"
        fi
    done
    
    # Check storage classes
    if ! kubectl get storageclass fast-ssd >/dev/null 2>&1; then
        log_warning "Storage class 'fast-ssd' not found. Using default storage class."
    fi
    
    log_success "Pre-deployment checks completed"
}

# Deploy infrastructure components
deploy_infrastructure() {
    local env="$1"
    local namespace="fanz-os$([ "$env" = "staging" ] && echo "-staging" || echo "")"
    
    log_info "Deploying infrastructure components..."
    
    # Deploy cert-manager if not exists
    if ! kubectl get namespace cert-manager >/dev/null 2>&1; then
        log_info "Installing cert-manager..."
        kubectl apply -f https://github.com/jetstack/cert-manager/releases/latest/download/cert-manager.yaml
        kubectl wait --for=condition=ready pod -l app=cert-manager -n cert-manager --timeout=300s
    fi
    
    # Deploy ingress-nginx if not exists
    if ! kubectl get namespace ingress-nginx >/dev/null 2>&1; then
        log_info "Installing ingress-nginx..."
        helm install ingress-nginx ingress-nginx/ingress-nginx \
            --namespace ingress-nginx \
            --create-namespace \
            --set controller.service.type=LoadBalancer
        kubectl wait --for=condition=ready pod -l app.kubernetes.io/name=ingress-nginx -n ingress-nginx --timeout=300s
    fi
    
    log_success "Infrastructure components deployed"
}

# Deploy Fanz OS application
deploy_application() {
    local env="$1"
    local version="$2"
    local namespace="fanz-os$([ "$env" = "staging" ] && echo "-staging" || echo "")"
    local release_name="fanz-os$([ "$env" = "staging" ] && echo "-staging" || echo "-prod")"
    local values_file="$PROJECT_ROOT/helm/fanz-os/values-$env.yaml"
    
    log_info "Deploying Fanz OS application to $env..."
    
    # Check if values file exists
    if [[ ! -f "$values_file" ]]; then
        log_warning "Values file $values_file not found. Using default values."
        values_file="$PROJECT_ROOT/helm/fanz-os/values.yaml"
    fi
    
    # Build Helm command
    local helm_cmd=("helm" "upgrade" "--install" "$release_name" "$PROJECT_ROOT/helm/fanz-os")
    helm_cmd+=("--namespace" "$namespace")
    helm_cmd+=("--create-namespace")
    helm_cmd+=("--values" "$values_file")
    helm_cmd+=("--set" "image.tag=$version")
    helm_cmd+=("--set" "fanzos.environment=$env")
    
    if [[ "$env" == "staging" ]]; then
        helm_cmd+=("--set" "fanzos.domain=staging.fanz-os.com")
        helm_cmd+=("--set" "tls.issuer=letsencrypt-staging")
    else
        helm_cmd+=("--set" "fanzos.domain=fanz-os.com")
        helm_cmd+=("--set" "tls.issuer=letsencrypt-prod")
    fi
    
    helm_cmd+=("--timeout" "15m")
    helm_cmd+=("--wait")
    
    if [[ "$DRY_RUN" == "true" ]]; then
        helm_cmd+=("--dry-run")
        log_info "Dry run mode enabled"
    fi
    
    # Execute deployment
    log_info "Executing: ${helm_cmd[*]}"
    "${helm_cmd[@]}"
    
    if [[ "$DRY_RUN" != "true" ]]; then
        log_success "Fanz OS application deployed successfully"
    else
        log_success "Dry run completed successfully"
    fi
}

# Post-deployment checks
post_deployment_checks() {
    local env="$1"
    local namespace="fanz-os$([ "$env" = "staging" ] && echo "-staging" || echo "")"
    local domain="$([ "$env" = "staging" ] && echo "staging.fanz-os.com" || echo "fanz-os.com")"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        log_info "Skipping post-deployment checks in dry run mode"
        return 0
    fi
    
    log_info "Running post-deployment checks..."
    
    # Wait for pods to be ready
    log_info "Waiting for pods to be ready..."
    if ! kubectl wait --for=condition=ready pod -l app.kubernetes.io/part-of=fanz-os -n "$namespace" --timeout=600s; then
        log_error "Pods failed to become ready within timeout"
        kubectl get pods -n "$namespace"
        return 1
    fi
    
    # Check service status
    log_info "Checking service status..."
    kubectl get pods,svc,ing -n "$namespace"
    
    # Wait for ingress to be ready
    log_info "Waiting for ingress to be ready..."
    local max_attempts=30
    local attempt=1
    
    while [[ $attempt -le $max_attempts ]]; do
        if curl -s -o /dev/null -w "%{http_code}" "https://$domain/health" | grep -q "200\|404"; then
            break
        fi
        
        log_info "Attempt $attempt/$max_attempts: Waiting for ingress..."
        sleep 10
        ((attempt++))
    done
    
    if [[ $attempt -gt $max_attempts ]]; then
        log_warning "Ingress may not be fully ready yet. Manual verification recommended."
    fi
    
    # Test health endpoints
    log_info "Testing health endpoints..."
    local health_endpoints=(
        "/health"
        "/api/v1/health"
        "/ready"
    )
    
    for endpoint in "${health_endpoints[@]}"; do
        local url="https://$domain$endpoint"
        local status_code
        status_code=$(curl -s -o /dev/null -w "%{http_code}" "$url" || echo "000")
        
        if [[ "$status_code" =~ ^(200|404)$ ]]; then
            log_success "✅ $url - Status: $status_code"
        else
            log_warning "⚠️  $url - Status: $status_code"
        fi
    done
    
    log_success "Post-deployment checks completed"
}

# Rollback function
rollback() {
    local env="$1"
    local namespace="fanz-os$([ "$env" = "staging" ] && echo "-staging" || echo "")"
    local release_name="fanz-os$([ "$env" = "staging" ] && echo "-staging" || echo "-prod")"
    
    log_warning "Initiating rollback for $env environment..."
    
    # Get rollback revision
    local revision="${2:-}"
    if [[ -z "$revision" ]]; then
        log_info "Getting previous revision..."
        revision=$(helm history "$release_name" -n "$namespace" --max 2 -o json | jq -r '.[1].revision // "1"')
    fi
    
    log_info "Rolling back to revision $revision..."
    
    if helm rollback "$release_name" "$revision" -n "$namespace" --wait --timeout 10m; then
        log_success "Rollback completed successfully"
        post_deployment_checks "$env"
    else
        log_error "Rollback failed"
        return 1
    fi
}

# Main deployment function
main() {
    local command="${1:-deploy}"
    
    case "$command" in
        "deploy")
            validate_environment "$ENVIRONMENT"
            check_prerequisites
            pre_deployment_checks "$ENVIRONMENT"
            deploy_infrastructure "$ENVIRONMENT"
            deploy_application "$ENVIRONMENT" "$VERSION"
            post_deployment_checks "$ENVIRONMENT"
            ;;
        "rollback")
            validate_environment "$ENVIRONMENT"
            check_prerequisites
            rollback "$ENVIRONMENT" "$VERSION"
            ;;
        "check")
            validate_environment "$ENVIRONMENT"
            check_prerequisites
            pre_deployment_checks "$ENVIRONMENT"
            ;;
        "status")
            validate_environment "$ENVIRONMENT"
            local namespace="fanz-os$([ "$ENVIRONMENT" = "staging" ] && echo "-staging" || echo "")"
            kubectl get pods,svc,ing -n "$namespace"
            helm status "fanz-os$([ "$ENVIRONMENT" = "staging" ] && echo "-staging" || echo "-prod")" -n "$namespace"
            ;;
        *)
            echo "Usage: $0 {deploy|rollback|check|status} [environment] [version] [dry-run]"
            echo ""
            echo "Commands:"
            echo "  deploy    - Deploy the application (default)"
            echo "  rollback  - Rollback to previous version"
            echo "  check     - Run pre-deployment checks only"
            echo "  status    - Show deployment status"
            echo ""
            echo "Parameters:"
            echo "  environment - staging or production (default: staging)"
            echo "  version     - Image tag/version (default: latest)"
            echo "  dry-run     - true/false (default: false)"
            echo ""
            echo "Examples:"
            echo "  $0 deploy staging v1.0.0"
            echo "  $0 deploy production v1.0.0 false"
            echo "  $0 rollback production"
            echo "  $0 status staging"
            exit 1
            ;;
    esac
}

# Error handling
trap 'log_error "Deployment script failed at line $LINENO"' ERR

# Execute main function
main "$@"

log_success "🎉 Fanz OS deployment script completed successfully!"
echo ""
log_info "Next steps:"
log_info "1. Verify all services are running: kubectl get pods -n fanz-os$([ "$ENVIRONMENT" = "staging" ] && echo "-staging" || echo "")"
log_info "2. Check application logs: kubectl logs -l app.kubernetes.io/part-of=fanz-os -n fanz-os$([ "$ENVIRONMENT" = "staging" ] && echo "-staging" || echo "")"
log_info "3. Access the application: https://$([ "$ENVIRONMENT" = "staging" ] && echo "staging.fanz-os.com" || echo "fanz-os.com")"
echo ""