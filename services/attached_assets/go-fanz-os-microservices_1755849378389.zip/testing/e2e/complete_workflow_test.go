package e2e

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
)

// TestCompleteCreatorFanWorkflow tests the entire platform workflow
func TestCompleteCreatorFanWorkflow(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Scenario: New creator joins platform, creates content, gets subscribers, earns money
	
	// Phase 1: Creator Onboarding
	creatorData := suite.CreateTestUser("creator")
	creatorData["bio"] = "I'm a fitness trainer who creates workout videos"
	creatorData["subscriptionPrice"] = 29.99

	t.Log("Phase 1: Creator Registration and Setup")
	
	// Register creator
	recorder := suite.MakeRequest("POST", "/api/auth/register", creatorData)
	require.Equal(t, 201, recorder.Code, "Creator registration should succeed")
	
	creatorToken := suite.LoginUser(creatorData["email"].(string), creatorData["password"].(string))
	
	// Complete profile setup
	profileData := map[string]interface{}{
		"displayName":       "FitGuru Mike",
		"bio":               creatorData["bio"],
		"subscriptionPrice": creatorData["subscriptionPrice"],
		"profileImageUrl":   "https://example.com/profile.jpg",
	}
	
	recorder = suite.MakeRequest("PUT", "/api/users/profile", profileData, creatorToken)
	require.Equal(t, 200, recorder.Code, "Profile setup should succeed")
	
	// Phase 2: Content Creation Strategy
	t.Log("Phase 2: Content Creation")
	
	var postIDs []string
	contentTypes := []map[string]interface{}{
		{
			"content":    "Welcome to my fitness journey! Here's a free workout to get started.",
			"mediaUrls":  []string{"https://example.com/free-workout.mp4"},
			"mediaTypes": []string{"video"},
			"visibility": "public",
			"isPpv":      false,
		},
		{
			"content":    "Exclusive advanced HIIT routine for subscribers only!",
			"mediaUrls":  []string{"https://example.com/hiit-workout.mp4"},
			"mediaTypes": []string{"video"},
			"visibility": "subscribers",
			"isPpv":      false,
		},
		{
			"content":    "Premium personal training session recording",
			"mediaUrls":  []string{"https://example.com/personal-training.mp4"},
			"mediaTypes": []string{"video"},
			"visibility": "public",
			"isPpv":      true,
			"ppvPrice":   15.99,
		},
	}
	
	for i, content := range contentTypes {
		recorder := suite.MakeRequest("POST", "/api/content/posts", content, creatorToken)
		require.Equal(t, 201, recorder.Code, "Content creation %d should succeed", i+1)
		
		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		post := response["post"].(map[string]interface{})
		postIDs = append(postIDs, post["id"].(string))
		
		// Simulate AI content analysis
		moderationData := map[string]interface{}{
			"content":     content["content"],
			"contentType": "text",
		}
		
		recorder = suite.MakeRequest("POST", "/api/ai/moderation/analyze", moderationData, creatorToken)
		assert.Equal(t, 200, recorder.Code, "Content moderation should work")
	}
	
	// Phase 3: Fan Discovery and Engagement
	t.Log("Phase 3: Fan Discovery and Engagement")
	
	// Create multiple fans with different behaviors
	fans := []map[string]interface{}{
		suite.CreateTestUser("fanz"), // Will become subscriber
		suite.CreateTestUser("fanz"), // Will purchase PPV
		suite.CreateTestUser("fanz"), // Will just interact
	}
	
	fanTokens := make([]string, len(fans))
	for i, fan := range fans {
		recorder := suite.MakeRequest("POST", "/api/auth/register", fan)
		require.Equal(t, 201, recorder.Code, "Fan %d registration should succeed", i+1)
		fanTokens[i] = suite.LoginUser(fan["email"].(string), fan["password"].(string))
	}
	
	// Fan 1: Discovers content through recommendations
	recorder = suite.MakeRequest("GET", "/api/ai/recommendations/creators", nil, fanTokens[0])
	require.Equal(t, 200, recorder.Code, "Creator recommendations should work")
	
	// All fans view public content
	for i, token := range fanTokens {
		recorder := suite.MakeRequest("GET", "/api/content/posts/"+postIDs[0], nil, token)
		require.Equal(t, 200, recorder.Code, "Fan %d should access public content", i+1)
		
		// Like the post
		recorder = suite.MakeRequest("POST", "/api/content/posts/"+postIDs[0]+"/like", nil, token)
		require.Equal(t, 200, recorder.Code, "Fan %d should be able to like post", i+1)
		
		// Comment on the post
		commentData := map[string]interface{}{
			"content": "Great workout! Thanks for sharing!",
		}
		recorder = suite.MakeRequest("POST", "/api/content/posts/"+postIDs[0]+"/comments", commentData, token)
		require.Equal(t, 201, recorder.Code, "Fan %d should be able to comment", i+1)
	}
	
	// Phase 4: Monetization - Subscriptions
	t.Log("Phase 4: Subscription Monetization")
	
	// Fan 1 becomes subscriber
	subscriptionData := map[string]interface{}{
		"creatorId":     creatorData["username"],
		"paymentMethod": "credit_card",
	}
	
	recorder = suite.MakeRequest("POST", "/api/payments/subscriptions", subscriptionData, fanTokens[0])
	require.Equal(t, 201, recorder.Code, "Subscription should succeed")
	
	var subscriptionResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &subscriptionResponse)
	subscription := subscriptionResponse["subscription"].(map[string]interface{})
	assert.Equal(t, "active", subscription["status"])
	
	// Subscriber can now access exclusive content
	recorder = suite.MakeRequest("GET", "/api/content/posts/"+postIDs[1], nil, fanTokens[0])
	require.Equal(t, 200, recorder.Code, "Subscriber should access exclusive content")
	
	// Non-subscriber cannot access exclusive content
	recorder = suite.MakeRequest("GET", "/api/content/posts/"+postIDs[1], nil, fanTokens[1])
	assert.Equal(t, 403, recorder.Code, "Non-subscriber should not access exclusive content")
	
	// Phase 5: PPV Monetization
	t.Log("Phase 5: PPV Monetization")
	
	// Fan 2 purchases PPV content
	recorder = suite.MakeRequest("GET", "/api/content/posts/"+postIDs[2], nil, fanTokens[1])
	assert.Equal(t, 402, recorder.Code, "PPV content should require payment")
	
	// Purchase the PPV content
	ppvData := map[string]interface{}{
		"creatorId":     creatorData["username"],
		"type":          "ppv",
		"amount":        15.99,
		"paymentMethod": "credit_card",
		"contentId":     postIDs[2],
	}
	
	recorder = suite.MakeRequest("POST", "/api/payments/transactions", ppvData, fanTokens[1])
	require.Equal(t, 201, recorder.Code, "PPV purchase should succeed")
	
	// Now can access PPV content
	recorder = suite.MakeRequest("GET", "/api/content/posts/"+postIDs[2], nil, fanTokens[1])
	require.Equal(t, 200, recorder.Code, "Should access PPV content after purchase")
	
	// Phase 6: Direct Messaging and PPV Messages
	t.Log("Phase 6: Messaging and PPV Messages")
	
	// Fan messages creator
	messageData := map[string]interface{}{
		"recipientId": creatorData["username"],
		"content":     "Love your workouts! Can you create a custom routine?",
		"messageType": "text",
	}
	
	recorder = suite.MakeRequest("POST", "/api/messaging/messages", messageData, fanTokens[0])
	require.Equal(t, 201, recorder.Code, "Fan should be able to message creator")
	
	// Creator sends PPV message with custom routine
	ppvMessageData := map[string]interface{}{
		"recipientId": fans[0]["username"],
		"content":     "Here's your custom workout routine! 💪",
		"messageType": "video",
		"mediaUrl":    "https://example.com/custom-routine.mp4",
		"isPpv":       true,
		"ppvPrice":    19.99,
	}
	
	recorder = suite.MakeRequest("POST", "/api/messaging/messages", ppvMessageData, creatorToken)
	require.Equal(t, 201, recorder.Code, "Creator should send PPV message")
	
	var ppvMessageResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &ppvMessageResponse)
	ppvMessage := ppvMessageResponse["message"].(map[string]interface{})
	ppvMessageID := ppvMessage["id"].(string)
	
	// Fan purchases PPV message
	purchaseData := map[string]interface{}{
		"paymentMethod": "credit_card",
	}
	
	recorder = suite.MakeRequest("POST", "/api/messaging/messages/"+ppvMessageID+"/purchase", purchaseData, fanTokens[0])
	require.Equal(t, 200, recorder.Code, "PPV message purchase should succeed")
	
	// Phase 7: Tipping and Appreciation
	t.Log("Phase 7: Tipping")
	
	// Fans tip the creator
	tipAmounts := []float64{10.00, 25.00, 5.00}
	for i, amount := range tipAmounts {
		tipData := map[string]interface{}{
			"creatorId":     creatorData["username"],
			"type":          "tip",
			"amount":        amount,
			"paymentMethod": "credit_card",
			"message":       "Keep up the great work!",
		}
		
		recorder := suite.MakeRequest("POST", "/api/payments/transactions", tipData, fanTokens[i])
		require.Equal(t, 201, recorder.Code, "Tip %d should succeed", i+1)
	}
	
	// Phase 8: Live Streaming
	t.Log("Phase 8: Live Streaming")
	
	// Creator starts live workout session
	streamData := map[string]interface{}{
		"title":       "Live Morning Workout Session",
		"description": "Join me for an energizing morning workout!",
		"isPrivate":   false,
		"price":       0,
	}
	
	recorder = suite.MakeRequest("POST", "/api/streaming/streams", streamData, creatorToken)
	require.Equal(t, 201, recorder.Code, "Stream creation should succeed")
	
	var streamResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &streamResponse)
	stream := streamResponse["stream"].(map[string]interface{})
	streamID := stream["id"].(string)
	
	// Start the stream
	recorder = suite.MakeRequest("POST", "/api/streaming/streams/"+streamID+"/start", nil, creatorToken)
	require.Equal(t, 200, recorder.Code, "Stream start should succeed")
	
	// Fans join the stream
	for i, token := range fanTokens {
		recorder := suite.MakeRequest("POST", "/api/streaming/streams/"+streamID+"/join", nil, token)
		require.Equal(t, 200, recorder.Code, "Fan %d should join stream", i+1)
		
		// Send chat messages
		chatData := map[string]interface{}{
			"message": "Great stream! Thanks for the motivation!",
		}
		recorder = suite.MakeRequest("POST", "/api/streaming/streams/"+streamID+"/chat", chatData, token)
		require.Equal(t, 200, recorder.Code, "Fan %d should send chat", i+1)
	}
	
	// Stop the stream
	recorder = suite.MakeRequest("POST", "/api/streaming/streams/"+streamID+"/stop", nil, creatorToken)
	require.Equal(t, 200, recorder.Code, "Stream stop should succeed")
	
	// Phase 9: Analytics and Insights
	t.Log("Phase 9: Analytics and Business Intelligence")
	
	// Creator views comprehensive analytics
	analyticsEndpoints := []string{
		"/api/ai/insights/content-performance",
		"/api/ai/insights/audience",
		"/api/ai/insights/revenue-optimization",
		"/api/payments/analytics/revenue?period=30days",
		"/api/streaming/analytics/streams",
	}
	
	for _, endpoint := range analyticsEndpoints {
		recorder := suite.MakeRequest("GET", endpoint, nil, creatorToken)
		assert.Equal(t, 200, recorder.Code, "Analytics endpoint %s should work", endpoint)
	}
	
	// Get AI recommendations for content strategy
	recorder = suite.MakeRequest("GET", "/api/ai/recommendations/strategy", nil, creatorToken)
	require.Equal(t, 200, recorder.Code, "Content strategy recommendations should work")
	
	// Phase 10: Creator Success Metrics
	t.Log("Phase 10: Success Metrics Validation")
	
	// Validate creator has earned money
	recorder = suite.MakeRequest("GET", "/api/payments/wallet/balance", nil, creatorToken)
	require.Equal(t, 200, recorder.Code, "Wallet balance check should work")
	
	var walletResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &walletResponse)
	
	// Should have earnings from subscription, PPV, tips, and PPV message
	totalEarnings := walletResponse["totalEarnings"].(float64)
	expectedMinimum := 29.99 + 15.99 + 10.00 + 25.00 + 5.00 + 19.99 // All transactions
	assert.True(t, totalEarnings >= expectedMinimum, "Creator should have earned money from all monetization streams")
	
	// Validate subscriber count
	recorder = suite.MakeRequest("GET", "/api/users/profile", nil, creatorToken)
	require.Equal(t, 200, recorder.Code, "Profile check should work")
	
	var profileResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &profileResponse)
	user := profileResponse["user"].(map[string]interface{})
	
	subscriberCount := user["subscriberCount"].(float64)
	assert.True(t, subscriberCount >= 1, "Creator should have at least 1 subscriber")
	
	// Phase 11: Fan Satisfaction Check
	t.Log("Phase 11: Fan Experience Validation")
	
	// Check fan notifications
	for i, token := range fanTokens {
		recorder := suite.MakeRequest("GET", "/api/messaging/notifications", nil, token)
		assert.Equal(t, 200, recorder.Code, "Fan %d notifications should work", i+1)
	}
	
	// Check personalized recommendations improved for fans
	recorder = suite.MakeRequest("GET", "/api/ai/recommendations/content", nil, fanTokens[0])
	require.Equal(t, 200, recorder.Code, "Content recommendations should work")
	
	var recResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &recResponse)
	personalizationScore := recResponse["personalizationScore"].(float64)
	assert.True(t, personalizationScore > 0.5, "Personalization should improve with interactions")
	
	t.Log("✅ Complete Creator-Fan Workflow Test Passed Successfully!")
	t.Logf("Creator earned $%.2f from %d subscribers and multiple revenue streams", totalEarnings, int(subscriberCount))
}

func TestPlatformScalabilityWorkflow(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Test platform handling multiple creators and fans simultaneously
	t.Log("Testing Platform Scalability")
	
	numCreators := 5
	numFansPerCreator := 3
	
	creators := make([]map[string]interface{}, numCreators)
	creatorTokens := make([]string, numCreators)
	
	// Create multiple creators
	for i := 0; i < numCreators; i++ {
		creator := suite.CreateTestUser("creator")
		creators[i] = creator
		
		recorder := suite.MakeRequest("POST", "/api/auth/register", creator)
		require.Equal(t, 201, recorder.Code, "Creator %d registration should succeed", i+1)
		
		creatorTokens[i] = suite.LoginUser(creator["email"].(string), creator["password"].(string))
		
		// Set up creator profile
		profileData := map[string]interface{}{
			"displayName":       "Creator " + string(rune(65+i)),
			"subscriptionPrice": float64(10 + i*5),
		}
		
		recorder = suite.MakeRequest("PUT", "/api/users/profile", profileData, creatorTokens[i])
		require.Equal(t, 200, recorder.Code, "Creator %d profile setup should succeed", i+1)
		
		// Create content
		postData := map[string]interface{}{
			"content":    "Content from creator " + string(rune(65+i)),
			"visibility": "public",
		}
		
		recorder = suite.MakeRequest("POST", "/api/content/posts", postData, creatorTokens[i])
		require.Equal(t, 201, recorder.Code, "Creator %d content creation should succeed", i+1)
	}
	
	// Create fans and distribute them across creators
	totalTransactions := 0
	for creatorIdx := 0; creatorIdx < numCreators; creatorIdx++ {
		for fanIdx := 0; fanIdx < numFansPerCreator; fanIdx++ {
			fan := suite.CreateTestUser("fanz")
			
			recorder := suite.MakeRequest("POST", "/api/auth/register", fan)
			require.Equal(t, 201, recorder.Code, "Fan %d-%d registration should succeed", creatorIdx+1, fanIdx+1)
			
			fanToken := suite.LoginUser(fan["email"].(string), fan["password"].(string))
			
			// Subscribe to creator
			subscriptionData := map[string]interface{}{
				"creatorId":     creators[creatorIdx]["username"],
				"paymentMethod": "credit_card",
			}
			
			recorder = suite.MakeRequest("POST", "/api/payments/subscriptions", subscriptionData, fanToken)
			if recorder.Code == 201 {
				totalTransactions++
			}
			
			// Send tip
			tipData := map[string]interface{}{
				"creatorId":     creators[creatorIdx]["username"],
				"type":          "tip",
				"amount":        5.00,
				"paymentMethod": "credit_card",
			}
			
			recorder = suite.MakeRequest("POST", "/api/payments/transactions", tipData, fanToken)
			if recorder.Code == 201 {
				totalTransactions++
			}
		}
	}
	
	t.Logf("✅ Platform handled %d creators with %d fans each, processing %d transactions", 
		numCreators, numFansPerCreator, totalTransactions)
	
	assert.True(t, totalTransactions > 0, "Platform should process multiple transactions")
}

func TestContentModerationWorkflow(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Test complete content moderation pipeline
	t.Log("Testing Content Moderation Workflow")
	
	// Create admin, creator, and user
	adminUser := suite.CreateTestUser("admin")
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")
	
	users := []map[string]interface{}{adminUser, creatorUser, fanUser}
	tokens := make([]string, 3)
	
	for i, user := range users {
		recorder := suite.MakeRequest("POST", "/api/auth/register", user)
		require.Equal(t, 201, recorder.Code, "User %d registration should succeed", i+1)
		tokens[i] = suite.LoginUser(user["email"].(string), user["password"].(string))
	}
	
	adminToken, creatorToken, fanToken := tokens[0], tokens[1], tokens[2]
	
	// Test different types of content
	contentTests := []struct {
		content      string
		shouldFlag   bool
		description  string
	}{
		{
			content:      "This is perfectly appropriate content for everyone!",
			shouldFlag:   false,
			description:  "Clean content",
		},
		{
			content:      "This might be borderline inappropriate content",
			shouldFlag:   true,
			description:  "Borderline content",
		},
		{
			content:      "BUY NOW! CLICK HERE! AMAZING DEALS! LIMITED TIME!",
			shouldFlag:   true,
			description:  "Spam content",
		},
	}
	
	flaggedPostIDs := []string{}
	
	for i, test := range contentTests {
		// Creator posts content
		postData := map[string]interface{}{
			"content":    test.content,
			"visibility": "public",
		}
		
		recorder := suite.MakeRequest("POST", "/api/content/posts", postData, creatorToken)
		assert.True(t, recorder.Code == 201 || recorder.Code == 202, 
			"Content %d (%s) should be created or flagged", i+1, test.description)
		
		if recorder.Code == 202 {
			// Content flagged for review
			var response map[string]interface{}
			json.Unmarshal(recorder.Body.Bytes(), &response)
			assert.Contains(t, response["message"], "review", "Flagged content should mention review")
		} else if recorder.Code == 201 {
			var response map[string]interface{}
			json.Unmarshal(recorder.Body.Bytes(), &response)
			post := response["post"].(map[string]interface{})
			postID := post["id"].(string)
			
			if test.shouldFlag {
				flaggedPostIDs = append(flaggedPostIDs, postID)
			}
		}
	}
	
	// Fan reports content
	if len(flaggedPostIDs) > 0 {
		reportData := map[string]interface{}{
			"reason":      "inappropriate",
			"description": "This content violates community guidelines",
		}
		
		recorder := suite.MakeRequest("POST", "/api/content/posts/"+flaggedPostIDs[0]+"/report", reportData, fanToken)
		assert.Equal(t, 200, recorder.Code, "Content reporting should work")
	}
	
	// Admin reviews reported content
	recorder := suite.MakeRequest("GET", "/api/admin/content/reported", nil, adminToken)
	assert.Equal(t, 200, recorder.Code, "Admin should access reported content")
	
	// Admin takes moderation action
	if len(flaggedPostIDs) > 0 {
		moderationData := map[string]interface{}{
			"status": "approved",
			"notes":  "Content reviewed and approved",
		}
		
		recorder := suite.MakeRequest("PUT", "/api/admin/content/"+flaggedPostIDs[0]+"/moderate", moderationData, adminToken)
		assert.Equal(t, 200, recorder.Code, "Admin moderation should work")
	}
	
	t.Log("✅ Content Moderation Workflow Test Passed Successfully!")
}

func TestCriticalSystemFailureRecovery(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Test system behavior under various failure scenarios
	t.Log("Testing Critical System Failure Recovery")
	
	// Create test user
	testUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/api/auth/register", testUser)
	require.Equal(t, 201, recorder.Code, "User registration should succeed")
	
	token := suite.LoginUser(testUser["email"].(string), testUser["password"].(string))
	
	// Test 1: Database connection failure simulation
	t.Run("Database Failure Recovery", func(t *testing.T) {
		// Attempt operations that would fail if database is down
		recorder := suite.MakeRequest("GET", "/api/users/profile", nil, token)
		// Should either succeed or fail gracefully
		assert.True(t, recorder.Code == 200 || recorder.Code >= 500)
		
		if recorder.Code >= 500 {
			var response map[string]interface{}
			json.Unmarshal(recorder.Body.Bytes(), &response)
			assert.Contains(t, response, "error")
		}
	})
	
	// Test 2: Service overload simulation
	t.Run("Service Overload Handling", func(t *testing.T) {
		// Make multiple concurrent requests
		done := make(chan bool, 10)
		
		for i := 0; i < 10; i++ {
			go func() {
				recorder := suite.MakeRequest("GET", "/api/users/profile", nil, token)
				// Should handle concurrent requests gracefully
				assert.True(t, recorder.Code == 200 || recorder.Code == 429 || recorder.Code >= 500)
				done <- true
			}()
		}
		
		// Wait for all requests to complete
		for i := 0; i < 10; i++ {
			<-done
		}
	})
	
	// Test 3: Network partition simulation
	t.Run("Network Partition Tolerance", func(t *testing.T) {
		// Test operations that require multiple service coordination
		postData := map[string]interface{}{
			"content":    "Testing network partition tolerance",
			"visibility": "public",
		}
		
		recorder := suite.MakeRequest("POST", "/api/content/posts", postData, token)
		// Should either succeed or fail with proper error
		assert.True(t, recorder.Code == 201 || recorder.Code >= 500)
	})
	
	t.Log("✅ Critical System Failure Recovery Test Completed!")
}

func TestPerformanceUnderLoad(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Test platform performance under simulated load
	t.Log("Testing Performance Under Load")
	
	// Create test users
	testUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/api/auth/register", testUser)
	require.Equal(t, 201, recorder.Code, "User registration should succeed")
	
	token := suite.LoginUser(testUser["email"].(string), testUser["password"].(string))
	
	// Performance test scenarios
	scenarios := []struct {
		name        string
		endpoint    string
		method      string
		payload     map[string]interface{}
		maxDuration time.Duration
	}{
		{
			name:        "User Profile Load",
			endpoint:    "/api/users/profile",
			method:      "GET",
			payload:     nil,
			maxDuration: 1 * time.Second,
		},
		{
			name:        "Content Creation Load",
			endpoint:    "/api/content/posts",
			method:      "POST",
			payload:     map[string]interface{}{"content": "Load test post", "visibility": "public"},
			maxDuration: 2 * time.Second,
		},
		{
			name:        "Recommendations Load",
			endpoint:    "/api/ai/recommendations/creators",
			method:      "GET",
			payload:     nil,
			maxDuration: 3 * time.Second,
		},
	}
	
	for _, scenario := range scenarios {
		t.Run(scenario.name, func(t *testing.T) {
			start := time.Now()
			
			if scenario.method == "GET" {
				recorder := suite.MakeRequest(scenario.method, scenario.endpoint, nil, token)
				assert.True(t, recorder.Code == 200 || recorder.Code >= 500)
			} else {
				recorder := suite.MakeRequest(scenario.method, scenario.endpoint, scenario.payload, token)
				assert.True(t, recorder.Code == 201 || recorder.Code >= 500)
			}
			
			duration := time.Since(start)
			assert.True(t, duration < scenario.maxDuration, 
				"Request should complete within %v, took %v", scenario.maxDuration, duration)
			
			t.Logf("%s completed in %v", scenario.name, duration)
		})
	}
	
	t.Log("✅ Performance Under Load Test Completed!")
}