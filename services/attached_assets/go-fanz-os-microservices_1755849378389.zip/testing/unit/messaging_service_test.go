package unit

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
)

func TestMessagingServiceConversations(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator and fan users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	t.Run("Start Conversation", func(t *testing.T) {
		messageData := map[string]interface{}{
			"recipientId": creatorUser["username"],
			"content":     "Hi! I love your content!",
			"messageType": "text",
		}

		recorder := suite.MakeRequest("POST", "/messages", messageData, fanToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "message")
		assert.Contains(t, response, "conversation")
		
		message := response["message"].(map[string]interface{})
		assert.Equal(t, "Hi! I love your content!", message["content"])
		assert.Equal(t, "text", message["messageType"])
	})

	t.Run("Get Conversations", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/conversations", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "conversations")
		conversations := response["conversations"].([]interface{})
		assert.GreaterOrEqual(t, len(conversations), 1)

		conversation := conversations[0].(map[string]interface{})
		assert.Contains(t, conversation, "id")
		assert.Contains(t, conversation, "participants")
		assert.Contains(t, conversation, "lastMessage")
		assert.Contains(t, conversation, "unreadCount")
	})

	t.Run("Reply to Message", func(t *testing.T) {
		replyData := map[string]interface{}{
			"recipientId": fanUser["username"],
			"content":     "Thank you so much! 💕",
			"messageType": "text",
		}

		recorder := suite.MakeRequest("POST", "/messages", replyData, creatorToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		message := response["message"].(map[string]interface{})
		assert.Equal(t, "Thank you so much! 💕", message["content"])
	})
}

func TestMessagingServicePPVMessages(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	var ppvMessageID string

	t.Run("Send PPV Message", func(t *testing.T) {
		ppvData := map[string]interface{}{
			"recipientId": fanUser["username"],
			"content":     "Exclusive photo just for you! 📸",
			"messageType": "image",
			"mediaUrl":    "https://example.com/exclusive-photo.jpg",
			"isPpv":       true,
			"ppvPrice":    4.99,
		}

		recorder := suite.MakeRequest("POST", "/messages", ppvData, creatorToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		message := response["message"].(map[string]interface{})
		assert.Equal(t, true, message["isPpv"])
		assert.Equal(t, 4.99, message["ppvPrice"])
		assert.Equal(t, "pending", message["ppvStatus"])

		ppvMessageID = message["id"].(string)
	})

	t.Run("Fan View PPV Message Before Payment", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/messages/"+ppvMessageID, nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		message := response["message"].(map[string]interface{})
		assert.Equal(t, true, message["isPpv"])
		assert.Equal(t, "pending", message["ppvStatus"])
		// Media URL should be blurred or not included
		assert.NotContains(t, message, "mediaUrl")
	})

	t.Run("Purchase PPV Message", func(t *testing.T) {
		purchaseData := map[string]interface{}{
			"paymentMethod": "credit_card",
		}

		recorder := suite.MakeRequest("POST", "/messages/"+ppvMessageID+"/purchase", purchaseData, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "transaction")
		assert.Contains(t, response, "message")
		
		message := response["message"].(map[string]interface{})
		assert.Equal(t, "unlocked", message["ppvStatus"])
	})

	t.Run("Fan View PPV Message After Payment", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/messages/"+ppvMessageID, nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		message := response["message"].(map[string]interface{})
		assert.Equal(t, "unlocked", message["ppvStatus"])
		// Media URL should now be accessible
		assert.Contains(t, message, "mediaUrl")
		assert.Equal(t, "https://example.com/exclusive-photo.jpg", message["mediaUrl"])
	})
}

func TestMessagingServiceMediaMessages(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	tests := []struct {
		name         string
		messageType  string
		mediaUrl     string
		expectedCode int
		expectError  bool
		description  string
	}{
		{
			name:         "Send Image Message",
			messageType:  "image",
			mediaUrl:     "https://example.com/photo.jpg",
			expectedCode: 201,
			expectError:  false,
			description:  "Image messages should be allowed",
		},
		{
			name:         "Send Video Message",
			messageType:  "video",
			mediaUrl:     "https://example.com/video.mp4",
			expectedCode: 201,
			expectError:  false,
			description:  "Video messages should be allowed",
		},
		{
			name:         "Send Audio Message",
			messageType:  "audio",
			mediaUrl:     "https://example.com/voice-note.mp3",
			expectedCode: 201,
			expectError:  false,
			description:  "Audio messages should be allowed",
		},
		{
			name:         "Invalid Media Type",
			messageType:  "document",
			mediaUrl:     "https://example.com/file.pdf",
			expectedCode: 400,
			expectError:  true,
			description:  "Unsupported media types should be rejected",
		},
		{
			name:         "Missing Media URL",
			messageType:  "image",
			mediaUrl:     "",
			expectedCode: 400,
			expectError:  true,
			description:  "Media messages without URL should be rejected",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			messageData := map[string]interface{}{
				"recipientId": fanUser["username"],
				"content":     "Check this out!",
				"messageType": tt.messageType,
				"mediaUrl":    tt.mediaUrl,
				"isPpv":       false,
			}

			recorder := suite.MakeRequest("POST", "/messages", messageData, creatorToken)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				message := response["message"].(map[string]interface{})
				assert.Equal(t, tt.messageType, message["messageType"])
				assert.Equal(t, tt.mediaUrl, message["mediaUrl"])
			}
		})
	}
}

func TestMessagingServiceGroupChat(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	creatorUser := suite.CreateTestUser("creator")
	fan1User := suite.CreateTestUser("fanz")
	fan2User := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fan1User, fan2User} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fan1Token := suite.LoginUser(fan1User["email"].(string), fan1User["password"].(string))
	fan2Token := suite.LoginUser(fan2User["email"].(string), fan2User["password"].(string))

	var groupID string

	t.Run("Create Group Chat", func(t *testing.T) {
		groupData := map[string]interface{}{
			"name":        "VIP Fans",
			"description": "Exclusive group for VIP subscribers",
			"participants": []string{
				fan1User["username"].(string),
				fan2User["username"].(string),
			},
			"isPrivate": true,
			"price":     9.99,
		}

		recorder := suite.MakeRequest("POST", "/groups", groupData, creatorToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		group := response["group"].(map[string]interface{})
		assert.Equal(t, "VIP Fans", group["name"])
		assert.Equal(t, true, group["isPrivate"])
		
		groupID = group["id"].(string)
	})

	t.Run("Join Group Chat", func(t *testing.T) {
		joinData := map[string]interface{}{
			"paymentMethod": "credit_card",
		}

		recorder := suite.MakeRequest("POST", "/groups/"+groupID+"/join", joinData, fan1Token)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Successfully joined group", response["message"])
	})

	t.Run("Send Group Message", func(t *testing.T) {
		messageData := map[string]interface{}{
			"content":     "Hello VIP fans!",
			"messageType": "text",
		}

		recorder := suite.MakeRequest("POST", "/groups/"+groupID+"/messages", messageData, fan1Token)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		message := response["message"].(map[string]interface{})
		assert.Equal(t, "Hello VIP fans!", message["content"])
	})

	t.Run("Get Group Messages", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/groups/"+groupID+"/messages", nil, fan1Token)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "messages")
		messages := response["messages"].([]interface{})
		assert.GreaterOrEqual(t, len(messages), 1)
	})

	t.Run("Leave Group Chat", func(t *testing.T) {
		recorder := suite.MakeRequest("POST", "/groups/"+groupID+"/leave", nil, fan1Token)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Successfully left group", response["message"])
	})
}

func TestMessagingServiceNotifications(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	t.Run("Get Notifications", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/notifications", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "notifications")
		assert.Contains(t, response, "unreadCount")
	})

	t.Run("Send Message Creates Notification", func(t *testing.T) {
		// Send a message
		messageData := map[string]interface{}{
			"recipientId": fanUser["username"],
			"content":     "This should create a notification",
			"messageType": "text",
		}

		recorder := suite.MakeRequest("POST", "/messages", messageData, creatorToken)
		require.Equal(t, 201, recorder.Code)

		// Check fan's notifications
		suite.WaitForCondition(func() bool {
			recorder := suite.MakeRequest("GET", "/notifications", nil, fanToken)
			if recorder.Code != 200 {
				return false
			}
			
			var response map[string]interface{}
			json.Unmarshal(recorder.Body.Bytes(), &response)
			unreadCount := response["unreadCount"].(float64)
			return unreadCount > 0
		}, 5*time.Second, "Notification should be created")
	})

	t.Run("Mark Notification as Read", func(t *testing.T) {
		// Get notifications first
		recorder := suite.MakeRequest("GET", "/notifications", nil, fanToken)
		require.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		notifications := response["notifications"].([]interface{})
		
		if len(notifications) > 0 {
			notification := notifications[0].(map[string]interface{})
			notificationID := notification["id"].(string)

			recorder := suite.MakeRequest("PUT", "/notifications/"+notificationID+"/read", nil, fanToken)
			assert.Equal(t, 200, recorder.Code)

			var readResponse map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &readResponse)
			require.NoError(t, err)

			assert.Equal(t, "Notification marked as read", readResponse["message"])
		}
	})

	t.Run("Update Notification Preferences", func(t *testing.T) {
		preferencesData := map[string]interface{}{
			"newMessage":        true,
			"ppvMessage":        true,
			"newSubscriber":     true,
			"tips":              true,
			"liveStream":        false,
			"emailNotifications": true,
			"pushNotifications":  true,
		}

		recorder := suite.MakeRequest("PUT", "/notifications/preferences", preferencesData, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		preferences := response["preferences"].(map[string]interface{})
		assert.Equal(t, true, preferences["newMessage"])
		assert.Equal(t, false, preferences["liveStream"])
	})
}

func TestMessagingServiceRealTime(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	t.Run("Connect to WebSocket", func(t *testing.T) {
		// In a real test, this would establish WebSocket connections
		// For now, we'll test the WebSocket token generation endpoint
		recorder := suite.MakeRequest("POST", "/websocket/token", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "token")
		assert.Contains(t, response, "url")
		
		wsURL := response["url"].(string)
		assert.Contains(t, wsURL, "ws://") // or wss:// for secure connections
	})

	t.Run("Get Online Status", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/users/"+creatorUser["username"].(string)+"/status", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "isOnline")
		assert.Contains(t, response, "lastSeen")
	})

	t.Run("Set User Status", func(t *testing.T) {
		statusData := map[string]interface{}{
			"status": "away",
		}

		recorder := suite.MakeRequest("PUT", "/users/status", statusData, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "away", response["status"])
	})

	t.Run("Send Typing Indicator", func(t *testing.T) {
		typingData := map[string]interface{}{
			"recipientId": creatorUser["username"],
			"typing":      true,
		}

		recorder := suite.MakeRequest("POST", "/typing", typingData, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Typing indicator sent", response["message"])
	})
}