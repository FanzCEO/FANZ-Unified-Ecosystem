package unit

import (
	"encoding/json"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
	"github.com/fanz-os/testing/fixtures"
)

func TestContentServicePostCreation(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create and login creator
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)

	token := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	tests := []struct {
		name         string
		payload      map[string]interface{}
		expectedCode int
		expectError  bool
	}{
		{
			name: "Create Public Post",
			payload: map[string]interface{}{
				"content":    "This is a public post",
				"mediaUrls":  []string{"https://example.com/image1.jpg"},
				"mediaTypes": []string{"image"},
				"visibility": "public",
				"isPpv":      false,
			},
			expectedCode: 201,
			expectError:  false,
		},
		{
			name: "Create Subscriber-Only Post",
			payload: map[string]interface{}{
				"content":    "Exclusive content for subscribers",
				"mediaUrls":  []string{"https://example.com/video1.mp4"},
				"mediaTypes": []string{"video"},
				"visibility": "subscribers",
				"isPpv":      false,
			},
			expectedCode: 201,
			expectError:  false,
		},
		{
			name: "Create PPV Post",
			payload: map[string]interface{}{
				"content":    "Premium pay-per-view content",
				"mediaUrls":  []string{"https://example.com/premium.mp4"},
				"mediaTypes": []string{"video"},
				"visibility": "public",
				"isPpv":      true,
				"ppvPrice":   24.99,
			},
			expectedCode: 201,
			expectError:  false,
		},
		{
			name: "Create Post with Multiple Media",
			payload: map[string]interface{}{
				"content": "Post with multiple media files",
				"mediaUrls": []string{
					"https://example.com/image1.jpg",
					"https://example.com/image2.jpg",
					"https://example.com/video1.mp4",
				},
				"mediaTypes": []string{"image", "image", "video"},
				"visibility": "public",
				"isPpv":      false,
			},
			expectedCode: 201,
			expectError:  false,
		},
		{
			name: "Invalid Content - Empty",
			payload: map[string]interface{}{
				"content":    "",
				"mediaUrls":  []string{},
				"visibility": "public",
			},
			expectedCode: 400,
			expectError:  true,
		},
		{
			name: "Invalid PPV Price",
			payload: map[string]interface{}{
				"content":    "Test post",
				"visibility": "public",
				"isPpv":      true,
				"ppvPrice":   -5.00, // Negative price
			},
			expectedCode: 400,
			expectError:  true,
		},
		{
			name: "Media URLs and Types Mismatch",
			payload: map[string]interface{}{
				"content":    "Test post",
				"mediaUrls":  []string{"url1", "url2"},
				"mediaTypes": []string{"image"}, // Only one type for two URLs
				"visibility": "public",
			},
			expectedCode: 400,
			expectError:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			recorder := suite.MakeRequest("POST", "/posts", tt.payload, token)
			assert.Equal(t, tt.expectedCode, recorder.Code)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				assert.Contains(t, response, "post")
				
				post := response["post"].(map[string]interface{})
				assert.Equal(t, tt.payload["content"], post["content"])
				assert.Equal(t, tt.payload["visibility"], post["visibility"])
				assert.Equal(t, tt.payload["isPpv"], post["isPpv"])
				
				if tt.payload["isPpv"] == true {
					assert.Equal(t, tt.payload["ppvPrice"], post["ppvPrice"])
				}
			}
		})
	}
}

func TestContentServicePostRetrieval(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator and posts
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	// Create fan user
	fanUser := suite.CreateTestUser("fanz")
	recorder = suite.MakeRequest("POST", "/auth/register", fanUser)
	require.Equal(t, 201, recorder.Code)
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	// Create test posts
	publicPost := map[string]interface{}{
		"content":    "Public post",
		"visibility": "public",
		"isPpv":      false,
	}
	
	subscriberPost := map[string]interface{}{
		"content":    "Subscriber-only post",
		"visibility": "subscribers",
		"isPpv":      false,
	}
	
	ppvPost := map[string]interface{}{
		"content":    "PPV post",
		"visibility": "public",
		"isPpv":      true,
		"ppvPrice":   15.99,
	}

	// Create posts
	var postIDs []string
	for _, post := range []map[string]interface{}{publicPost, subscriberPost, ppvPost} {
		recorder := suite.MakeRequest("POST", "/posts", post, creatorToken)
		require.Equal(t, 201, recorder.Code)
		
		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		postData := response["post"].(map[string]interface{})
		postIDs = append(postIDs, postData["id"].(string))
	}

	tests := []struct {
		name         string
		endpoint     string
		token        string
		expectedCode int
		expectPost   bool
		description  string
	}{
		{
			name:         "Creator Access Own Public Post",
			endpoint:     "/posts/" + postIDs[0],
			token:        creatorToken,
			expectedCode: 200,
			expectPost:   true,
			description:  "Creator should access their own posts",
		},
		{
			name:         "Fan Access Public Post",
			endpoint:     "/posts/" + postIDs[0],
			token:        fanToken,
			expectedCode: 200,
			expectPost:   true,
			description:  "Fans should access public posts",
		},
		{
			name:         "Fan Access Subscriber Post Without Subscription",
			endpoint:     "/posts/" + postIDs[1],
			token:        fanToken,
			expectedCode: 403,
			expectPost:   false,
			description:  "Fans should not access subscriber posts without subscription",
		},
		{
			name:         "Fan Access PPV Post Without Payment",
			endpoint:     "/posts/" + postIDs[2],
			token:        fanToken,
			expectedCode: 402,
			expectPost:   false,
			description:  "Fans should get payment required for PPV posts",
		},
		{
			name:         "Unauthenticated Access Public Post",
			endpoint:     "/posts/" + postIDs[0],
			token:        "",
			expectedCode: 200,
			expectPost:   true,
			description:  "Public posts should be accessible without auth",
		},
		{
			name:         "Unauthenticated Access Private Post",
			endpoint:     "/posts/" + postIDs[1],
			token:        "",
			expectedCode: 401,
			expectPost:   false,
			description:  "Private posts should require authentication",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var recorder *httptest.ResponseRecorder
			if tt.token != "" {
				recorder = suite.MakeRequest("GET", tt.endpoint, nil, tt.token)
			} else {
				recorder = suite.MakeRequest("GET", tt.endpoint, nil)
			}
			
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			if tt.expectPost {
				var response map[string]interface{}
				err := json.Unmarshal(recorder.Body.Bytes(), &response)
				require.NoError(t, err)
				assert.Contains(t, response, "post")
			}
		})
	}
}

func TestContentServicePostInteractions(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator and post
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	// Create fan user
	fanUser := suite.CreateTestUser("fanz")
	recorder = suite.MakeRequest("POST", "/auth/register", fanUser)
	require.Equal(t, 201, recorder.Code)
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	// Create test post
	post := map[string]interface{}{
		"content":    "Test post for interactions",
		"visibility": "public",
		"isPpv":      false,
	}

	recorder = suite.MakeRequest("POST", "/posts", post, creatorToken)
	require.Equal(t, 201, recorder.Code)

	var response map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &response)
	postData := response["post"].(map[string]interface{})
	postID := postData["id"].(string)

	t.Run("Like Post", func(t *testing.T) {
		recorder := suite.MakeRequest("POST", "/posts/"+postID+"/like", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.True(t, response["liked"].(bool))
		assert.Equal(t, float64(1), response["likeCount"].(float64))
	})

	t.Run("Unlike Post", func(t *testing.T) {
		recorder := suite.MakeRequest("DELETE", "/posts/"+postID+"/like", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.False(t, response["liked"].(bool))
		assert.Equal(t, float64(0), response["likeCount"].(float64))
	})

	t.Run("Add Comment", func(t *testing.T) {
		commentData := map[string]interface{}{
			"content": "Great post!",
		}

		recorder := suite.MakeRequest("POST", "/posts/"+postID+"/comments", commentData, fanToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		comment := response["comment"].(map[string]interface{})
		assert.Equal(t, "Great post!", comment["content"])
		assert.Equal(t, postID, comment["postId"])
	})

	t.Run("Get Comments", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/posts/"+postID+"/comments", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		comments := response["comments"].([]interface{})
		assert.Len(t, comments, 1)

		comment := comments[0].(map[string]interface{})
		assert.Equal(t, "Great post!", comment["content"])
	})

	t.Run("Report Content", func(t *testing.T) {
		reportData := map[string]interface{}{
			"reason":      "inappropriate",
			"description": "This content violates community guidelines",
		}

		recorder := suite.MakeRequest("POST", "/posts/"+postID+"/report", reportData, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Report submitted successfully", response["message"])
	})
}

func TestContentServiceMediaUpload(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	tests := []struct {
		name         string
		fileType     string
		fileSize     int64
		expectedCode int
		expectError  bool
		description  string
	}{
		{
			name:         "Valid Image Upload",
			fileType:     "image/jpeg",
			fileSize:     1024 * 1024, // 1MB
			expectedCode: 200,
			expectError:  false,
			description:  "Standard image should upload successfully",
		},
		{
			name:         "Valid Video Upload",
			fileType:     "video/mp4",
			fileSize:     10 * 1024 * 1024, // 10MB
			expectedCode: 200,
			expectError:  false,
			description:  "Standard video should upload successfully",
		},
		{
			name:         "File Too Large",
			fileType:     "video/mp4",
			fileSize:     500 * 1024 * 1024, // 500MB
			expectedCode: 413,
			expectError:  true,
			description:  "Files over size limit should be rejected",
		},
		{
			name:         "Unsupported File Type",
			fileType:     "application/exe",
			fileSize:     1024,
			expectedCode: 400,
			expectError:  true,
			description:  "Unsupported file types should be rejected",
		},
		{
			name:         "Empty File",
			fileType:     "image/jpeg",
			fileSize:     0,
			expectedCode: 400,
			expectError:  true,
			description:  "Empty files should be rejected",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			uploadData := map[string]interface{}{
				"fileType": tt.fileType,
				"fileSize": tt.fileSize,
				"fileName": "test-file",
			}

			recorder := suite.MakeRequest("POST", "/media/upload-url", uploadData, creatorToken)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			if !tt.expectError {
				var response map[string]interface{}
				err := json.Unmarshal(recorder.Body.Bytes(), &response)
				require.NoError(t, err)

				assert.Contains(t, response, "uploadUrl")
				assert.Contains(t, response, "mediaId")
			}
		})
	}
}

func TestContentServiceContentModeration(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	tests := []struct {
		name         string
		content      string
		expectedCode int
		expectError  bool
		description  string
	}{
		{
			name:         "Clean Content",
			content:      "This is perfectly clean content",
			expectedCode: 201,
			expectError:  false,
			description:  "Clean content should be approved",
		},
		{
			name:         "Potentially Inappropriate Content",
			content:      "This content contains inappropriate language: damn",
			expectedCode: 202,
			expectError:  false,
			description:  "Borderline content should be flagged for review",
		},
		{
			name:         "Clearly Inappropriate Content",
			content:      "This content contains explicit illegal content",
			expectedCode: 400,
			expectError:  true,
			description:  "Clearly inappropriate content should be rejected",
		},
		{
			name:         "Spam Content",
			content:      "Buy now! Click here! Amazing deal! Hurry up! Limited time!",
			expectedCode: 400,
			expectError:  true,
			description:  "Spam content should be rejected",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			postData := map[string]interface{}{
				"content":    tt.content,
				"visibility": "public",
				"isPpv":      false,
			}

			recorder := suite.MakeRequest("POST", "/posts", postData, creatorToken)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else if recorder.Code == 202 {
				// Content under review
				assert.Contains(t, response, "message")
				assert.Contains(t, response["message"], "review")
			} else {
				// Content approved
				assert.Contains(t, response, "post")
			}
		})
	}
}

func TestContentServiceShortVideos(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	t.Run("Create Short Video", func(t *testing.T) {
		shortVideoData := map[string]interface{}{
			"title":       "My Short Video",
			"description": "A fun short video",
			"videoUrl":    "https://example.com/short-video.mp4",
			"thumbnailUrl": "https://example.com/thumbnail.jpg",
			"duration":    30, // 30 seconds
			"tags":        []string{"fun", "creative", "short"},
		}

		recorder := suite.MakeRequest("POST", "/short-videos", shortVideoData, creatorToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		shortVideo := response["shortVideo"].(map[string]interface{})
		assert.Equal(t, "My Short Video", shortVideo["title"])
		assert.Equal(t, float64(30), shortVideo["duration"])
	})

	t.Run("Get Short Videos Feed", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/short-videos/feed", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		shortVideos := response["shortVideos"].([]interface{})
		assert.GreaterOrEqual(t, len(shortVideos), 1)
	})

	t.Run("Invalid Short Video Duration", func(t *testing.T) {
		shortVideoData := map[string]interface{}{
			"title":    "Invalid Duration",
			"videoUrl": "https://example.com/long-video.mp4",
			"duration": 300, // 5 minutes - too long for short video
		}

		recorder := suite.MakeRequest("POST", "/short-videos", shortVideoData, creatorToken)
		assert.Equal(t, 400, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response["error"], "duration")
	})
}