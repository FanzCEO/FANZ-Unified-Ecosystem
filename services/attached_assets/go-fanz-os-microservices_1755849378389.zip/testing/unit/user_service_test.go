package unit

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
	"github.com/fanz-os/testing/fixtures"
)

func TestUserServiceRegistration(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	tests := []struct {
		name           string
		payload        map[string]interface{}
		expectedCode   int
		expectError    bool
		errorMessage   string
	}{
		{
			name: "Valid Creator Registration",
			payload: map[string]interface{}{
				"email":     "creator@test.com",
				"password":  "ValidPassword123!",
				"firstName": "John",
				"lastName":  "Creator",
				"role":      "creator",
				"username":  "johncreator",
			},
			expectedCode: 201,
			expectError:  false,
		},
		{
			name: "Valid Fan Registration",
			payload: map[string]interface{}{
				"email":     "fan@test.com",
				"password":  "ValidPassword123!",
				"firstName": "Jane",
				"lastName":  "Fan",
				"role":      "fanz",
				"username":  "janefan",
			},
			expectedCode: 201,
			expectError:  false,
		},
		{
			name: "Invalid Email Format",
			payload: map[string]interface{}{
				"email":     "invalid-email",
				"password":  "ValidPassword123!",
				"firstName": "Test",
				"lastName":  "User",
				"role":      "fanz",
			},
			expectedCode: 400,
			expectError:  true,
			errorMessage: "Invalid email format",
		},
		{
			name: "Weak Password",
			payload: map[string]interface{}{
				"email":     "test@test.com",
				"password":  "123",
				"firstName": "Test",
				"lastName":  "User",
				"role":      "fanz",
			},
			expectedCode: 400,
			expectError:  true,
			errorMessage: "Password must be at least 8 characters",
		},
		{
			name: "Missing Required Fields",
			payload: map[string]interface{}{
				"email":    "test@test.com",
				"password": "ValidPassword123!",
				// Missing firstName, lastName, role
			},
			expectedCode: 400,
			expectError:  true,
			errorMessage: "Missing required fields",
		},
		{
			name: "Duplicate Email",
			payload: map[string]interface{}{
				"email":     "creator@test.com", // Same as first test
				"password":  "ValidPassword123!",
				"firstName": "Duplicate",
				"lastName":  "User",
				"role":      "fanz",
			},
			expectedCode: 409,
			expectError:  true,
			errorMessage: "Email already exists",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			recorder := suite.MakeRequest("POST", "/auth/register", tt.payload)
			assert.Equal(t, tt.expectedCode, recorder.Code)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				assert.Contains(t, response, "user")
				assert.Contains(t, response, "token")
				
				user := response["user"].(map[string]interface{})
				assert.Equal(t, tt.payload["email"], user["email"])
				assert.Equal(t, tt.payload["firstName"], user["firstName"])
				assert.Equal(t, tt.payload["lastName"], user["lastName"])
				assert.Equal(t, tt.payload["role"], user["role"])
			}
		})
	}
}

func TestUserServiceAuthentication(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create test user first
	testUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", testUser)
	require.Equal(t, 201, recorder.Code)

	tests := []struct {
		name         string
		email        string
		password     string
		expectedCode int
		expectToken  bool
	}{
		{
			name:         "Valid Login",
			email:        testUser["email"].(string),
			password:     testUser["password"].(string),
			expectedCode: 200,
			expectToken:  true,
		},
		{
			name:         "Invalid Email",
			email:        "nonexistent@test.com",
			password:     testUser["password"].(string),
			expectedCode: 401,
			expectToken:  false,
		},
		{
			name:         "Invalid Password",
			email:        testUser["email"].(string),
			password:     "wrongpassword",
			expectedCode: 401,
			expectToken:  false,
		},
		{
			name:         "Empty Credentials",
			email:        "",
			password:     "",
			expectedCode: 400,
			expectToken:  false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			loginData := map[string]string{
				"email":    tt.email,
				"password": tt.password,
			}

			recorder := suite.MakeRequest("POST", "/auth/login", loginData)
			assert.Equal(t, tt.expectedCode, recorder.Code)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectToken {
				assert.Contains(t, response, "token")
				assert.Contains(t, response, "user")
				
				user := response["user"].(map[string]interface{})
				assert.Equal(t, tt.email, user["email"])
			} else {
				assert.Contains(t, response, "error")
			}
		})
	}
}

func TestUserServiceProfileManagement(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create and login user
	testUser := suite.CreateTestUser("creator")
	registerRecorder := suite.MakeRequest("POST", "/auth/register", testUser)
	require.Equal(t, 201, registerRecorder.Code)

	token := suite.LoginUser(testUser["email"].(string), testUser["password"].(string))

	tests := []struct {
		name         string
		updates      map[string]interface{}
		expectedCode int
		expectError  bool
	}{
		{
			name: "Valid Profile Update",
			updates: map[string]interface{}{
				"displayName": "Updated Display Name",
				"bio":         "Updated bio information",
			},
			expectedCode: 200,
			expectError:  false,
		},
		{
			name: "Update Subscription Price",
			updates: map[string]interface{}{
				"subscriptionPrice": 29.99,
			},
			expectedCode: 200,
			expectError:  false,
		},
		{
			name: "Invalid Bio Length",
			updates: map[string]interface{}{
				"bio": string(make([]byte, 1000)), // Too long
			},
			expectedCode: 400,
			expectError:  true,
		},
		{
			name: "Invalid Subscription Price",
			updates: map[string]interface{}{
				"subscriptionPrice": -10.00, // Negative price
			},
			expectedCode: 400,
			expectError:  true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			recorder := suite.MakeRequest("PUT", "/users/profile", tt.updates, token)
			assert.Equal(t, tt.expectedCode, recorder.Code)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				assert.Contains(t, response, "user")
				
				user := response["user"].(map[string]interface{})
				for key, value := range tt.updates {
					assert.Equal(t, value, user[key])
				}
			}
		})
	}
}

func TestUserServiceAuthorization(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users with different roles
	fanUser := suite.CreateTestUser("fanz")
	creatorUser := suite.CreateTestUser("creator")
	adminUser := suite.CreateTestUser("admin")

	for _, user := range []map[string]interface{}{fanUser, creatorUser, adminUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	adminToken := suite.LoginUser(adminUser["email"].(string), adminUser["password"].(string))

	tests := []struct {
		name         string
		endpoint     string
		method       string
		token        string
		expectedCode int
		description  string
	}{
		{
			name:         "Fan Access Fan Endpoint",
			endpoint:     "/users/subscriptions",
			method:       "GET",
			token:        fanToken,
			expectedCode: 200,
			description:  "Fans should access their subscriptions",
		},
		{
			name:         "Creator Access Creator Endpoint",
			endpoint:     "/creator/analytics",
			method:       "GET",
			token:        creatorToken,
			expectedCode: 200,
			description:  "Creators should access analytics",
		},
		{
			name:         "Admin Access Admin Endpoint",
			endpoint:     "/admin/users",
			method:       "GET",
			token:        adminToken,
			expectedCode: 200,
			description:  "Admins should access user management",
		},
		{
			name:         "Fan Access Creator Endpoint Denied",
			endpoint:     "/creator/analytics",
			method:       "GET",
			token:        fanToken,
			expectedCode: 403,
			description:  "Fans should not access creator endpoints",
		},
		{
			name:         "Creator Access Admin Endpoint Denied",
			endpoint:     "/admin/users",
			method:       "GET",
			token:        creatorToken,
			expectedCode: 403,
			description:  "Creators should not access admin endpoints",
		},
		{
			name:         "No Token Access Denied",
			endpoint:     "/users/profile",
			method:       "GET",
			token:        "",
			expectedCode: 401,
			description:  "Unauthenticated requests should be denied",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var recorder *httptest.ResponseRecorder
			if tt.token != "" {
				recorder = suite.MakeRequest(tt.method, tt.endpoint, nil, tt.token)
			} else {
				recorder = suite.MakeRequest(tt.method, tt.endpoint, nil)
			}
			
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)
		})
	}
}

func TestUserServiceTwoFactorAuthentication(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create test user
	testUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", testUser)
	require.Equal(t, 201, recorder.Code)

	token := suite.LoginUser(testUser["email"].(string), testUser["password"].(string))

	t.Run("Enable Two-Factor Authentication", func(t *testing.T) {
		recorder := suite.MakeRequest("POST", "/auth/2fa/enable", nil, token)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "secret")
		assert.Contains(t, response, "qrCodeUrl")
	})

	t.Run("Verify Two-Factor Code", func(t *testing.T) {
		verifyData := map[string]interface{}{
			"code": "123456", // Mock TOTP code
		}

		recorder := suite.MakeRequest("POST", "/auth/2fa/verify", verifyData, token)
		// In real implementation, this would validate against TOTP algorithm
		// For testing, we'll assume valid codes are 6 digits
		expectedCode := 200
		if verifyData["code"] != "123456" {
			expectedCode = 400
		}
		assert.Equal(t, expectedCode, recorder.Code)
	})

	t.Run("Disable Two-Factor Authentication", func(t *testing.T) {
		disableData := map[string]interface{}{
			"password": testUser["password"],
		}

		recorder := suite.MakeRequest("POST", "/auth/2fa/disable", disableData, token)
		assert.Equal(t, 200, recorder.Code)
	})
}

func TestUserServicePasswordReset(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create test user
	testUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", testUser)
	require.Equal(t, 201, recorder.Code)

	t.Run("Request Password Reset", func(t *testing.T) {
		resetData := map[string]interface{}{
			"email": testUser["email"],
		}

		recorder := suite.MakeRequest("POST", "/auth/password/reset-request", resetData)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "message")
		assert.Equal(t, "Password reset code sent", response["message"])
	})

	t.Run("Verify Reset Code", func(t *testing.T) {
		verifyData := map[string]interface{}{
			"email": testUser["email"],
			"code":  "123456", // Mock reset code
		}

		recorder := suite.MakeRequest("POST", "/auth/password/verify-code", verifyData)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "resetToken")
	})

	t.Run("Reset Password", func(t *testing.T) {
		resetData := map[string]interface{}{
			"resetToken":  "mock-reset-token",
			"newPassword": "NewPassword123!",
		}

		recorder := suite.MakeRequest("POST", "/auth/password/reset", resetData)
		assert.Equal(t, 200, recorder.Code)

		// Test login with new password
		loginData := map[string]interface{}{
			"email":    testUser["email"],
			"password": "NewPassword123!",
		}

		loginRecorder := suite.MakeRequest("POST", "/auth/login", loginData)
		assert.Equal(t, 200, loginRecorder.Code)
	})
}

func TestUserServiceRateLimiting(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	loginData := map[string]interface{}{
		"email":    "test@test.com",
		"password": "wrongpassword",
	}

	// Make multiple failed login attempts
	successCount := 0
	rateLimitedCount := 0

	for i := 0; i < 20; i++ {
		recorder := suite.MakeRequest("POST", "/auth/login", loginData)
		if recorder.Code == 401 {
			successCount++
		} else if recorder.Code == 429 {
			rateLimitedCount++
		}
		time.Sleep(10 * time.Millisecond) // Small delay between requests
	}

	// Should have some rate limited requests
	assert.True(t, rateLimitedCount > 0, "Rate limiting should kick in after multiple failed attempts")
	assert.True(t, successCount > 0, "Some requests should go through before rate limiting")
}