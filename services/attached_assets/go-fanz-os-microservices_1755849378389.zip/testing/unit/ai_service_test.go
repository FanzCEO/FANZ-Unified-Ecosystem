package unit

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
)

func TestAIServiceContentModeration(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	tests := []struct {
		name         string
		content      string
		contentType  string
		expectedCode int
		expectedAction string
		description  string
	}{
		{
			name:           "Clean Text Content",
			content:        "This is perfectly appropriate content for my fans!",
			contentType:    "text",
			expectedCode:   200,
			expectedAction: "approved",
			description:    "Clean content should be approved",
		},
		{
			name:           "Potentially Inappropriate Content",
			content:        "This content might be borderline inappropriate",
			contentType:    "text",
			expectedCode:   200,
			expectedAction: "flagged",
			description:    "Borderline content should be flagged for review",
		},
		{
			name:           "Spam Content",
			content:        "BUY NOW! CLICK HERE! AMAZING DEALS! LIMITED TIME ONLY!",
			contentType:    "text",
			expectedCode:   200,
			expectedAction: "rejected",
			description:    "Obvious spam should be rejected",
		},
		{
			name:           "Image Content Analysis",
			content:        "https://example.com/safe-image.jpg",
			contentType:    "image",
			expectedCode:   200,
			expectedAction: "approved",
			description:    "Safe images should be approved",
		},
		{
			name:           "Video Content Analysis",
			content:        "https://example.com/video.mp4",
			contentType:    "video",
			expectedCode:   200,
			expectedAction: "flagged",
			description:    "Videos require manual review",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			moderationData := map[string]interface{}{
				"content":     tt.content,
				"contentType": tt.contentType,
				"userId":      creatorUser["username"],
			}

			recorder := suite.MakeRequest("POST", "/ai/moderation/analyze", moderationData, creatorToken)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			assert.Contains(t, response, "action")
			assert.Contains(t, response, "confidence")
			assert.Contains(t, response, "reasons")
			
			if tt.expectedAction != "" {
				assert.Equal(t, tt.expectedAction, response["action"])
			}
			
			confidence := response["confidence"].(float64)
			assert.True(t, confidence >= 0 && confidence <= 1)
		})
	}
}

func TestAIServiceRecommendations(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	t.Run("Get Creator Recommendations for Fan", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/ai/recommendations/creators", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "recommendations")
		assert.Contains(t, response, "algorithm")
		
		recommendations := response["recommendations"].([]interface{})
		for _, rec := range recommendations {
			recommendation := rec.(map[string]interface{})
			assert.Contains(t, recommendation, "creatorId")
			assert.Contains(t, recommendation, "score")
			assert.Contains(t, recommendation, "reasons")
			
			score := recommendation["score"].(float64)
			assert.True(t, score >= 0 && score <= 1)
		}
	})

	t.Run("Get Content Recommendations for Fan", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/ai/recommendations/content", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "recommendations")
		assert.Contains(t, response, "personalizationScore")
		
		recommendations := response["recommendations"].([]interface{})
		for _, rec := range recommendations {
			recommendation := rec.(map[string]interface{})
			assert.Contains(t, recommendation, "contentId")
			assert.Contains(t, recommendation, "score")
			assert.Contains(t, recommendation, "category")
		}
	})

	t.Run("Get Pricing Recommendations for Creator", func(t *testing.T) {
		priceData := map[string]interface{}{
			"contentType": "video",
			"duration":    300, // 5 minutes
			"category":    "educational",
		}

		recorder := suite.MakeRequest("POST", "/ai/recommendations/pricing", priceData, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "recommendedPrice")
		assert.Contains(t, response, "priceRange")
		assert.Contains(t, response, "factors")
		
		recommendedPrice := response["recommendedPrice"].(float64)
		assert.True(t, recommendedPrice > 0)
		
		priceRange := response["priceRange"].(map[string]interface{})
		assert.Contains(t, priceRange, "min")
		assert.Contains(t, priceRange, "max")
	})

	t.Run("Get Content Strategy Recommendations", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/ai/recommendations/strategy", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "recommendations")
		assert.Contains(t, response, "insights")
		
		recommendations := response["recommendations"].([]interface{})
		for _, rec := range recommendations {
			recommendation := rec.(map[string]interface{})
			assert.Contains(t, recommendation, "type")
			assert.Contains(t, recommendation, "suggestion")
			assert.Contains(t, recommendation, "impact")
		}
	})
}

func TestAIServicePersonalization(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create fan user
	fanUser := suite.CreateTestUser("fanz")
	recorder := suite.MakeRequest("POST", "/auth/register", fanUser)
	require.Equal(t, 201, recorder.Code)
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	t.Run("Update User Preferences", func(t *testing.T) {
		preferencesData := map[string]interface{}{
			"contentCategories": []string{"fitness", "lifestyle", "education"},
			"priceRange": map[string]interface{}{
				"min": 5.0,
				"max": 25.0,
			},
			"languages":      []string{"en", "es"},
			"contentTypes":   []string{"video", "image"},
			"exclusions":     []string{"explicit"},
		}

		recorder := suite.MakeRequest("PUT", "/ai/personalization/preferences", preferencesData, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Preferences updated successfully", response["message"])
		assert.Contains(t, response, "personalizationScore")
	})

	t.Run("Get Personalized Feed", func(t *testing.T) {
		feedParams := map[string]interface{}{
			"limit": 20,
			"type":  "mixed",
		}

		recorder := suite.MakeRequest("POST", "/ai/personalization/feed", feedParams, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "feed")
		assert.Contains(t, response, "personalizationScore")
		assert.Contains(t, response, "algorithm")
		
		feed := response["feed"].([]interface{})
		for _, item := range feed {
			feedItem := item.(map[string]interface{})
			assert.Contains(t, feedItem, "contentId")
			assert.Contains(t, feedItem, "relevanceScore")
			assert.Contains(t, feedItem, "type")
		}
	})

	t.Run("Track User Interaction", func(t *testing.T) {
		interactionData := map[string]interface{}{
			"contentId":       "post-123",
			"interactionType": "view",
			"duration":        45, // seconds
			"engagement":      "high",
		}

		recorder := suite.MakeRequest("POST", "/ai/personalization/interaction", interactionData, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Interaction tracked", response["message"])
	})

	t.Run("Get User Profile Analysis", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/ai/personalization/profile", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "interests")
		assert.Contains(t, response, "behaviorPattern")
		assert.Contains(t, response, "engagementStyle")
		assert.Contains(t, response, "spendingPattern")
	})
}

func TestAIServiceInsights(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	t.Run("Get Content Performance Insights", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/ai/insights/content-performance", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "insights")
		assert.Contains(t, response, "trends")
		assert.Contains(t, response, "recommendations")
		
		insights := response["insights"].([]interface{})
		for _, insight := range insights {
			insightData := insight.(map[string]interface{})
			assert.Contains(t, insightData, "metric")
			assert.Contains(t, insightData, "value")
			assert.Contains(t, insightData, "trend")
			assert.Contains(t, insightData, "interpretation")
		}
	})

	t.Run("Get Audience Insights", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/ai/insights/audience", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "demographics")
		assert.Contains(t, response, "interests")
		assert.Contains(t, response, "behaviorPatterns")
		assert.Contains(t, response, "engagementPreferences")
		
		demographics := response["demographics"].(map[string]interface{})
		assert.Contains(t, demographics, "ageGroups")
		assert.Contains(t, demographics, "locations")
		assert.Contains(t, demographics, "spendingPower")
	})

	t.Run("Get Revenue Optimization Insights", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/ai/insights/revenue-optimization", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "currentRevenue")
		assert.Contains(t, response, "projectedRevenue")
		assert.Contains(t, response, "optimizations")
		
		optimizations := response["optimizations"].([]interface{})
		for _, opt := range optimizations {
			optimization := opt.(map[string]interface{})
			assert.Contains(t, optimization, "strategy")
			assert.Contains(t, optimization, "estimatedImpact")
			assert.Contains(t, optimization, "effort")
			assert.Contains(t, optimization, "priority")
		}
	})

	t.Run("Get Growth Predictions", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/ai/insights/growth-predictions", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "subscriberGrowth")
		assert.Contains(t, response, "revenueGrowth")
		assert.Contains(t, response, "engagementTrends")
		assert.Contains(t, response, "confidenceLevel")
		
		subscriberGrowth := response["subscriberGrowth"].(map[string]interface{})
		assert.Contains(t, subscriberGrowth, "current")
		assert.Contains(t, subscriberGrowth, "predicted30Days")
		assert.Contains(t, subscriberGrowth, "predicted90Days")
	})
}

func TestAIServiceChatbot(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create fan user
	fanUser := suite.CreateTestUser("fanz")
	recorder := suite.MakeRequest("POST", "/auth/register", fanUser)
	require.Equal(t, 201, recorder.Code)
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	t.Run("Start Chatbot Conversation", func(t *testing.T) {
		recorder := suite.MakeRequest("POST", "/ai/chatbot/conversations", nil, fanToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "conversationId")
		assert.Contains(t, response, "welcomeMessage")
		assert.Contains(t, response, "suggestedQuestions")
	})

	conversationID := "conv-test-123" // Mock conversation ID

	tests := []struct {
		name         string
		message      string
		expectedCode int
		expectReply  bool
		description  string
	}{
		{
			name:         "General Platform Question",
			message:      "How do I subscribe to a creator?",
			expectedCode: 200,
			expectReply:  true,
			description:  "Bot should answer platform questions",
		},
		{
			name:         "Pricing Question",
			message:      "How much does it cost to subscribe?",
			expectedCode: 200,
			expectReply:  true,
			description:  "Bot should provide pricing information",
		},
		{
			name:         "Technical Support",
			message:      "I'm having trouble uploading content",
			expectedCode: 200,
			expectReply:  true,
			description:  "Bot should provide technical support",
		},
		{
			name:         "Inappropriate Question",
			message:      "Can you help me with illegal activities?",
			expectedCode: 200,
			expectReply:  true,
			description:  "Bot should handle inappropriate questions appropriately",
		},
		{
			name:         "Empty Message",
			message:      "",
			expectedCode: 400,
			expectReply:  false,
			description:  "Empty messages should be rejected",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			chatData := map[string]interface{}{
				"message": tt.message,
			}

			recorder := suite.MakeRequest("POST", "/ai/chatbot/conversations/"+conversationID+"/messages", chatData, fanToken)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectReply {
				assert.Contains(t, response, "reply")
				assert.Contains(t, response, "confidence")
				assert.Contains(t, response, "suggestedActions")
				
				reply := response["reply"].(string)
				assert.NotEmpty(t, reply)
				
				confidence := response["confidence"].(float64)
				assert.True(t, confidence >= 0 && confidence <= 1)
			} else {
				assert.Contains(t, response, "error")
			}
		})
	}

	t.Run("Get Conversation History", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/ai/chatbot/conversations/"+conversationID, nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "conversation")
		assert.Contains(t, response, "messages")
		
		conversation := response["conversation"].(map[string]interface{})
		assert.Contains(t, conversation, "id")
		assert.Contains(t, conversation, "startedAt")
		assert.Contains(t, conversation, "status")
	})

	t.Run("End Chatbot Conversation", func(t *testing.T) {
		feedbackData := map[string]interface{}{
			"rating":   5,
			"feedback": "Very helpful!",
		}

		recorder := suite.MakeRequest("POST", "/ai/chatbot/conversations/"+conversationID+"/end", feedbackData, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Conversation ended", response["message"])
		assert.Contains(t, response, "summary")
	})
}