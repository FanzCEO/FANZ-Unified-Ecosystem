package unit

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
)

func TestStreamingServiceLiveStreams(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	// Create fan user
	fanUser := suite.CreateTestUser("fanz")
	recorder = suite.MakeRequest("POST", "/auth/register", fanUser)
	require.Equal(t, 201, recorder.Code)
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	tests := []struct {
		name         string
		endpoint     string
		method       string
		payload      map[string]interface{}
		token        string
		expectedCode int
		expectError  bool
		description  string
	}{
		{
			name:     "Create Live Stream",
			endpoint: "/streams",
			method:   "POST",
			payload: map[string]interface{}{
				"title":       "Live Q&A Session",
				"description": "Ask me anything about content creation",
				"isPrivate":   false,
				"price":       0,
				"scheduledAt": time.Now().Add(1 * time.Hour).Format(time.RFC3339),
			},
			token:        creatorToken,
			expectedCode: 201,
			expectError:  false,
			description:  "Creator should be able to create live stream",
		},
		{
			name:     "Create Private Stream",
			endpoint: "/streams",
			method:   "POST",
			payload: map[string]interface{}{
				"title":       "Private Show",
				"description": "Exclusive private streaming session",
				"isPrivate":   true,
				"price":       49.99,
				"maxViewers":  10,
			},
			token:        creatorToken,
			expectedCode: 201,
			expectError:  false,
			description:  "Creator should be able to create private stream",
		},
		{
			name:     "Fan Create Stream Denied",
			endpoint: "/streams",
			method:   "POST",
			payload: map[string]interface{}{
				"title": "Fan Stream",
			},
			token:        fanToken,
			expectedCode: 403,
			expectError:  true,
			description:  "Fan should not be able to create streams",
		},
		{
			name:     "Invalid Stream Data",
			endpoint: "/streams",
			method:   "POST",
			payload: map[string]interface{}{
				// Missing required title
				"description": "Stream without title",
			},
			token:        creatorToken,
			expectedCode: 400,
			expectError:  true,
			description:  "Invalid stream data should be rejected",
		},
	}

	var streamID string
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			recorder := suite.MakeRequest(tt.method, tt.endpoint, tt.payload, tt.token)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				assert.Contains(t, response, "stream")
				stream := response["stream"].(map[string]interface{})
				assert.Equal(t, tt.payload["title"], stream["title"])
				
				// Store first stream ID for later tests
				if streamID == "" {
					streamID = stream["id"].(string)
				}
			}
		})
	}

	// Test stream management
	t.Run("Start Stream", func(t *testing.T) {
		if streamID == "" {
			t.Skip("No stream ID available")
		}

		recorder := suite.MakeRequest("POST", "/streams/"+streamID+"/start", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "stream")
		stream := response["stream"].(map[string]interface{})
		assert.Equal(t, "live", stream["status"])
		assert.Contains(t, response, "streamKey")
		assert.Contains(t, response, "webrtcConfig")
	})

	t.Run("Get Live Streams", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/streams/live", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "streams")
		streams := response["streams"].([]interface{})
		assert.GreaterOrEqual(t, len(streams), 1)
	})

	t.Run("Join Stream", func(t *testing.T) {
		if streamID == "" {
			t.Skip("No stream ID available")
		}

		recorder := suite.MakeRequest("POST", "/streams/"+streamID+"/join", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "viewerToken")
		assert.Contains(t, response, "webrtcConfig")
		assert.Contains(t, response, "chatToken")
	})

	t.Run("Stop Stream", func(t *testing.T) {
		if streamID == "" {
			t.Skip("No stream ID available")
		}

		recorder := suite.MakeRequest("POST", "/streams/"+streamID+"/stop", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		stream := response["stream"].(map[string]interface{})
		assert.Equal(t, "ended", stream["status"])
		assert.Contains(t, response, "duration")
		assert.Contains(t, response, "viewerCount")
	})
}

func TestStreamingServiceWebRTC(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	t.Run("Get WebRTC Configuration", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/webrtc/config", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "iceServers")
		assert.Contains(t, response, "sdpSemantics")
		
		iceServers := response["iceServers"].([]interface{})
		assert.Greater(t, len(iceServers), 0)
		
		firstServer := iceServers[0].(map[string]interface{})
		assert.Contains(t, firstServer, "urls")
	})

	t.Run("Create WebRTC Offer", func(t *testing.T) {
		offerData := map[string]interface{}{
			"type": "offer",
			"sdp":  "v=0\no=- 123456789 987654321 IN IP4 192.168.1.1\n...",
		}

		recorder := suite.MakeRequest("POST", "/webrtc/offer", offerData, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "type")
		assert.Contains(t, response, "sdp")
		assert.Equal(t, "answer", response["type"])
	})

	t.Run("Handle ICE Candidate", func(t *testing.T) {
		candidateData := map[string]interface{}{
			"candidate":     "candidate:1 1 UDP 2130706431 192.168.1.1 54400 typ host",
			"sdpMLineIndex": 0,
			"sdpMid":        "video",
		}

		recorder := suite.MakeRequest("POST", "/webrtc/candidate", candidateData, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "received", response["status"])
	})
}

func TestStreamingServiceChat(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	// Create and start stream first
	streamData := map[string]interface{}{
		"title":       "Test Stream",
		"description": "Stream for chat testing",
		"isPrivate":   false,
	}

	recorder := suite.MakeRequest("POST", "/streams", streamData, creatorToken)
	require.Equal(t, 201, recorder.Code)

	var streamResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &streamResponse)
	stream := streamResponse["stream"].(map[string]interface{})
	streamID := stream["id"].(string)

	// Start the stream
	recorder = suite.MakeRequest("POST", "/streams/"+streamID+"/start", nil, creatorToken)
	require.Equal(t, 200, recorder.Code)

	tests := []struct {
		name         string
		message      string
		token        string
		expectedCode int
		expectError  bool
		description  string
	}{
		{
			name:         "Send Chat Message",
			message:      "Hello everyone!",
			token:        fanToken,
			expectedCode: 200,
			expectError:  false,
			description:  "Fan should be able to send chat messages",
		},
		{
			name:         "Creator Chat Message",
			message:      "Thanks for watching!",
			token:        creatorToken,
			expectedCode: 200,
			expectError:  false,
			description:  "Creator should be able to send chat messages",
		},
		{
			name:         "Empty Chat Message",
			message:      "",
			token:        fanToken,
			expectedCode: 400,
			expectError:  true,
			description:  "Empty messages should be rejected",
		},
		{
			name:         "Long Chat Message",
			message:      string(make([]byte, 1000)),
			token:        fanToken,
			expectedCode: 400,
			expectError:  true,
			description:  "Overly long messages should be rejected",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			chatData := map[string]interface{}{
				"message": tt.message,
			}

			recorder := suite.MakeRequest("POST", "/streams/"+streamID+"/chat", chatData, tt.token)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				assert.Contains(t, response, "message")
				messageData := response["message"].(map[string]interface{})
				assert.Equal(t, tt.message, messageData["content"])
				assert.Contains(t, messageData, "username")
				assert.Contains(t, messageData, "timestamp")
			}
		})
	}

	t.Run("Get Chat History", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/streams/"+streamID+"/chat", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "messages")
		messages := response["messages"].([]interface{})
		assert.GreaterOrEqual(t, len(messages), 2) // At least the valid messages we sent
	})

	t.Run("Moderate Chat", func(t *testing.T) {
		// Send a message first
		chatData := map[string]interface{}{
			"message": "This message will be deleted",
		}
		recorder := suite.MakeRequest("POST", "/streams/"+streamID+"/chat", chatData, fanToken)
		require.Equal(t, 200, recorder.Code)

		var chatResponse map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &chatResponse)
		message := chatResponse["message"].(map[string]interface{})
		messageID := message["id"].(string)

		// Creator moderates the message
		recorder = suite.MakeRequest("DELETE", "/streams/"+streamID+"/chat/"+messageID, nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Message deleted", response["message"])
	})
}

func TestStreamingServiceRecording(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	// Create stream
	streamData := map[string]interface{}{
		"title":            "Recorded Stream",
		"description":      "Stream that will be recorded",
		"enableRecording": true,
	}

	recorder = suite.MakeRequest("POST", "/streams", streamData, creatorToken)
	require.Equal(t, 201, recorder.Code)

	var streamResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &streamResponse)
	stream := streamResponse["stream"].(map[string]interface{})
	streamID := stream["id"].(string)

	t.Run("Start Recording", func(t *testing.T) {
		recorder := suite.MakeRequest("POST", "/streams/"+streamID+"/recording/start", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "recordingId")
		assert.Contains(t, response, "status")
		assert.Equal(t, "recording", response["status"])
	})

	t.Run("Stop Recording", func(t *testing.T) {
		recorder := suite.MakeRequest("POST", "/streams/"+streamID+"/recording/stop", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "recordingId")
		assert.Contains(t, response, "status")
		assert.Contains(t, response, "duration")
		assert.Equal(t, "completed", response["status"])
	})

	t.Run("Get Recordings", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/recordings", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "recordings")
		recordings := response["recordings"].([]interface{})
		assert.GreaterOrEqual(t, len(recordings), 1)

		recording := recordings[0].(map[string]interface{})
		assert.Contains(t, recording, "id")
		assert.Contains(t, recording, "streamId")
		assert.Contains(t, recording, "duration")
		assert.Contains(t, recording, "fileUrl")
	})
}

func TestStreamingServiceAnalytics(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	t.Run("Get Stream Analytics", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/analytics/streams", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "totalStreams")
		assert.Contains(t, response, "totalViewTime")
		assert.Contains(t, response, "averageViewers")
		assert.Contains(t, response, "peakViewers")
		assert.Contains(t, response, "revenueFromStreams")
	})

	t.Run("Get Viewer Analytics", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/analytics/viewers", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "uniqueViewers")
		assert.Contains(t, response, "returningViewers")
		assert.Contains(t, response, "averageWatchTime")
		assert.Contains(t, response, "viewersByCountry")
		assert.Contains(t, response, "viewersByDevice")
	})

	t.Run("Get Stream Performance", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/analytics/performance", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "averageBitrate")
		assert.Contains(t, response, "bufferingRatio")
		assert.Contains(t, response, "dropoutRate")
		assert.Contains(t, response, "qualityDistribution")
		assert.Contains(t, response, "networkStats")
	})
}