package unit

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/shopspring/decimal"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
	"github.com/fanz-os/testing/fixtures"
)

func TestPaymentServiceSubscriptions(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator and fan users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	// Set creator subscription price
	priceData := map[string]interface{}{
		"subscriptionPrice": 19.99,
	}
	recorder := suite.MakeRequest("PUT", "/users/profile", priceData, creatorToken)
	require.Equal(t, 200, recorder.Code)

	tests := []struct {
		name         string
		endpoint     string
		method       string
		payload      map[string]interface{}
		token        string
		expectedCode int
		expectError  bool
		description  string
	}{
		{
			name:     "Create Subscription",
			endpoint: "/subscriptions",
			method:   "POST",
			payload: map[string]interface{}{
				"creatorId":     creatorUser["username"],
				"paymentMethod": "credit_card",
			},
			token:        fanToken,
			expectedCode: 201,
			expectError:  false,
			description:  "Fan should be able to subscribe to creator",
		},
		{
			name:     "Get Active Subscriptions",
			endpoint: "/subscriptions/active",
			method:   "GET",
			payload:  nil,
			token:    fanToken,
			expectedCode: 200,
			expectError:  false,
			description:  "Fan should be able to view active subscriptions",
		},
		{
			name:     "Get Subscription Earnings",
			endpoint: "/subscriptions/earnings",
			method:   "GET",
			payload:  nil,
			token:    creatorToken,
			expectedCode: 200,
			expectError:  false,
			description:  "Creator should be able to view subscription earnings",
		},
		{
			name:     "Subscribe to Self",
			endpoint: "/subscriptions",
			method:   "POST",
			payload: map[string]interface{}{
				"creatorId":     creatorUser["username"],
				"paymentMethod": "credit_card",
			},
			token:        creatorToken,
			expectedCode: 400,
			expectError:  true,
			description:  "Creator should not be able to subscribe to themselves",
		},
		{
			name:     "Subscribe Without Payment Method",
			endpoint: "/subscriptions",
			method:   "POST",
			payload: map[string]interface{}{
				"creatorId": creatorUser["username"],
			},
			token:        fanToken,
			expectedCode: 400,
			expectError:  true,
			description:  "Subscription should require payment method",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			recorder := suite.MakeRequest(tt.method, tt.endpoint, tt.payload, tt.token)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				switch tt.method {
				case "POST":
					if tt.endpoint == "/subscriptions" {
						assert.Contains(t, response, "subscription")
						subscription := response["subscription"].(map[string]interface{})
						assert.Equal(t, "active", subscription["status"])
					}
				case "GET":
					if tt.endpoint == "/subscriptions/active" {
						assert.Contains(t, response, "subscriptions")
					} else if tt.endpoint == "/subscriptions/earnings" {
						assert.Contains(t, response, "earnings")
					}
				}
			}
		})
	}
}

func TestPaymentServiceTransactions(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator and fan users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	tests := []struct {
		name         string
		transactionType string
		amount       float64
		expectedCode int
		expectError  bool
		description  string
	}{
		{
			name:            "Valid Tip Transaction",
			transactionType: "tip",
			amount:          5.00,
			expectedCode:    201,
			expectError:     false,
			description:     "Valid tip should be processed",
		},
		{
			name:            "Valid PPV Purchase",
			transactionType: "ppv",
			amount:          9.99,
			expectedCode:    201,
			expectError:     false,
			description:     "Valid PPV purchase should be processed",
		},
		{
			name:            "Large Tip",
			transactionType: "tip",
			amount:          100.00,
			expectedCode:    201,
			expectError:     false,
			description:     "Large tips should be allowed",
		},
		{
			name:            "Invalid Amount - Negative",
			transactionType: "tip",
			amount:          -5.00,
			expectedCode:    400,
			expectError:     true,
			description:     "Negative amounts should be rejected",
		},
		{
			name:            "Invalid Amount - Zero",
			transactionType: "tip",
			amount:          0.00,
			expectedCode:    400,
			expectError:     true,
			description:     "Zero amounts should be rejected",
		},
		{
			name:            "Invalid Amount - Too Small",
			transactionType: "tip",
			amount:          0.01,
			expectedCode:    400,
			expectError:     true,
			description:     "Amounts below minimum should be rejected",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			transactionData := map[string]interface{}{
				"creatorId":     creatorUser["username"],
				"type":          tt.transactionType,
				"amount":        tt.amount,
				"paymentMethod": "credit_card",
			}

			recorder := suite.MakeRequest("POST", "/transactions", transactionData, fanToken)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				assert.Contains(t, response, "transaction")
				
				transaction := response["transaction"].(map[string]interface{})
				assert.Equal(t, tt.transactionType, transaction["type"])
				assert.Equal(t, tt.amount, transaction["amount"])
				assert.Equal(t, "pending", transaction["status"]) // Initially pending
			}
		})
	}
}

func TestPaymentServiceWallet(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	t.Run("Get Wallet Balance", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/wallet/balance", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "balance")
		assert.Contains(t, response, "pendingBalance")
		assert.Contains(t, response, "totalEarnings")
	})

	t.Run("Get Wallet Transactions", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/wallet/transactions", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "transactions")
		assert.Contains(t, response, "pagination")
	})

	t.Run("Request Withdrawal", func(t *testing.T) {
		// First, add some balance to the user (simulate earnings)
		// This would normally be done through completed transactions
		
		withdrawalData := map[string]interface{}{
			"amount":        50.00,
			"paymentMethod": "bank_transfer",
			"accountInfo": map[string]interface{}{
				"accountNumber": "1234567890",
				"routingNumber": "987654321",
			},
		}

		recorder := suite.MakeRequest("POST", "/withdrawals", withdrawalData, creatorToken)
		// This might return 400 if insufficient balance, which is expected for new accounts
		assert.True(t, recorder.Code == 201 || recorder.Code == 400)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		if recorder.Code == 201 {
			assert.Contains(t, response, "withdrawal")
		} else {
			assert.Contains(t, response, "error")
			assert.Contains(t, response["error"], "insufficient")
		}
	})

	t.Run("Get Withdrawal History", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/withdrawals", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "withdrawals")
		assert.Contains(t, response, "pagination")
	})
}

func TestPaymentServiceWebhooks(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	tests := []struct {
		name         string
		provider     string
		payload      map[string]interface{}
		headers      map[string]string
		expectedCode int
		description  string
	}{
		{
			name:     "Stripe Payment Success",
			provider: "stripe",
			payload: map[string]interface{}{
				"type": "payment_intent.succeeded",
				"data": map[string]interface{}{
					"object": map[string]interface{}{
						"id":     "pi_test_payment",
						"amount": 1999,
						"status": "succeeded",
						"metadata": map[string]interface{}{
							"user_id":        "user-123",
							"transaction_id": "txn-456",
						},
					},
				},
			},
			headers: map[string]string{
				"Stripe-Signature": "test_signature",
			},
			expectedCode: 200,
			description:  "Valid Stripe webhook should be processed",
		},
		{
			name:     "Stripe Payment Failed",
			provider: "stripe",
			payload: map[string]interface{}{
				"type": "payment_intent.payment_failed",
				"data": map[string]interface{}{
					"object": map[string]interface{}{
						"id":     "pi_test_failed",
						"status": "requires_payment_method",
						"metadata": map[string]interface{}{
							"user_id":        "user-123",
							"transaction_id": "txn-789",
						},
					},
				},
			},
			headers: map[string]string{
				"Stripe-Signature": "test_signature",
			},
			expectedCode: 200,
			description:  "Failed payment webhook should be handled",
		},
		{
			name:     "Invalid Signature",
			provider: "stripe",
			payload: map[string]interface{}{
				"type": "payment_intent.succeeded",
				"data": map[string]interface{}{},
			},
			headers: map[string]string{
				"Stripe-Signature": "invalid_signature",
			},
			expectedCode: 400,
			description:  "Invalid webhook signature should be rejected",
		},
		{
			name:     "Unknown Event Type",
			provider: "stripe",
			payload: map[string]interface{}{
				"type": "unknown.event.type",
				"data": map[string]interface{}{},
			},
			headers: map[string]string{
				"Stripe-Signature": "test_signature",
			},
			expectedCode: 200,
			description:  "Unknown events should be acknowledged but ignored",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			endpoint := "/webhooks/" + tt.provider
			
			recorder := suite.MakeRequest("POST", endpoint, tt.payload)
			
			// Add headers
			for key, value := range tt.headers {
				recorder.Result().Header.Set(key, value)
			}

			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectedCode == 200 {
				assert.Contains(t, response, "received")
			} else {
				assert.Contains(t, response, "error")
			}
		})
	}
}

func TestPaymentServiceRefunds(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")
	adminUser := suite.CreateTestUser("admin")

	for _, user := range []map[string]interface{}{creatorUser, fanUser, adminUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))
	adminToken := suite.LoginUser(adminUser["email"].(string), adminUser["password"].(string))

	// Create a transaction first
	transactionData := map[string]interface{}{
		"creatorId":     creatorUser["username"],
		"type":          "tip",
		"amount":        10.00,
		"paymentMethod": "credit_card",
	}

	recorder := suite.MakeRequest("POST", "/transactions", transactionData, fanToken)
	require.Equal(t, 201, recorder.Code)

	var transactionResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &transactionResponse)
	transaction := transactionResponse["transaction"].(map[string]interface{})
	transactionID := transaction["id"].(string)

	tests := []struct {
		name         string
		transactionId string
		requester    string
		token        string
		expectedCode int
		expectError  bool
		description  string
	}{
		{
			name:          "Fan Request Refund",
			transactionId: transactionID,
			requester:     "fan",
			token:         fanToken,
			expectedCode:  201,
			expectError:   false,
			description:   "Fan should be able to request refund for their transaction",
		},
		{
			name:          "Admin Process Refund",
			transactionId: transactionID,
			requester:     "admin",
			token:         adminToken,
			expectedCode:  200,
			expectError:   false,
			description:   "Admin should be able to process refunds",
		},
		{
			name:          "Creator Cannot Refund Others",
			transactionId: transactionID,
			requester:     "other",
			token:         creatorToken,
			expectedCode:  403,
			expectError:   true,
			description:   "Creator should not be able to refund transactions they didn't make",
		},
		{
			name:          "Refund Non-existent Transaction",
			transactionId: "non-existent-id",
			requester:     "fan",
			token:         fanToken,
			expectedCode:  404,
			expectError:   true,
			description:   "Should return 404 for non-existent transactions",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var endpoint string
			if tt.requester == "admin" {
				endpoint = "/admin/refunds/" + tt.transactionId + "/approve"
			} else {
				endpoint = "/refunds/" + tt.transactionId
			}

			method := "POST"
			if tt.requester == "admin" {
				method = "PUT"
			}

			recorder := suite.MakeRequest(method, endpoint, nil, tt.token)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				if tt.requester == "fan" {
					assert.Contains(t, response, "refundRequest")
				} else {
					assert.Contains(t, response, "refund")
				}
			}
		})
	}
}

func TestPaymentServiceAnalytics(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create creator user
	creatorUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/auth/register", creatorUser)
	require.Equal(t, 201, recorder.Code)
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	t.Run("Get Revenue Analytics", func(t *testing.T) {
		endpoint := "/analytics/revenue?period=30days"
		recorder := suite.MakeRequest("GET", endpoint, nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "totalRevenue")
		assert.Contains(t, response, "subscriptionRevenue")
		assert.Contains(t, response, "tipRevenue")
		assert.Contains(t, response, "ppvRevenue")
		assert.Contains(t, response, "dailyBreakdown")
	})

	t.Run("Get Subscriber Analytics", func(t *testing.T) {
		endpoint := "/analytics/subscribers"
		recorder := suite.MakeRequest("GET", endpoint, nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "totalSubscribers")
		assert.Contains(t, response, "newSubscribers")
		assert.Contains(t, response, "churnedSubscribers")
		assert.Contains(t, response, "retentionRate")
	})

	t.Run("Get Payment Method Analytics", func(t *testing.T) {
		endpoint := "/analytics/payment-methods"
		recorder := suite.MakeRequest("GET", endpoint, nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "paymentMethods")
		
		methods := response["paymentMethods"].([]interface{})
		for _, method := range methods {
			methodData := method.(map[string]interface{})
			assert.Contains(t, methodData, "method")
			assert.Contains(t, methodData, "count")
			assert.Contains(t, methodData, "totalAmount")
		}
	})
}