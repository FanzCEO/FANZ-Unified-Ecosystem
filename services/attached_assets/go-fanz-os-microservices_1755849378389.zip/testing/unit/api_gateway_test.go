package unit

import (
	"encoding/json"
	"net/http"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
	"github.com/fanz-os/testing/mocks"
)

func TestAPIGatewayRouting(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Setup mock services
	userService := mocks.NewMockUserService()
	contentService := mocks.NewMockContentService()
	paymentService := mocks.NewMockPaymentService()
	defer func() {
		userService.Close()
		contentService.Close()
		paymentService.Close()
	}()

	tests := []struct {
		name         string
		method       string
		path         string
		expectedCode int
		targetService string
		description  string
	}{
		{
			name:          "Route to User Service - Health Check",
			method:        "GET",
			path:          "/api/users/health",
			expectedCode:  200,
			targetService: "user-service",
			description:   "Should route health checks to user service",
		},
		{
			name:          "Route to Content Service - Posts",
			method:        "GET",
			path:          "/api/content/posts",
			expectedCode:  200,
			targetService: "content-service",
			description:   "Should route post requests to content service",
		},
		{
			name:          "Route to Payment Service - Transactions",
			method:        "GET",
			path:          "/api/payments/transactions",
			expectedCode:  401, // No auth token
			targetService: "payment-service",
			description:   "Should route payment requests to payment service",
		},
		{
			name:          "Invalid Route",
			method:        "GET",
			path:          "/api/invalid/endpoint",
			expectedCode:  404,
			targetService: "none",
			description:   "Should return 404 for invalid routes",
		},
		{
			name:          "Root Health Check",
			method:        "GET",
			path:          "/health",
			expectedCode:  200,
			targetService: "gateway",
			description:   "Gateway should handle its own health check",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			recorder := suite.MakeRequest(tt.method, tt.path, nil)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			if tt.expectedCode == 200 {
				var response map[string]interface{}
				err := json.Unmarshal(recorder.Body.Bytes(), &response)
				require.NoError(t, err)
				
				if tt.targetService != "none" {
					assert.Contains(t, response, "status")
					assert.Equal(t, "healthy", response["status"])
				}
			}
		})
	}
}

func TestAPIGatewayAuthentication(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create test user and get token
	testUser := suite.CreateTestUser("creator")
	recorder := suite.MakeRequest("POST", "/api/auth/register", testUser)
	require.Equal(t, 201, recorder.Code)

	token := suite.LoginUser(testUser["email"].(string), testUser["password"].(string))

	tests := []struct {
		name         string
		endpoint     string
		method       string
		token        string
		expectedCode int
		description  string
	}{
		{
			name:         "Valid Token Access",
			endpoint:     "/api/users/profile",
			method:       "GET",
			token:        token,
			expectedCode: 200,
			description:  "Valid token should allow access to protected endpoints",
		},
		{
			name:         "No Token Access",
			endpoint:     "/api/users/profile",
			method:       "GET",
			token:        "",
			expectedCode: 401,
			description:  "No token should be rejected",
		},
		{
			name:         "Invalid Token Access",
			endpoint:     "/api/users/profile",
			method:       "GET",
			token:        "invalid.jwt.token",
			expectedCode: 401,
			description:  "Invalid token should be rejected",
		},
		{
			name:         "Expired Token Access",
			endpoint:     "/api/users/profile",
			method:       "GET",
			token:        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.expired.token",
			expectedCode: 401,
			description:  "Expired token should be rejected",
		},
		{
			name:         "Public Endpoint No Auth Required",
			endpoint:     "/api/content/posts/public",
			method:       "GET",
			token:        "",
			expectedCode: 200,
			description:  "Public endpoints should not require authentication",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			var recorder *http.ResponseRecorder
			if tt.token != "" {
				recorder = suite.MakeRequest(tt.method, tt.endpoint, nil, tt.token)
			} else {
				recorder = suite.MakeRequest(tt.method, tt.endpoint, nil)
			}
			
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)
		})
	}
}

func TestAPIGatewayRateLimiting(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	endpoint := "/api/auth/login"
	loginData := map[string]interface{}{
		"email":    "test@test.com",
		"password": "wrong_password",
	}

	// Test rate limiting
	var successCount, rateLimitedCount int

	for i := 0; i < 50; i++ {
		recorder := suite.MakeRequest("POST", endpoint, loginData)
		if recorder.Code == 401 {
			successCount++
		} else if recorder.Code == 429 {
			rateLimitedCount++
		}
		time.Sleep(5 * time.Millisecond)
	}

	assert.True(t, rateLimitedCount > 0, "Rate limiting should kick in after multiple requests")
	assert.True(t, successCount > 0, "Some requests should get through before rate limiting")
}

func TestAPIGatewayCORS(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Test CORS preflight request
	recorder := suite.MakeRequest("OPTIONS", "/api/users/profile", nil)
	assert.Equal(t, 200, recorder.Code)

	// Check CORS headers
	headers := recorder.Header()
	assert.Contains(t, headers, "Access-Control-Allow-Origin")
	assert.Contains(t, headers, "Access-Control-Allow-Methods")
	assert.Contains(t, headers, "Access-Control-Allow-Headers")
}

func TestAPIGatewayErrorHandling(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	tests := []struct {
		name         string
		endpoint     string
		method       string
		payload      interface{}
		expectedCode int
		description  string
	}{
		{
			name:         "Invalid JSON Payload",
			endpoint:     "/api/auth/register",
			method:       "POST",
			payload:      "invalid json",
			expectedCode: 400,
			description:  "Invalid JSON should return bad request",
		},
		{
			name:         "Method Not Allowed",
			endpoint:     "/api/users/profile",
			method:       "PATCH", // Not supported
			payload:      nil,
			expectedCode: 405,
			description:  "Unsupported HTTP methods should return method not allowed",
		},
		{
			name:         "Large Payload",
			endpoint:     "/api/content/posts",
			method:       "POST",
			payload:      map[string]interface{}{"content": string(make([]byte, 10*1024*1024))}, // 10MB
			expectedCode: 413,
			description:  "Oversized payloads should be rejected",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			recorder := suite.MakeRequest(tt.method, tt.endpoint, tt.payload)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			json.Unmarshal(recorder.Body.Bytes(), &response)
			assert.Contains(t, response, "error")
		})
	}
}

func TestAPIGatewayServiceDiscovery(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Test service health endpoint
	recorder := suite.MakeRequest("GET", "/api/services/health", nil)
	assert.Equal(t, 200, recorder.Code)

	var response map[string]interface{}
	err := json.Unmarshal(recorder.Body.Bytes(), &response)
	require.NoError(t, err)

	services := response["services"].(map[string]interface{})
	expectedServices := []string{
		"user-service",
		"content-service", 
		"payment-service",
		"streaming-service",
		"messaging-service",
		"admin-service",
		"ai-service",
	}

	for _, serviceName := range expectedServices {
		assert.Contains(t, services, serviceName)
		service := services[serviceName].(map[string]interface{})
		assert.Contains(t, service, "status")
		assert.Contains(t, service, "url")
		assert.Contains(t, service, "lastCheck")
	}
}

func TestAPIGatewayLoadBalancing(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Test multiple requests are distributed (round-robin simulation)
	endpoint := "/api/users/health"
	
	var responses []string
	for i := 0; i < 10; i++ {
		recorder := suite.MakeRequest("GET", endpoint, nil)
		assert.Equal(t, 200, recorder.Code)
		
		// In a real scenario, different instances might return slightly different data
		// For testing, we'll check that all requests are successful
		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		responses = append(responses, response["status"].(string))
	}

	// All requests should be successful
	for _, status := range responses {
		assert.Equal(t, "healthy", status)
	}
}

func TestAPIGatewayMetrics(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Make some requests to generate metrics
	endpoints := []string{
		"/api/users/health",
		"/api/content/posts",
		"/api/payments/health",
	}

	for _, endpoint := range endpoints {
		for i := 0; i < 5; i++ {
			suite.MakeRequest("GET", endpoint, nil)
		}
	}

	// Check metrics endpoint
	recorder := suite.MakeRequest("GET", "/api/metrics", nil)
	assert.Equal(t, 200, recorder.Code)

	var response map[string]interface{}
	err := json.Unmarshal(recorder.Body.Bytes(), &response)
	require.NoError(t, err)

	assert.Contains(t, response, "totalRequests")
	assert.Contains(t, response, "requestsByService")
	assert.Contains(t, response, "averageResponseTime")
	assert.Contains(t, response, "errorRate")

	// Verify we have metrics for the requests we made
	totalRequests := response["totalRequests"].(float64)
	assert.True(t, totalRequests >= 15) // At least 3 endpoints * 5 requests each
}