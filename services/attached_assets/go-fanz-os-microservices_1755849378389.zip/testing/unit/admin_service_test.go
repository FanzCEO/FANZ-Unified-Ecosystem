package unit

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
)

func TestAdminServiceUserManagement(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	adminUser := suite.CreateTestUser("admin")
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	for _, user := range []map[string]interface{}{adminUser, creatorUser, fanUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	adminToken := suite.LoginUser(adminUser["email"].(string), adminUser["password"].(string))
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	tests := []struct {
		name         string
		endpoint     string
		method       string
		payload      map[string]interface{}
		token        string
		expectedCode int
		expectError  bool
		description  string
	}{
		{
			name:         "Admin Get All Users",
			endpoint:     "/admin/users",
			method:       "GET",
			payload:      nil,
			token:        adminToken,
			expectedCode: 200,
			expectError:  false,
			description:  "Admin should be able to get all users",
		},
		{
			name:         "Admin Search Users",
			endpoint:     "/admin/users/search?query=creator",
			method:       "GET",
			payload:      nil,
			token:        adminToken,
			expectedCode: 200,
			expectError:  false,
			description:  "Admin should be able to search users",
		},
		{
			name:         "Admin Suspend User",
			endpoint:     "/admin/users/" + creatorUser["username"].(string) + "/suspend",
			method:       "PUT",
			payload: map[string]interface{}{
				"reason":   "Policy violation",
				"duration": 7, // days
			},
			token:        adminToken,
			expectedCode: 200,
			expectError:  false,
			description:  "Admin should be able to suspend users",
		},
		{
			name:         "Admin Unsuspend User",
			endpoint:     "/admin/users/" + creatorUser["username"].(string) + "/unsuspend",
			method:       "PUT",
			payload:      nil,
			token:        adminToken,
			expectedCode: 200,
			expectError:  false,
			description:  "Admin should be able to unsuspend users",
		},
		{
			name:         "Creator Cannot Access Admin Endpoint",
			endpoint:     "/admin/users",
			method:       "GET",
			payload:      nil,
			token:        creatorToken,
			expectedCode: 403,
			expectError:  true,
			description:  "Non-admin users should not access admin endpoints",
		},
		{
			name:         "Admin Verify Creator",
			endpoint:     "/admin/users/" + creatorUser["username"].(string) + "/verify",
			method:       "PUT",
			payload: map[string]interface{}{
				"verified": true,
			},
			token:        adminToken,
			expectedCode: 200,
			expectError:  false,
			description:  "Admin should be able to verify creators",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			recorder := suite.MakeRequest(tt.method, tt.endpoint, tt.payload, tt.token)
			assert.Equal(t, tt.expectedCode, recorder.Code, tt.description)

			var response map[string]interface{}
			err := json.Unmarshal(recorder.Body.Bytes(), &response)
			require.NoError(t, err)

			if tt.expectError {
				assert.Contains(t, response, "error")
			} else {
				switch tt.endpoint {
				case "/admin/users":
					assert.Contains(t, response, "users")
					assert.Contains(t, response, "pagination")
				default:
					if tt.method == "PUT" {
						assert.Contains(t, response, "message")
					}
				}
			}
		})
	}
}

func TestAdminServiceContentModeration(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create admin and creator
	adminUser := suite.CreateTestUser("admin")
	creatorUser := suite.CreateTestUser("creator")

	for _, user := range []map[string]interface{}{adminUser, creatorUser} {
		recorder := suite.MakeRequest("POST", "/auth/register", user)
		require.Equal(t, 201, recorder.Code)
	}

	adminToken := suite.LoginUser(adminUser["email"].(string), adminUser["password"].(string))
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))

	// Create test content
	postData := map[string]interface{}{
		"content":    "This post will be moderated",
		"visibility": "public",
		"isPpv":      false,
	}

	recorder := suite.MakeRequest("POST", "/posts", postData, creatorToken)
	require.Equal(t, 201, recorder.Code)

	var postResponse map[string]interface{}
	json.Unmarshal(recorder.Body.Bytes(), &postResponse)
	post := postResponse["post"].(map[string]interface{})
	postID := post["id"].(string)

	t.Run("Get Reported Content", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/content/reported", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "reports")
		assert.Contains(t, response, "pagination")
	})

	t.Run("Approve Content", func(t *testing.T) {
		approvalData := map[string]interface{}{
			"status": "approved",
			"notes":  "Content is appropriate",
		}

		recorder := suite.MakeRequest("PUT", "/admin/content/"+postID+"/moderate", approvalData, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Content moderated successfully", response["message"])
	})

	t.Run("Remove Content", func(t *testing.T) {
		removalData := map[string]interface{}{
			"status": "removed",
			"reason": "Policy violation",
			"notes":  "Violates community guidelines",
		}

		recorder := suite.MakeRequest("PUT", "/admin/content/"+postID+"/moderate", removalData, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Content moderated successfully", response["message"])
	})

	t.Run("Get Moderation History", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/content/"+postID+"/history", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "history")
		history := response["history"].([]interface{})
		assert.GreaterOrEqual(t, len(history), 1) // At least one moderation action
	})
}

func TestAdminServiceCompliance(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create admin user
	adminUser := suite.CreateTestUser("admin")
	recorder := suite.MakeRequest("POST", "/auth/register", adminUser)
	require.Equal(t, 201, recorder.Code)
	adminToken := suite.LoginUser(adminUser["email"].(string), adminUser["password"].(string))

	t.Run("Get 2257 Compliance Records", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/compliance/2257", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "records")
		assert.Contains(t, response, "totalRecords")
		assert.Contains(t, response, "compliantPercentage")
	})

	t.Run("Update Compliance Record", func(t *testing.T) {
		updateData := map[string]interface{}{
			"performerId":      "performer-123",
			"documentType":     "drivers_license",
			"verificationDate": "2024-01-01",
			"expirationDate":   "2029-01-01",
			"status":           "verified",
		}

		recorder := suite.MakeRequest("PUT", "/admin/compliance/2257/performer-123", updateData, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Compliance record updated", response["message"])
	})

	t.Run("Generate Compliance Report", func(t *testing.T) {
		reportData := map[string]interface{}{
			"startDate": "2024-01-01",
			"endDate":   "2024-12-31",
			"format":    "pdf",
		}

		recorder := suite.MakeRequest("POST", "/admin/compliance/reports", reportData, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "reportId")
		assert.Contains(t, response, "downloadUrl")
		assert.Equal(t, "generating", response["status"])
	})

	t.Run("Get Geographic Restrictions", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/compliance/geo-restrictions", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "restrictions")
		restrictions := response["restrictions"].([]interface{})
		assert.IsType(t, []interface{}{}, restrictions)
	})

	t.Run("Update Geographic Restrictions", func(t *testing.T) {
		restrictionData := map[string]interface{}{
			"country": "US",
			"states":  []string{"TX", "UT"},
			"action":  "block",
			"reason":  "Legal compliance",
		}

		recorder := suite.MakeRequest("PUT", "/admin/compliance/geo-restrictions", restrictionData, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "Geographic restrictions updated", response["message"])
	})
}

func TestAdminServiceAnalytics(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create admin user
	adminUser := suite.CreateTestUser("admin")
	recorder := suite.MakeRequest("POST", "/auth/register", adminUser)
	require.Equal(t, 201, recorder.Code)
	adminToken := suite.LoginUser(adminUser["email"].(string), adminUser["password"].(string))

	t.Run("Get Platform Analytics", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/analytics/platform", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "totalUsers")
		assert.Contains(t, response, "activeUsers")
		assert.Contains(t, response, "totalRevenue")
		assert.Contains(t, response, "growthRate")
		assert.Contains(t, response, "conversionRate")
	})

	t.Run("Get User Analytics", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/analytics/users", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "usersByRole")
		assert.Contains(t, response, "usersByCountry")
		assert.Contains(t, response, "registrationTrends")
		assert.Contains(t, response, "retentionRates")
	})

	t.Run("Get Revenue Analytics", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/analytics/revenue?period=30days", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "totalRevenue")
		assert.Contains(t, response, "subscriptionRevenue")
		assert.Contains(t, response, "tipRevenue")
		assert.Contains(t, response, "ppvRevenue")
		assert.Contains(t, response, "revenueByCountry")
		assert.Contains(t, response, "dailyBreakdown")
	})

	t.Run("Get Content Analytics", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/analytics/content", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "totalPosts")
		assert.Contains(t, response, "contentByType")
		assert.Contains(t, response, "moderationStats")
		assert.Contains(t, response, "engagementRates")
	})

	t.Run("Get System Performance", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/analytics/system", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "responseTime")
		assert.Contains(t, response, "uptime")
		assert.Contains(t, response, "errorRate")
		assert.Contains(t, response, "throughput")
		assert.Contains(t, response, "resourceUsage")
	})
}

func TestAdminServiceSystemManagement(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create admin user
	adminUser := suite.CreateTestUser("admin")
	recorder := suite.MakeRequest("POST", "/auth/register", adminUser)
	require.Equal(t, 201, recorder.Code)
	adminToken := suite.LoginUser(adminUser["email"].(string), adminUser["password"].(string))

	t.Run("Get System Health", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/system/health", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "status")
		assert.Contains(t, response, "services")
		assert.Contains(t, response, "database")
		assert.Contains(t, response, "redis")
		assert.Contains(t, response, "storage")
	})

	t.Run("Get System Configuration", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/system/config", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "features")
		assert.Contains(t, response, "limits")
		assert.Contains(t, response, "policies")
	})

	t.Run("Update System Configuration", func(t *testing.T) {
		configData := map[string]interface{}{
			"maxFileSize":       100 * 1024 * 1024, // 100MB
			"maxVideoLength":    3600,              // 1 hour
			"enablePayments":    true,
			"maintenanceMode":   false,
			"registrationOpen":  true,
		}

		recorder := suite.MakeRequest("PUT", "/admin/system/config", configData, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Equal(t, "System configuration updated", response["message"])
	})

	t.Run("Get Audit Log", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/admin/audit?limit=50", nil, adminToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "auditLog")
		assert.Contains(t, response, "pagination")
		
		auditLog := response["auditLog"].([]interface{})
		if len(auditLog) > 0 {
			entry := auditLog[0].(map[string]interface{})
			assert.Contains(t, entry, "action")
			assert.Contains(t, entry, "userId")
			assert.Contains(t, entry, "timestamp")
			assert.Contains(t, entry, "details")
		}
	})

	t.Run("Export Platform Data", func(t *testing.T) {
		exportData := map[string]interface{}{
			"type":      "users",
			"startDate": "2024-01-01",
			"endDate":   "2024-12-31",
			"format":    "csv",
		}

		recorder := suite.MakeRequest("POST", "/admin/export", exportData, adminToken)
		assert.Equal(t, 202, recorder.Code) // Accepted for processing

		var response map[string]interface{}
		err := json.Unmarshal(recorder.Body.Bytes(), &response)
		require.NoError(t, err)

		assert.Contains(t, response, "exportId")
		assert.Contains(t, response, "status")
		assert.Equal(t, "processing", response["status"])
	})
}