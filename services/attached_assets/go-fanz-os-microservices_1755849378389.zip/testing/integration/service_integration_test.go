package integration

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	"github.com/fanz-os/testing/utils"
)

// TestFullWorkflowIntegration tests complete user workflows across services
func TestFullWorkflowIntegration(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Create users
	creatorUser := suite.CreateTestUser("creator")
	fanUser := suite.CreateTestUser("fanz")

	// Step 1: User Registration (User Service)
	t.Run("Creator Registration", func(t *testing.T) {
		recorder := suite.MakeRequest("POST", "/api/auth/register", creatorUser)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		assert.Contains(t, response, "user")
		assert.Contains(t, response, "token")
	})

	t.Run("Fan Registration", func(t *testing.T) {
		recorder := suite.MakeRequest("POST", "/api/auth/register", fanUser)
		assert.Equal(t, 201, recorder.Code)
	})

	// Get tokens
	creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
	fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

	// Step 2: Creator Setup (User Service + Content Service)
	var postID string
	t.Run("Creator Profile Setup", func(t *testing.T) {
		profileData := map[string]interface{}{
			"displayName":       "Amazing Creator",
			"bio":               "I create amazing content!",
			"subscriptionPrice": 19.99,
		}

		recorder := suite.MakeRequest("PUT", "/api/users/profile", profileData, creatorToken)
		assert.Equal(t, 200, recorder.Code)
	})

	// Step 3: Content Creation (Content Service + AI Service)
	t.Run("Create Content", func(t *testing.T) {
		postData := map[string]interface{}{
			"content":    "Welcome to my page! Here's some great content.",
			"mediaUrls":  []string{"https://example.com/image.jpg"},
			"mediaTypes": []string{"image"},
			"visibility": "public",
			"isPpv":      false,
		}

		recorder := suite.MakeRequest("POST", "/api/content/posts", postData, creatorToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		post := response["post"].(map[string]interface{})
		postID = post["id"].(string)
	})

	// Step 4: Fan Discovery and Interaction (Content Service + AI Service)
	t.Run("Fan Discovers Content", func(t *testing.T) {
		// Get personalized recommendations
		recorder := suite.MakeRequest("GET", "/api/ai/recommendations/creators", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		// View public content
		recorder = suite.MakeRequest("GET", "/api/content/posts/"+postID, nil, fanToken)
		assert.Equal(t, 200, recorder.Code)
	})

	t.Run("Fan Interacts with Content", func(t *testing.T) {
		// Like the post
		recorder := suite.MakeRequest("POST", "/api/content/posts/"+postID+"/like", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		// Add a comment
		commentData := map[string]interface{}{
			"content": "Amazing content! Love it!",
		}
		recorder = suite.MakeRequest("POST", "/api/content/posts/"+postID+"/comments", commentData, fanToken)
		assert.Equal(t, 201, recorder.Code)
	})

	// Step 5: Subscription Flow (Payment Service + User Service)
	var subscriptionID string
	t.Run("Fan Subscribes to Creator", func(t *testing.T) {
		subscriptionData := map[string]interface{}{
			"creatorId":     creatorUser["username"],
			"paymentMethod": "credit_card",
		}

		recorder := suite.MakeRequest("POST", "/api/payments/subscriptions", subscriptionData, fanToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		subscription := response["subscription"].(map[string]interface{})
		subscriptionID = subscription["id"].(string)
		assert.Equal(t, "active", subscription["status"])
	})

	// Step 6: Exclusive Content Access (Content Service + Payment Service)
	var exclusivePostID string
	t.Run("Creator Creates Subscriber-Only Content", func(t *testing.T) {
		postData := map[string]interface{}{
			"content":    "Exclusive content for my amazing subscribers!",
			"mediaUrls":  []string{"https://example.com/exclusive-video.mp4"},
			"mediaTypes": []string{"video"},
			"visibility": "subscribers",
			"isPpv":      false,
		}

		recorder := suite.MakeRequest("POST", "/api/content/posts", postData, creatorToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		post := response["post"].(map[string]interface{})
		exclusivePostID = post["id"].(string)
	})

	t.Run("Subscriber Accesses Exclusive Content", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/api/content/posts/"+exclusivePostID, nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		post := response["post"].(map[string]interface{})
		assert.Equal(t, "subscribers", post["visibility"])
		assert.NotEmpty(t, post["content"])
	})

	// Step 7: Messaging (Messaging Service)
	var messageID string
	t.Run("Fan Messages Creator", func(t *testing.T) {
		messageData := map[string]interface{}{
			"recipientId": creatorUser["username"],
			"content":     "Hi! I love your content, keep it up!",
			"messageType": "text",
		}

		recorder := suite.MakeRequest("POST", "/api/messaging/messages", messageData, fanToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		message := response["message"].(map[string]interface{})
		messageID = message["id"].(string)
	})

	t.Run("Creator Replies to Message", func(t *testing.T) {
		replyData := map[string]interface{}{
			"recipientId": fanUser["username"],
			"content":     "Thank you so much for your support! ❤️",
			"messageType": "text",
		}

		recorder := suite.MakeRequest("POST", "/api/messaging/messages", replyData, creatorToken)
		assert.Equal(t, 201, recorder.Code)
	})

	// Step 8: PPV Transaction (Messaging Service + Payment Service)
	var ppvMessageID string
	t.Run("Creator Sends PPV Message", func(t *testing.T) {
		ppvData := map[string]interface{}{
			"recipientId": fanUser["username"],
			"content":     "Special exclusive photo just for you! 📸",
			"messageType": "image",
			"mediaUrl":    "https://example.com/special-photo.jpg",
			"isPpv":       true,
			"ppvPrice":    9.99,
		}

		recorder := suite.MakeRequest("POST", "/api/messaging/messages", ppvData, creatorToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		message := response["message"].(map[string]interface{})
		ppvMessageID = message["id"].(string)
	})

	t.Run("Fan Purchases PPV Message", func(t *testing.T) {
		purchaseData := map[string]interface{}{
			"paymentMethod": "credit_card",
		}

		recorder := suite.MakeRequest("POST", "/api/messaging/messages/"+ppvMessageID+"/purchase", purchaseData, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		assert.Contains(t, response, "transaction")
		assert.Contains(t, response, "message")
	})

	// Step 9: Tipping (Payment Service)
	t.Run("Fan Tips Creator", func(t *testing.T) {
		tipData := map[string]interface{}{
			"creatorId":     creatorUser["username"],
			"type":          "tip",
			"amount":        15.00,
			"paymentMethod": "credit_card",
			"message":       "Keep up the great work!",
		}

		recorder := suite.MakeRequest("POST", "/api/payments/transactions", tipData, fanToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		transaction := response["transaction"].(map[string]interface{})
		assert.Equal(t, "tip", transaction["type"])
		assert.Equal(t, 15.00, transaction["amount"])
	})

	// Step 10: Live Streaming (Streaming Service)
	var streamID string
	t.Run("Creator Starts Live Stream", func(t *testing.T) {
		streamData := map[string]interface{}{
			"title":       "Live Q&A Session",
			"description": "Ask me anything!",
			"isPrivate":   false,
		}

		recorder := suite.MakeRequest("POST", "/api/streaming/streams", streamData, creatorToken)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		stream := response["stream"].(map[string]interface{})
		streamID = stream["id"].(string)

		// Start the stream
		recorder = suite.MakeRequest("POST", "/api/streaming/streams/"+streamID+"/start", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)
	})

	t.Run("Fan Joins Live Stream", func(t *testing.T) {
		recorder := suite.MakeRequest("POST", "/api/streaming/streams/"+streamID+"/join", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		assert.Contains(t, response, "viewerToken")
		assert.Contains(t, response, "webrtcConfig")
	})

	t.Run("Fan Sends Chat Message in Stream", func(t *testing.T) {
		chatData := map[string]interface{}{
			"message": "Great stream! Thanks for answering questions.",
		}

		recorder := suite.MakeRequest("POST", "/api/streaming/streams/"+streamID+"/chat", chatData, fanToken)
		assert.Equal(t, 200, recorder.Code)
	})

	// Step 11: Analytics and Insights (AI Service + Admin Service)
	t.Run("Creator Views Analytics", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/api/ai/insights/content-performance", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		assert.Contains(t, response, "insights")
		assert.Contains(t, response, "recommendations")
	})

	t.Run("Creator Gets Revenue Analytics", func(t *testing.T) {
		recorder := suite.MakeRequest("GET", "/api/payments/analytics/revenue?period=30days", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		assert.Contains(t, response, "totalRevenue")
		assert.Contains(t, response, "subscriptionRevenue")
		assert.Contains(t, response, "tipRevenue")
	})

	// Step 12: Notifications (Messaging Service + AI Service)
	t.Run("Check Notifications", func(t *testing.T) {
		// Creator should have notifications about new subscriber, tips, messages
		recorder := suite.MakeRequest("GET", "/api/messaging/notifications", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		assert.Contains(t, response, "notifications")
		unreadCount := response["unreadCount"].(float64)
		assert.True(t, unreadCount > 0) // Should have notifications from the workflow
	})

	// Clean up - Stop stream
	suite.MakeRequest("POST", "/api/streaming/streams/"+streamID+"/stop", nil, creatorToken)
}

func TestServiceCommunication(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	// Test inter-service communication patterns

	t.Run("API Gateway Routes to Services", func(t *testing.T) {
		// Test that API Gateway properly routes to different services
		endpoints := []struct {
			path        string
			service     string
			expectedCode int
		}{
			{"/api/users/health", "user-service", 200},
			{"/api/content/health", "content-service", 200},
			{"/api/payments/health", "payment-service", 200},
			{"/api/streaming/health", "streaming-service", 200},
			{"/api/messaging/health", "messaging-service", 200},
			{"/api/admin/health", "admin-service", 200},
			{"/api/ai/health", "ai-service", 200},
		}

		for _, endpoint := range endpoints {
			recorder := suite.MakeRequest("GET", endpoint.path, nil)
			assert.Equal(t, endpoint.expectedCode, recorder.Code, 
				"Service %s should be reachable via API Gateway", endpoint.service)
		}
	})

	t.Run("Service Dependencies", func(t *testing.T) {
		// Create test user for dependency testing
		testUser := suite.CreateTestUser("creator")
		recorder := suite.MakeRequest("POST", "/api/auth/register", testUser)
		require.Equal(t, 201, recorder.Code)
		
		token := suite.LoginUser(testUser["email"].(string), testUser["password"].(string))

		// Test that Content Service can validate user through User Service
		postData := map[string]interface{}{
			"content":    "Testing service dependencies",
			"visibility": "public",
		}

		recorder = suite.MakeRequest("POST", "/api/content/posts", postData, token)
		assert.Equal(t, 201, recorder.Code)

		// Test that Payment Service can validate user through User Service
		transactionData := map[string]interface{}{
			"creatorId":     testUser["username"],
			"type":          "tip",
			"amount":        5.00,
			"paymentMethod": "credit_card",
		}

		recorder = suite.MakeRequest("POST", "/api/payments/transactions", transactionData, token)
		assert.True(t, recorder.Code == 201 || recorder.Code == 400) // May fail due to self-transaction
	})

	t.Run("Event-Driven Communication", func(t *testing.T) {
		// Test that events are properly communicated between services
		// For example, when a user subscribes, multiple services should be notified

		creatorUser := suite.CreateTestUser("creator")
		fanUser := suite.CreateTestUser("fanz")

		for _, user := range []map[string]interface{}{creatorUser, fanUser} {
			recorder := suite.MakeRequest("POST", "/api/auth/register", user)
			require.Equal(t, 201, recorder.Code)
		}

		creatorToken := suite.LoginUser(creatorUser["email"].(string), creatorUser["password"].(string))
		fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

		// Set subscription price
		profileData := map[string]interface{}{
			"subscriptionPrice": 19.99,
		}
		suite.MakeRequest("PUT", "/api/users/profile", profileData, creatorToken)

		// Create subscription
		subscriptionData := map[string]interface{}{
			"creatorId":     creatorUser["username"],
			"paymentMethod": "credit_card",
		}

		recorder := suite.MakeRequest("POST", "/api/payments/subscriptions", subscriptionData, fanToken)
		assert.Equal(t, 201, recorder.Code)

		// Wait for event propagation
		time.Sleep(1 * time.Second)

		// Check that User Service updated subscriber count
		recorder = suite.MakeRequest("GET", "/api/users/profile", nil, creatorToken)
		assert.Equal(t, 200, recorder.Code)

		// Check that Messaging Service can access subscription status
		messageData := map[string]interface{}{
			"recipientId": creatorUser["username"],
			"content":     "Thanks for the great content!",
			"messageType": "text",
		}

		recorder = suite.MakeRequest("POST", "/api/messaging/messages", messageData, fanToken)
		assert.Equal(t, 201, recorder.Code)
	})

	t.Run("Cross-Service Data Consistency", func(t *testing.T) {
		// Test that data remains consistent across services
		testUser := suite.CreateTestUser("creator")
		recorder := suite.MakeRequest("POST", "/api/auth/register", testUser)
		require.Equal(t, 201, recorder.Code)
		
		token := suite.LoginUser(testUser["email"].(string), testUser["password"].(string))

		// Update profile in User Service
		profileData := map[string]interface{}{
			"displayName": "Updated Creator Name",
		}

		recorder = suite.MakeRequest("PUT", "/api/users/profile", profileData, token)
		assert.Equal(t, 200, recorder.Code)

		// Check that the update is reflected in other services
		// Create content and verify creator name
		postData := map[string]interface{}{
			"content":    "Test post for consistency",
			"visibility": "public",
		}

		recorder = suite.MakeRequest("POST", "/api/content/posts", postData, token)
		assert.Equal(t, 201, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		post := response["post"].(map[string]interface{})
		
		// The post should reference the updated creator information
		assert.Contains(t, post, "creatorId")
	})
}

func TestErrorHandlingAcrossServices(t *testing.T) {
	suite := utils.NewTestSuite(t)
	defer suite.Teardown()

	t.Run("Graceful Service Failures", func(t *testing.T) {
		// Test behavior when dependent services are unavailable
		// This would require mocking service unavailability
		
		testUser := suite.CreateTestUser("creator")
		recorder := suite.MakeRequest("POST", "/api/auth/register", testUser)
		require.Equal(t, 201, recorder.Code)
		
		token := suite.LoginUser(testUser["email"].(string), testUser["password"].(string))

		// Test requests that depend on multiple services
		postData := map[string]interface{}{
			"content":    "Test post with potential service failures",
			"visibility": "public",
		}

		recorder = suite.MakeRequest("POST", "/api/content/posts", postData, token)
		// Should either succeed or fail gracefully with proper error message
		assert.True(t, recorder.Code == 201 || recorder.Code >= 500)

		if recorder.Code >= 500 {
			var response map[string]interface{}
			json.Unmarshal(recorder.Body.Bytes(), &response)
			assert.Contains(t, response, "error")
		}
	})

	t.Run("Transaction Rollback", func(t *testing.T) {
		// Test that failed transactions are properly rolled back
		creatorUser := suite.CreateTestUser("creator")
		fanUser := suite.CreateTestUser("fanz")

		for _, user := range []map[string]interface{}{creatorUser, fanUser} {
			recorder := suite.MakeRequest("POST", "/api/auth/register", user)
			require.Equal(t, 201, recorder.Code)
		}

		fanToken := suite.LoginUser(fanUser["email"].(string), fanUser["password"].(string))

		// Attempt transaction with invalid data
		transactionData := map[string]interface{}{
			"creatorId":     "nonexistent-creator",
			"type":          "subscription",
			"amount":        -10.00, // Invalid amount
			"paymentMethod": "invalid_method",
		}

		recorder := suite.MakeRequest("POST", "/api/payments/transactions", transactionData, fanToken)
		assert.True(t, recorder.Code >= 400)

		// Verify that no partial transaction was created
		recorder = suite.MakeRequest("GET", "/api/payments/wallet/transactions", nil, fanToken)
		assert.Equal(t, 200, recorder.Code)

		var response map[string]interface{}
		json.Unmarshal(recorder.Body.Bytes(), &response)
		transactions := response["transactions"].([]interface{})
		
		// Should not contain the failed transaction
		for _, txn := range transactions {
			transaction := txn.(map[string]interface{})
			assert.NotEqual(t, "invalid_method", transaction["paymentMethod"])
		}
	})

	t.Run("Circuit Breaker Pattern", func(t *testing.T) {
		// Test circuit breaker behavior under high failure rates
		testUser := suite.CreateTestUser("creator")
		recorder := suite.MakeRequest("POST", "/api/auth/register", testUser)
		require.Equal(t, 201, recorder.Code)
		
		token := suite.LoginUser(testUser["email"].(string), testUser["password"].(string))

		// Make multiple failing requests to trigger circuit breaker
		failingData := map[string]interface{}{
			"invalid": "data that should cause failures",
		}

		failureCount := 0
		for i := 0; i < 10; i++ {
			recorder = suite.MakeRequest("POST", "/api/content/posts", failingData, token)
			if recorder.Code >= 400 {
				failureCount++
			}
			time.Sleep(100 * time.Millisecond)
		}

		// Should have multiple failures
		assert.True(t, failureCount > 5)

		// After circuit breaker opens, should get different error codes
		recorder = suite.MakeRequest("POST", "/api/content/posts", failingData, token)
		// Circuit breaker might return 503 Service Unavailable
		assert.True(t, recorder.Code >= 400)
	})
}