package utils

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	_ "github.com/lib/pq"
)

// TestConfig holds test configuration
type TestConfig struct {
	DatabaseURL   string
	RedisURL      string
	JWTSecret     string
	TestDataPath  string
}

// TestSuite provides common testing utilities
type TestSuite struct {
	T             *testing.T
	Config        *TestConfig
	DB            *sql.DB
	Redis         *redis.Client
	Router        *gin.Engine
	TokenCache    map[string]string
}

// NewTestSuite creates a new test suite
func NewTestSuite(t *testing.T) *TestSuite {
	// Set Gin to test mode
	gin.SetMode(gin.TestMode)
	
	config := &TestConfig{
		DatabaseURL:  getEnv("TEST_DATABASE_URL", "postgres://fanz_user:fanz_password@localhost:5432/fanz_os_test"),
		RedisURL:     getEnv("TEST_REDIS_URL", "localhost:6379"),
		JWTSecret:    getEnv("TEST_JWT_SECRET", "test-jwt-secret"),
		TestDataPath: getEnv("TEST_DATA_PATH", "./fixtures"),
	}

	suite := &TestSuite{
		T:          t,
		Config:     config,
		TokenCache: make(map[string]string),
	}

	// Setup test database
	suite.setupDatabase()
	
	// Setup test Redis
	suite.setupRedis()

	return suite
}

// setupDatabase connects to test database and runs migrations
func (ts *TestSuite) setupDatabase() {
	var err error
	ts.DB, err = sql.Open("postgres", ts.Config.DatabaseURL)
	require.NoError(ts.T, err)

	// Test connection
	err = ts.DB.Ping()
	require.NoError(ts.T, err)

	// Run test migrations
	ts.runTestMigrations()
}

// setupRedis connects to test Redis
func (ts *TestSuite) setupRedis() {
	ts.Redis = redis.NewClient(&redis.Options{
		Addr:     ts.Config.RedisURL,
		Password: "",
		DB:       1, // Use test database
	})

	// Test connection
	_, err := ts.Redis.Ping(context.Background()).Result()
	require.NoError(ts.T, err)
}

// runTestMigrations runs database migrations for testing
func (ts *TestSuite) runTestMigrations() {
	migrations := []string{
		`CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`,
		
		// Users table
		`CREATE TABLE IF NOT EXISTS users (
			id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
			email VARCHAR UNIQUE,
			phone_number VARCHAR UNIQUE,
			password_hash VARCHAR,
			first_name VARCHAR,
			last_name VARCHAR,
			profile_image_url VARCHAR,
			role VARCHAR NOT NULL DEFAULT 'fanz',
			username VARCHAR UNIQUE,
			display_name VARCHAR,
			bio TEXT,
			subscription_price DECIMAL DEFAULT 0,
			is_verified BOOLEAN DEFAULT FALSE,
			email_verified BOOLEAN DEFAULT FALSE,
			phone_verified BOOLEAN DEFAULT FALSE,
			two_factor_enabled BOOLEAN DEFAULT FALSE,
			two_factor_secret VARCHAR,
			balance DECIMAL DEFAULT 0,
			total_earnings DECIMAL DEFAULT 0,
			subscriber_count INTEGER DEFAULT 0,
			creator_status VARCHAR DEFAULT 'pending',
			last_post_date TIMESTAMP,
			weekly_post_count INTEGER DEFAULT 0,
			monthly_post_count INTEGER DEFAULT 0,
			push_notification_token VARCHAR,
			notification_preferences JSONB DEFAULT '{}',
			created_at TIMESTAMP DEFAULT NOW(),
			updated_at TIMESTAMP DEFAULT NOW()
		);`,
		
		// Sessions table
		`CREATE TABLE IF NOT EXISTS sessions (
			id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
			user_id VARCHAR NOT NULL REFERENCES users(id),
			token_hash VARCHAR NOT NULL,
			expires_at TIMESTAMP NOT NULL,
			is_active BOOLEAN DEFAULT TRUE,
			device_info JSONB,
			ip_address VARCHAR,
			created_at TIMESTAMP DEFAULT NOW(),
			updated_at TIMESTAMP DEFAULT NOW()
		);`,
		
		// Posts table
		`CREATE TABLE IF NOT EXISTS posts (
			id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
			creator_id VARCHAR NOT NULL REFERENCES users(id),
			content TEXT,
			media_urls JSONB DEFAULT '[]',
			media_types JSONB DEFAULT '[]',
			visibility VARCHAR DEFAULT 'public',
			is_ppv BOOLEAN DEFAULT FALSE,
			ppv_price DECIMAL DEFAULT 0,
			like_count INTEGER DEFAULT 0,
			comment_count INTEGER DEFAULT 0,
			view_count INTEGER DEFAULT 0,
			created_at TIMESTAMP DEFAULT NOW(),
			updated_at TIMESTAMP DEFAULT NOW()
		);`,
		
		// Transactions table
		`CREATE TABLE IF NOT EXISTS transactions (
			id VARCHAR PRIMARY KEY DEFAULT uuid_generate_v4(),
			user_id VARCHAR NOT NULL REFERENCES users(id),
			creator_id VARCHAR REFERENCES users(id),
			type VARCHAR NOT NULL,
			amount DECIMAL NOT NULL,
			status VARCHAR DEFAULT 'pending',
			payment_method VARCHAR,
			external_transaction_id VARCHAR,
			description TEXT,
			created_at TIMESTAMP DEFAULT NOW(),
			updated_at TIMESTAMP DEFAULT NOW()
		);`,
	}

	for _, migration := range migrations {
		_, err := ts.DB.Exec(migration)
		require.NoError(ts.T, err)
	}
}

// CleanupDatabase cleans test data
func (ts *TestSuite) CleanupDatabase() {
	tables := []string{"sessions", "transactions", "posts", "users"}
	
	for _, table := range tables {
		_, err := ts.DB.Exec(fmt.Sprintf("TRUNCATE TABLE %s CASCADE", table))
		if err != nil {
			log.Printf("Warning: Failed to truncate table %s: %v", table, err)
		}
	}
}

// CleanupRedis clears test Redis data
func (ts *TestSuite) CleanupRedis() {
	err := ts.Redis.FlushDB(context.Background()).Err()
	if err != nil {
		log.Printf("Warning: Failed to flush Redis: %v", err)
	}
}

// Teardown cleans up test resources
func (ts *TestSuite) Teardown() {
	ts.CleanupDatabase()
	ts.CleanupRedis()
	
	if ts.DB != nil {
		ts.DB.Close()
	}
	if ts.Redis != nil {
		ts.Redis.Close()
	}
}

// MakeRequest makes HTTP request for testing
func (ts *TestSuite) MakeRequest(method, url string, body interface{}, token ...string) *httptest.ResponseRecorder {
	var reqBody []byte
	var err error
	
	if body != nil {
		reqBody, err = json.Marshal(body)
		require.NoError(ts.T, err)
	}

	req := httptest.NewRequest(method, url, bytes.NewBuffer(reqBody))
	req.Header.Set("Content-Type", "application/json")
	
	// Add authorization header if token provided
	if len(token) > 0 && token[0] != "" {
		req.Header.Set("Authorization", "Bearer "+token[0])
	}

	recorder := httptest.NewRecorder()
	ts.Router.ServeHTTP(recorder, req)

	return recorder
}

// AssertStatusCode asserts HTTP status code
func (ts *TestSuite) AssertStatusCode(recorder *httptest.ResponseRecorder, expectedCode int) {
	assert.Equal(ts.T, expectedCode, recorder.Code, 
		"Expected status code %d, got %d. Response: %s", 
		expectedCode, recorder.Code, recorder.Body.String())
}

// AssertJSONResponse asserts JSON response structure
func (ts *TestSuite) AssertJSONResponse(recorder *httptest.ResponseRecorder, expected interface{}) {
	var actual interface{}
	err := json.Unmarshal(recorder.Body.Bytes(), &actual)
	require.NoError(ts.T, err)
	
	expectedJSON, _ := json.Marshal(expected)
	actualJSON, _ := json.Marshal(actual)
	assert.JSONEq(ts.T, string(expectedJSON), string(actualJSON))
}

// CreateTestUser creates a test user
func (ts *TestSuite) CreateTestUser(role string) map[string]interface{} {
	timestamp := time.Now().Unix()
	user := map[string]interface{}{
		"email":     fmt.Sprintf("test%d@example.com", timestamp),
		"password":  "TestPassword123!",
		"firstName": "Test",
		"lastName":  "User",
		"role":      role,
		"username":  fmt.Sprintf("testuser%d", timestamp),
	}

	return user
}

// LoginUser logs in a user and returns token
func (ts *TestSuite) LoginUser(email, password string) string {
	// Check cache first
	cacheKey := fmt.Sprintf("%s:%s", email, password)
	if token, exists := ts.TokenCache[cacheKey]; exists {
		return token
	}

	loginData := map[string]interface{}{
		"email":    email,
		"password": password,
	}

	recorder := ts.MakeRequest("POST", "/auth/login", loginData)
	require.Equal(ts.T, http.StatusOK, recorder.Code)

	var response map[string]interface{}
	err := json.Unmarshal(recorder.Body.Bytes(), &response)
	require.NoError(ts.T, err)

	token, ok := response["token"].(string)
	require.True(ts.T, ok, "Login response should contain token")

	// Cache token
	ts.TokenCache[cacheKey] = token

	return token
}

// WaitForCondition waits for a condition to be true
func (ts *TestSuite) WaitForCondition(condition func() bool, timeout time.Duration, message string) {
	start := time.Now()
	for time.Since(start) < timeout {
		if condition() {
			return
		}
		time.Sleep(100 * time.Millisecond)
	}
	ts.T.Fatalf("Timeout waiting for condition: %s", message)
}

// getEnv gets environment variable with default
func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}