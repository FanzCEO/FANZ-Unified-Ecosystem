package fixtures

import (
	"time"

	"github.com/shopspring/decimal"
)

// TestUsers contains sample user data for testing
var TestUsers = []map[string]interface{}{
	{
		"id":                "user-1",
		"email":             "creator1@test.com",
		"password":          "Creator123!",
		"first_name":        "Alice",
		"last_name":         "Creator",
		"role":              "creator",
		"username":          "alice_creator",
		"display_name":      "Alice the Creator",
		"bio":               "Professional content creator",
		"subscription_price": decimal.NewFromFloat(19.99),
		"is_verified":       true,
		"email_verified":    true,
		"creator_status":    "approved",
		"subscriber_count":  1250,
	},
	{
		"id":                "user-2",
		"email":             "fan1@test.com",
		"password":          "Fan123!",
		"first_name":        "Bob",
		"last_name":         "Fan",
		"role":              "fanz",
		"username":          "bob_fan",
		"display_name":      "Bob the Fan",
		"bio":               "Love supporting creators",
		"subscription_price": decimal.Zero,
		"is_verified":       false,
		"email_verified":    true,
		"creator_status":    "none",
		"subscriber_count":  0,
	},
	{
		"id":                "user-3",
		"email":             "admin@test.com",
		"password":          "Admin123!",
		"first_name":        "Charlie",
		"last_name":         "Admin",
		"role":              "admin",
		"username":          "charlie_admin",
		"display_name":      "Charlie Administrator",
		"bio":               "Platform administrator",
		"subscription_price": decimal.Zero,
		"is_verified":       true,
		"email_verified":    true,
		"creator_status":    "none",
		"subscriber_count":  0,
	},
}

// TestPosts contains sample post data for testing
var TestPosts = []map[string]interface{}{
	{
		"id":          "post-1",
		"creator_id":  "user-1",
		"content":     "Welcome to my page! Here's my first post.",
		"media_urls":  []string{"https://example.com/image1.jpg"},
		"media_types": []string{"image"},
		"visibility":  "public",
		"is_ppv":      false,
		"ppv_price":   decimal.Zero,
		"like_count":  45,
		"comment_count": 12,
		"view_count":  234,
		"created_at":  time.Now().Add(-24 * time.Hour),
	},
	{
		"id":          "post-2",
		"creator_id":  "user-1",
		"content":     "Exclusive content for subscribers only!",
		"media_urls":  []string{"https://example.com/video1.mp4"},
		"media_types": []string{"video"},
		"visibility":  "subscribers",
		"is_ppv":      false,
		"ppv_price":   decimal.Zero,
		"like_count":  89,
		"comment_count": 25,
		"view_count":  156,
		"created_at":  time.Now().Add(-12 * time.Hour),
	},
	{
		"id":          "post-3",
		"creator_id":  "user-1",
		"content":     "Premium content - pay per view",
		"media_urls":  []string{"https://example.com/premium1.mp4"},
		"media_types": []string{"video"],
		"visibility":  "public",
		"is_ppv":      true,
		"ppv_price":   decimal.NewFromFloat(9.99),
		"like_count":  23,
		"comment_count": 8,
		"view_count":  67,
		"created_at":  time.Now().Add(-6 * time.Hour),
	},
}

// TestTransactions contains sample transaction data for testing
var TestTransactions = []map[string]interface{}{
	{
		"id":                     "txn-1",
		"user_id":               "user-2",
		"creator_id":            "user-1",
		"type":                  "subscription",
		"amount":                decimal.NewFromFloat(19.99),
		"status":                "completed",
		"payment_method":        "credit_card",
		"external_transaction_id": "stripe_123456",
		"description":           "Monthly subscription to Alice the Creator",
		"created_at":            time.Now().Add(-30 * 24 * time.Hour),
	},
	{
		"id":                     "txn-2",
		"user_id":               "user-2",
		"creator_id":            "user-1",
		"type":                  "tip",
		"amount":                decimal.NewFromFloat(5.00),
		"status":                "completed",
		"payment_method":        "credit_card",
		"external_transaction_id": "stripe_123457",
		"description":           "Tip for great content",
		"created_at":            time.Now().Add(-7 * 24 * time.Hour),
	},
	{
		"id":                     "txn-3",
		"user_id":               "user-2",
		"creator_id":            "user-1",
		"type":                  "ppv",
		"amount":                decimal.NewFromFloat(9.99),
		"status":                "completed",
		"payment_method":        "credit_card",
		"external_transaction_id": "stripe_123458",
		"description":           "Premium content purchase",
		"created_at":            time.Now().Add(-2 * 24 * time.Hour),
	},
}

// TestMessages contains sample message data for testing
var TestMessages = []map[string]interface{}{
	{
		"id":           "msg-1",
		"sender_id":    "user-2",
		"receiver_id":  "user-1",
		"content":      "Hi! Love your content!",
		"message_type": "text",
		"is_read":      false,
		"is_ppv":       false,
		"ppv_price":    decimal.Zero,
		"created_at":   time.Now().Add(-1 * time.Hour),
	},
	{
		"id":           "msg-2",
		"sender_id":    "user-1",
		"receiver_id":  "user-2",
		"content":      "Thank you so much! 💕",
		"message_type": "text",
		"is_read":      true,
		"is_ppv":       false,
		"ppv_price":    decimal.Zero,
		"created_at":   time.Now().Add(-30 * time.Minute),
	},
	{
		"id":           "msg-3",
		"sender_id":    "user-1",
		"receiver_id":  "user-2",
		"content":      "Special photo just for you!",
		"message_type": "image",
		"media_url":    "https://example.com/special.jpg",
		"is_read":      false,
		"is_ppv":       true,
		"ppv_price":    decimal.NewFromFloat(4.99),
		"created_at":   time.Now().Add(-15 * time.Minute),
	},
}

// TestStreams contains sample streaming session data
var TestStreams = []map[string]interface{}{
	{
		"id":          "stream-1",
		"creator_id":  "user-1",
		"title":       "Live Q&A Session",
		"description": "Ask me anything!",
		"status":      "live",
		"viewer_count": 45,
		"is_private":  false,
		"price":       decimal.Zero,
		"started_at":  time.Now().Add(-30 * time.Minute),
	},
	{
		"id":          "stream-2",
		"creator_id":  "user-1",
		"title":       "Private Show",
		"description": "Exclusive private streaming session",
		"status":      "scheduled",
		"viewer_count": 0,
		"is_private":  true,
		"price":       decimal.NewFromFloat(49.99),
		"scheduled_at": time.Now().Add(2 * time.Hour),
	},
}

// ErrorScenarios contains test cases for error handling
var ErrorScenarios = map[string]map[string]interface{}{
	"invalid_user_creation": {
		"email":     "invalid-email",
		"password":  "123", // Too short
		"firstName": "",    // Required field empty
		"role":      "invalid_role",
	},
	"invalid_login": {
		"email":    "nonexistent@test.com",
		"password": "wrong_password",
	},
	"unauthorized_access": {
		"user_id": "user-2", // Fan trying to access creator-only endpoint
		"endpoint": "/creator/analytics",
	},
	"insufficient_balance": {
		"user_id": "user-2",
		"amount":  decimal.NewFromFloat(1000.00), // More than user's balance
		"action":  "tip",
	},
}

// PerformanceTestData contains data for load testing
var PerformanceTestData = map[string]interface{}{
	"concurrent_users":     []int{10, 50, 100, 500, 1000},
	"request_duration":     "60s",
	"ramp_up_time":        "30s",
	"test_endpoints": []string{
		"/api/users/profile",
		"/api/content/posts",
		"/api/payments/transactions",
		"/api/messaging/conversations",
	},
}

// SecurityTestCases contains test cases for security testing
var SecurityTestCases = []map[string]interface{}{
	{
		"name":        "SQL Injection Test",
		"endpoint":    "/api/users/search",
		"payload":     map[string]string{"query": "'; DROP TABLE users; --"},
		"expectCode":  400,
	},
	{
		"name":        "XSS Test",
		"endpoint":    "/api/content/posts",
		"payload":     map[string]string{"content": "<script>alert('xss')</script>"},
		"expectCode":  201, // Should be sanitized, not blocked
	},
	{
		"name":        "JWT Tampering Test",
		"endpoint":    "/api/users/profile",
		"headers":     map[string]string{"Authorization": "Bearer invalid.jwt.token"},
		"expectCode":  401,
	},
	{
		"name":        "Rate Limit Test",
		"endpoint":    "/api/auth/login",
		"requests":    100,
		"expectCode":  429, // Too Many Requests
	},
}