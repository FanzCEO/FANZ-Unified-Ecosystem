package mocks

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/shopspring/decimal"
)

// MockUserService provides mock user service for testing
type MockUserService struct {
	Users    map[string]interface{}
	Sessions map[string]interface{}
	Server   *httptest.Server
}

// NewMockUserService creates a new mock user service
func NewMockUserService() *MockUserService {
	mock := &MockUserService{
		Users:    make(map[string]interface{}),
		Sessions: make(map[string]interface{}),
	}

	gin.SetMode(gin.TestMode)
	router := gin.New()
	
	// Mock endpoints
	router.POST("/auth/register", mock.handleRegister)
	router.POST("/auth/login", mock.handleLogin)
	router.GET("/users/:id", mock.handleGetUser)
	router.PUT("/users/:id", mock.handleUpdateUser)
	router.GET("/health", mock.handleHealth)

	mock.Server = httptest.NewServer(router)
	return mock
}

func (m *MockUserService) handleRegister(c *gin.Context) {
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": "Invalid request"})
		return
	}

	userID := "mock-user-" + time.Now().Format("20060102150405")
	user := map[string]interface{}{
		"id":         userID,
		"email":      req["email"],
		"firstName":  req["firstName"],
		"lastName":   req["lastName"],
		"role":       req["role"],
		"username":   req["username"],
		"createdAt":  time.Now(),
	}

	m.Users[userID] = user
	c.JSON(201, gin.H{"user": user})
}

func (m *MockUserService) handleLogin(c *gin.Context) {
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": "Invalid request"})
		return
	}

	email := req["email"].(string)
	password := req["password"].(string)

	// Mock authentication
	if password == "wrong_password" {
		c.JSON(401, gin.H{"error": "Invalid credentials"})
		return
	}

	token := "mock-jwt-token-" + time.Now().Format("20060102150405")
	c.JSON(200, gin.H{
		"token": token,
		"user": map[string]interface{}{
			"email": email,
			"role":  "fanz",
		},
	})
}

func (m *MockUserService) handleGetUser(c *gin.Context) {
	userID := c.Param("id")
	if user, exists := m.Users[userID]; exists {
		c.JSON(200, gin.H{"user": user})
	} else {
		c.JSON(404, gin.H{"error": "User not found"})
	}
}

func (m *MockUserService) handleUpdateUser(c *gin.Context) {
	userID := c.Param("id")
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": "Invalid request"})
		return
	}

	if user, exists := m.Users[userID]; exists {
		// Update user fields
		for key, value := range req {
			if userMap, ok := user.(map[string]interface{}); ok {
				userMap[key] = value
			}
		}
		c.JSON(200, gin.H{"user": user})
	} else {
		c.JSON(404, gin.H{"error": "User not found"})
	}
}

func (m *MockUserService) handleHealth(c *gin.Context) {
	c.JSON(200, gin.H{"status": "healthy"})
}

func (m *MockUserService) Close() {
	m.Server.Close()
}

// MockPaymentService provides mock payment service for testing
type MockPaymentService struct {
	Transactions map[string]interface{}
	Server       *httptest.Server
}

func NewMockPaymentService() *MockPaymentService {
	mock := &MockPaymentService{
		Transactions: make(map[string]interface{}),
	}

	gin.SetMode(gin.TestMode)
	router := gin.New()
	
	router.POST("/transactions", mock.handleCreateTransaction)
	router.GET("/transactions/:id", mock.handleGetTransaction)
	router.POST("/subscriptions", mock.handleCreateSubscription)
	router.POST("/webhooks/stripe", mock.handleWebhook)
	router.GET("/health", mock.handleHealth)

	mock.Server = httptest.NewServer(router)
	return mock
}

func (m *MockPaymentService) handleCreateTransaction(c *gin.Context) {
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": "Invalid request"})
		return
	}

	transactionID := "mock-txn-" + time.Now().Format("20060102150405")
	transaction := map[string]interface{}{
		"id":        transactionID,
		"userId":    req["userId"],
		"creatorId": req["creatorId"],
		"type":      req["type"],
		"amount":    req["amount"],
		"status":    "completed",
		"createdAt": time.Now(),
	}

	m.Transactions[transactionID] = transaction
	c.JSON(201, gin.H{"transaction": transaction})
}

func (m *MockPaymentService) handleGetTransaction(c *gin.Context) {
	txnID := c.Param("id")
	if txn, exists := m.Transactions[txnID]; exists {
		c.JSON(200, gin.H{"transaction": txn})
	} else {
		c.JSON(404, gin.H{"error": "Transaction not found"})
	}
}

func (m *MockPaymentService) handleCreateSubscription(c *gin.Context) {
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": "Invalid request"})
		return
	}

	c.JSON(201, gin.H{
		"subscription": map[string]interface{}{
			"id":        "mock-sub-" + time.Now().Format("20060102150405"),
			"userId":    req["userId"],
			"creatorId": req["creatorId"],
			"status":    "active",
			"createdAt": time.Now(),
		},
	})
}

func (m *MockPaymentService) handleWebhook(c *gin.Context) {
	c.JSON(200, gin.H{"received": true})
}

func (m *MockPaymentService) handleHealth(c *gin.Context) {
	c.JSON(200, gin.H{"status": "healthy"})
}

func (m *MockPaymentService) Close() {
	m.Server.Close()
}

// MockContentService provides mock content service for testing
type MockContentService struct {
	Posts  map[string]interface{}
	Server *httptest.Server
}

func NewMockContentService() *MockContentService {
	mock := &MockContentService{
		Posts: make(map[string]interface{}),
	}

	gin.SetMode(gin.TestMode)
	router := gin.New()
	
	router.POST("/posts", mock.handleCreatePost)
	router.GET("/posts/:id", mock.handleGetPost)
	router.GET("/posts", mock.handleGetPosts)
	router.PUT("/posts/:id", mock.handleUpdatePost)
	router.DELETE("/posts/:id", mock.handleDeletePost)
	router.GET("/health", mock.handleHealth)

	mock.Server = httptest.NewServer(router)
	return mock
}

func (m *MockContentService) handleCreatePost(c *gin.Context) {
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": "Invalid request"})
		return
	}

	postID := "mock-post-" + time.Now().Format("20060102150405")
	post := map[string]interface{}{
		"id":         postID,
		"creatorId":  req["creatorId"],
		"content":    req["content"],
		"mediaUrls":  req["mediaUrls"],
		"visibility": req["visibility"],
		"isPpv":      req["isPpv"],
		"ppvPrice":   req["ppvPrice"],
		"createdAt":  time.Now(),
	}

	m.Posts[postID] = post
	c.JSON(201, gin.H{"post": post})
}

func (m *MockContentService) handleGetPost(c *gin.Context) {
	postID := c.Param("id")
	if post, exists := m.Posts[postID]; exists {
		c.JSON(200, gin.H{"post": post})
	} else {
		c.JSON(404, gin.H{"error": "Post not found"})
	}
}

func (m *MockContentService) handleGetPosts(c *gin.Context) {
	posts := make([]interface{}, 0)
	for _, post := range m.Posts {
		posts = append(posts, post)
	}
	c.JSON(200, gin.H{"posts": posts})
}

func (m *MockContentService) handleUpdatePost(c *gin.Context) {
	postID := c.Param("id")
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(400, gin.H{"error": "Invalid request"})
		return
	}

	if post, exists := m.Posts[postID]; exists {
		for key, value := range req {
			if postMap, ok := post.(map[string]interface{}); ok {
				postMap[key] = value
			}
		}
		c.JSON(200, gin.H{"post": post})
	} else {
		c.JSON(404, gin.H{"error": "Post not found"})
	}
}

func (m *MockContentService) handleDeletePost(c *gin.Context) {
	postID := c.Param("id")
	if _, exists := m.Posts[postID]; exists {
		delete(m.Posts, postID)
		c.JSON(204, nil)
	} else {
		c.JSON(404, gin.H{"error": "Post not found"})
	}
}

func (m *MockContentService) handleHealth(c *gin.Context) {
	c.JSON(200, gin.H{"status": "healthy"})
}

func (m *MockContentService) Close() {
	m.Server.Close()
}

// MockExternalServices provides mocks for external services
type MockExternalServices struct {
	StripeServer     *httptest.Server
	StorageServer    *httptest.Server
	NotificationServer *httptest.Server
}

func NewMockExternalServices() *MockExternalServices {
	mock := &MockExternalServices{}
	
	// Mock Stripe API
	gin.SetMode(gin.TestMode)
	stripeRouter := gin.New()
	stripeRouter.POST("/v1/payment_intents", mock.handleStripePayment)
	stripeRouter.POST("/v1/customers", mock.handleStripeCustomer)
	mock.StripeServer = httptest.NewServer(stripeRouter)
	
	// Mock Storage API
	storageRouter := gin.New()
	storageRouter.POST("/upload", mock.handleFileUpload)
	storageRouter.DELETE("/files/:id", mock.handleFileDelete)
	mock.StorageServer = httptest.NewServer(storageRouter)
	
	// Mock Notification Service
	notificationRouter := gin.New()
	notificationRouter.POST("/send", mock.handleNotification)
	mock.NotificationServer = httptest.NewServer(notificationRouter)
	
	return mock
}

func (m *MockExternalServices) handleStripePayment(c *gin.Context) {
	c.JSON(200, gin.H{
		"id":     "pi_mock_payment_intent",
		"status": "succeeded",
		"amount": 1999,
	})
}

func (m *MockExternalServices) handleStripeCustomer(c *gin.Context) {
	c.JSON(200, gin.H{
		"id":    "cus_mock_customer",
		"email": "test@example.com",
	})
}

func (m *MockExternalServices) handleFileUpload(c *gin.Context) {
	c.JSON(200, gin.H{
		"fileId":  "mock_file_123",
		"url":     "https://mock-storage.com/files/mock_file_123",
		"size":    1024,
		"mimeType": "image/jpeg",
	})
}

func (m *MockExternalServices) handleFileDelete(c *gin.Context) {
	c.JSON(200, gin.H{"deleted": true})
}

func (m *MockExternalServices) handleNotification(c *gin.Context) {
	c.JSON(200, gin.H{"sent": true})
}

func (m *MockExternalServices) Close() {
	if m.StripeServer != nil {
		m.StripeServer.Close()
	}
	if m.StorageServer != nil {
		m.StorageServer.Close()
	}
	if m.NotificationServer != nil {
		m.NotificationServer.Close()
	}
}