package monitoring

import (
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
	// HTTP metrics
	httpRequestsTotal = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "http_requests_total",
			Help: "Total number of HTTP requests",
		},
		[]string{"service", "method", "route", "code"},
	)

	httpRequestDuration = prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    "http_request_duration_seconds",
			Help:    "Duration of HTTP requests in seconds",
			Buckets: prometheus.DefBuckets,
		},
		[]string{"service", "method", "route"},
	)

	// Business metrics
	activeUsersGauge = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{
			Name: "active_users_total",
			Help: "Number of active users",
		},
		[]string{"role"},
	)

	paymentTransactionsTotal = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "payment_transactions_total",
			Help: "Total number of payment transactions",
		},
		[]string{"type", "status"},
	)

	paymentRevenueTotal = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "payment_revenue_total",
			Help: "Total payment revenue",
		},
		[]string{"type"},
	)

	subscriptionCreatedTotal = prometheus.NewCounter(
		prometheus.CounterOpts{
			Name: "subscription_created_total",
			Help: "Total number of subscriptions created",
		},
	)

	subscriptionCancellationsTotal = prometheus.NewCounter(
		prometheus.CounterOpts{
			Name: "subscription_cancellations_total",
			Help: "Total number of subscription cancellations",
		},
	)

	contentPostsCreatedTotal = prometheus.NewCounter(
		prometheus.CounterOpts{
			Name: "content_posts_created_total",
			Help: "Total number of content posts created",
		},
	)

	contentLikesTotal = prometheus.NewCounter(
		prometheus.CounterOpts{
			Name: "content_likes_total",
			Help: "Total number of content likes",
		},
	)

	contentCommentsTotal = prometheus.NewCounter(
		prometheus.CounterOpts{
			Name: "content_comments_total",
			Help: "Total number of content comments",
		},
	)

	contentViewsTotal = prometheus.NewCounter(
		prometheus.CounterOpts{
			Name: "content_views_total",
			Help: "Total number of content views",
		},
	)

	contentModerationTotal = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "content_moderation_total",
			Help: "Total number of content moderation actions",
		},
		[]string{"action"},
	)

	contentModerationQueueSize = prometheus.NewGauge(
		prometheus.GaugeOpts{
			Name: "content_moderation_queue_size",
			Help: "Number of items in content moderation queue",
		},
	)

	streamingActiveStreams = prometheus.NewGauge(
		prometheus.GaugeOpts{
			Name: "streaming_active_streams",
			Help: "Number of active streams",
		},
	)

	streamingTotalViewers = prometheus.NewGauge(
		prometheus.GaugeOpts{
			Name: "streaming_total_viewers",
			Help: "Total number of stream viewers",
		},
	)

	streamingConnectionsTotal = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "streaming_connections_total",
			Help: "Total number of streaming connections",
		},
		[]string{"status"},
	)

	streamingBandwidthUsage = prometheus.NewGauge(
		prometheus.GaugeOpts{
			Name: "streaming_bandwidth_usage_mbps",
			Help: "Streaming bandwidth usage in Mbps",
		},
	)

	messageDeliveryDuration = prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    "message_delivery_duration_seconds",
			Help:    "Time taken to deliver messages",
			Buckets: []float64{0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0},
		},
		[]string{"type"},
	)

	aiRequestDuration = prometheus.NewHistogramVec(
		prometheus.HistogramOpts{
			Name:    "ai_request_duration_seconds",
			Help:    "Duration of AI service requests",
			Buckets: []float64{0.5, 1.0, 2.0, 5.0, 10.0, 30.0},
		},
		[]string{"service", "model"},
	)

	// User registration metrics
	usersRegisteredTotal = prometheus.NewCounter(
		prometheus.CounterOpts{
			Name: "users_registered_total",
			Help: "Total number of users registered",
		},
	)

	usersVerifiedTotal = prometheus.NewCounter(
		prometheus.CounterOpts{
			Name: "users_verified_total",
			Help: "Total number of users verified",
		},
	)
)

// InitMetrics initializes Prometheus metrics
func InitMetrics() {
	prometheus.MustRegister(
		httpRequestsTotal,
		httpRequestDuration,
		activeUsersGauge,
		paymentTransactionsTotal,
		paymentRevenueTotal,
		subscriptionCreatedTotal,
		subscriptionCancellationsTotal,
		contentPostsCreatedTotal,
		contentLikesTotal,
		contentCommentsTotal,
		contentViewsTotal,
		contentModerationTotal,
		contentModerationQueueSize,
		streamingActiveStreams,
		streamingTotalViewers,
		streamingConnectionsTotal,
		streamingBandwidthUsage,
		messageDeliveryDuration,
		aiRequestDuration,
		usersRegisteredTotal,
		usersVerifiedTotal,
	)
}

// PrometheusMiddleware creates a Gin middleware for Prometheus metrics
func PrometheusMiddleware(serviceName string) gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()

		// Process request
		c.Next()

		// Record metrics
		duration := time.Since(start)
		statusCode := strconv.Itoa(c.Writer.Status())

		httpRequestsTotal.WithLabelValues(
			serviceName,
			c.Request.Method,
			c.FullPath(),
			statusCode,
		).Inc()

		httpRequestDuration.WithLabelValues(
			serviceName,
			c.Request.Method,
			c.FullPath(),
		).Observe(duration.Seconds())
	}
}

// MetricsHandler returns a Prometheus metrics handler
func MetricsHandler() gin.HandlerFunc {
	h := promhttp.Handler()
	return func(c *gin.Context) {
		h.ServeHTTP(c.Writer, c.Request)
	}
}

// Business Metrics Functions

// IncrementActiveUsers increments active users gauge
func IncrementActiveUsers(role string) {
	activeUsersGauge.WithLabelValues(role).Inc()
}

// DecrementActiveUsers decrements active users gauge
func DecrementActiveUsers(role string) {
	activeUsersGauge.WithLabelValues(role).Dec()
}

// RecordPaymentTransaction records a payment transaction
func RecordPaymentTransaction(transactionType, status string, amount float64) {
	paymentTransactionsTotal.WithLabelValues(transactionType, status).Inc()
	if status == "success" {
		paymentRevenueTotal.WithLabelValues(transactionType).Add(amount)
	}
}

// IncrementSubscriptionCreated increments subscription creation counter
func IncrementSubscriptionCreated() {
	subscriptionCreatedTotal.Inc()
}

// IncrementSubscriptionCancelled increments subscription cancellation counter
func IncrementSubscriptionCancelled() {
	subscriptionCancellationsTotal.Inc()
}

// IncrementContentPostCreated increments content post creation counter
func IncrementContentPostCreated() {
	contentPostsCreatedTotal.Inc()
}

// IncrementContentLikes increments content likes counter
func IncrementContentLikes() {
	contentLikesTotal.Inc()
}

// IncrementContentComments increments content comments counter
func IncrementContentComments() {
	contentCommentsTotal.Inc()
}

// IncrementContentViews increments content views counter
func IncrementContentViews() {
	contentViewsTotal.Inc()
}

// RecordContentModeration records content moderation action
func RecordContentModeration(action string) {
	contentModerationTotal.WithLabelValues(action).Inc()
}

// SetContentModerationQueueSize sets the moderation queue size
func SetContentModerationQueueSize(size float64) {
	contentModerationQueueSize.Set(size)
}

// SetStreamingActiveStreams sets the number of active streams
func SetStreamingActiveStreams(count float64) {
	streamingActiveStreams.Set(count)
}

// SetStreamingTotalViewers sets the total number of viewers
func SetStreamingTotalViewers(count float64) {
	streamingTotalViewers.Set(count)
}

// RecordStreamingConnection records a streaming connection attempt
func RecordStreamingConnection(status string) {
	streamingConnectionsTotal.WithLabelValues(status).Inc()
}

// SetStreamingBandwidthUsage sets the streaming bandwidth usage
func SetStreamingBandwidthUsage(mbps float64) {
	streamingBandwidthUsage.Set(mbps)
}

// RecordMessageDelivery records message delivery time
func RecordMessageDelivery(messageType string, duration time.Duration) {
	messageDeliveryDuration.WithLabelValues(messageType).Observe(duration.Seconds())
}

// RecordAIRequest records AI service request duration
func RecordAIRequest(service, model string, duration time.Duration) {
	aiRequestDuration.WithLabelValues(service, model).Observe(duration.Seconds())
}

// IncrementUserRegistered increments user registration counter
func IncrementUserRegistered() {
	usersRegisteredTotal.Inc()
}

// IncrementUserVerified increments user verification counter
func IncrementUserVerified() {
	usersVerifiedTotal.Inc()
}

// SetupMetricsRoute sets up the metrics endpoint
func SetupMetricsRoute(r *gin.Engine) {
	r.GET("/metrics", MetricsHandler())
}