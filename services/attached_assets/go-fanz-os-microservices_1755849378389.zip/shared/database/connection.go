package database

import (
        "context"
        "database/sql"
        "fmt"
        "log"
        "os"
        "time"

        _ "github.com/lib/pq"
)

// Config holds database configuration
type Config struct {
        Host     string
        Port     string
        User     string
        Password string
        Database string
        SSLMode  string
}

// DB wraps the sql.DB connection
type DB struct {
        *sql.DB
}

// NewConfig creates a database config from environment variables
func NewConfig() *Config {
        return &Config{
                Host:     getEnv("DB_HOST", "localhost"),
                Port:     getEnv("DB_PORT", "5432"),
                User:     getEnv("DB_USER", "fanz_user"),
                Password: getEnv("DB_PASSWORD", "fanz_password"),
                Database: getEnv("DB_NAME", "fanz_os"),
                SSLMode:  getEnv("DB_SSL_MODE", "disable"),
        }
}

// NewConfigFromURL creates a database config from a DATABASE_URL
func NewConfigFromURL(databaseURL string) (*Config, error) {
        if databaseURL == "" {
                return NewConfig(), nil
        }

        // Parse DATABASE_URL if provided
        // For now, return default config - in production, implement proper URL parsing
        return NewConfig(), nil
}

// Connect establishes a connection to the PostgreSQL database
func Connect(config *Config) (*DB, error) {
        dsn := fmt.Sprintf(
                "host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
                config.Host, config.Port, config.User, config.Password, config.Database, config.SSLMode,
        )

        db, err := sql.Open("postgres", dsn)
        if err != nil {
                return nil, fmt.Errorf("failed to open database connection: %w", err)
        }

        // Configure connection pool
        db.SetMaxOpenConns(100)
        db.SetMaxIdleConns(25)
        db.SetConnMaxLifetime(5 * time.Minute)
        db.SetConnMaxIdleTime(5 * time.Minute)

        // Test the connection
        if err := db.Ping(); err != nil {
                return nil, fmt.Errorf("failed to ping database: %w", err)
        }

        log.Printf("Successfully connected to PostgreSQL database: %s", config.Database)

        return &DB{DB: db}, nil
}

// ConnectFromEnv connects to the database using environment variables
func ConnectFromEnv() (*DB, error) {
        databaseURL := os.Getenv("DATABASE_URL")
        
        config, err := NewConfigFromURL(databaseURL)
        if err != nil {
                return nil, fmt.Errorf("failed to parse database config: %w", err)
        }

        return Connect(config)
}

// Close closes the database connection
func (db *DB) Close() error {
        log.Println("Closing database connection")
        return db.DB.Close()
}

// HealthCheck performs a health check on the database
func (db *DB) HealthCheck() error {
        ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
        defer cancel()

        return db.PingContext(ctx)
}

// BeginTx starts a new transaction
func (db *DB) BeginTx() (*sql.Tx, error) {
        return db.DB.Begin()
}

// GetStats returns database statistics
func (db *DB) GetStats() sql.DBStats {
        return db.DB.Stats()
}

// Helper function to get environment variables with default values
func getEnv(key, defaultValue string) string {
        if value := os.Getenv(key); value != "" {
                return value
        }
        return defaultValue
}