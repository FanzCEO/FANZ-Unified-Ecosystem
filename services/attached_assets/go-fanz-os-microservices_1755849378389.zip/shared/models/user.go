package models

import (
	"time"
	"github.com/shopspring/decimal"
)

// User represents the users table
type User struct {
	ID                        string                 `json:"id" db:"id"`
	Email                     *string                `json:"email,omitempty" db:"email"`
	PhoneNumber               *string                `json:"phoneNumber,omitempty" db:"phone_number"`
	PasswordHash              *string                `json:"-" db:"password_hash"` // Never include in JSON
	FirstName                 *string                `json:"firstName,omitempty" db:"first_name"`
	LastName                  *string                `json:"lastName,omitempty" db:"last_name"`
	ProfileImageURL           *string                `json:"profileImageUrl,omitempty" db:"profile_image_url"`
	Role                      UserRole               `json:"role" db:"role"`
	Username                  *string                `json:"username,omitempty" db:"username"`
	DisplayName               *string                `json:"displayName,omitempty" db:"display_name"`
	Bio                       *string                `json:"bio,omitempty" db:"bio"`
	SubscriptionPrice         decimal.Decimal        `json:"subscriptionPrice" db:"subscription_price"`
	IsVerified                bool                   `json:"isVerified" db:"is_verified"`
	EmailVerified             bool                   `json:"emailVerified" db:"email_verified"`
	PhoneVerified             bool                   `json:"phoneVerified" db:"phone_verified"`
	TwoFactorEnabled          bool                   `json:"twoFactorEnabled" db:"two_factor_enabled"`
	TwoFactorSecret           *string                `json:"-" db:"two_factor_secret"` // Never include in JSON
	Balance                   decimal.Decimal        `json:"balance" db:"balance"`
	TotalEarnings             decimal.Decimal        `json:"totalEarnings" db:"total_earnings"`
	SubscriberCount           int                    `json:"subscriberCount" db:"subscriber_count"`
	CreatorStatus             CreatorStatus          `json:"creatorStatus" db:"creator_status"`
	LastPostDate              *time.Time             `json:"lastPostDate,omitempty" db:"last_post_date"`
	WeeklyPostCount           int                    `json:"weeklyPostCount" db:"weekly_post_count"`
	MonthlyPostCount          int                    `json:"monthlyPostCount" db:"monthly_post_count"`
	PushNotificationToken     *string                `json:"pushNotificationToken,omitempty" db:"push_notification_token"`
	NotificationPreferences   map[string]interface{} `json:"notificationPreferences" db:"notification_preferences"`
	CreatedAt                 time.Time              `json:"createdAt" db:"created_at"`
	UpdatedAt                 time.Time              `json:"updatedAt" db:"updated_at"`
}

// CreateUserRequest represents request payload for creating a user
type CreateUserRequest struct {
	Email           *string   `json:"email" validate:"omitempty,email"`
	PhoneNumber     *string   `json:"phoneNumber" validate:"omitempty,phone"`
	Password        string    `json:"password" validate:"required,min=8"`
	FirstName       *string   `json:"firstName" validate:"required"`
	LastName        *string   `json:"lastName" validate:"required"`
	Role            UserRole  `json:"role" validate:"required,oneof=fanz creator admin"`
	Username        *string   `json:"username" validate:"omitempty,alphanum,min=3,max=20"`
	DisplayName     *string   `json:"displayName" validate:"omitempty,max=50"`
	Bio             *string   `json:"bio" validate:"omitempty,max=500"`
}

// UpdateUserRequest represents request payload for updating a user
type UpdateUserRequest struct {
	FirstName             *string         `json:"firstName,omitempty" validate:"omitempty,max=50"`
	LastName              *string         `json:"lastName,omitempty" validate:"omitempty,max=50"`
	Username              *string         `json:"username,omitempty" validate:"omitempty,alphanum,min=3,max=20"`
	DisplayName           *string         `json:"displayName,omitempty" validate:"omitempty,max=50"`
	Bio                   *string         `json:"bio,omitempty" validate:"omitempty,max=500"`
	ProfileImageURL       *string         `json:"profileImageUrl,omitempty" validate:"omitempty,url"`
	SubscriptionPrice     *decimal.Decimal `json:"subscriptionPrice,omitempty" validate:"omitempty,min=0"`
}

// LoginRequest represents login request payload
type LoginRequest struct {
	Email    *string `json:"email,omitempty" validate:"required_without=PhoneNumber,omitempty,email"`
	PhoneNumber *string `json:"phoneNumber,omitempty" validate:"required_without=Email,omitempty,phone"`
	Password string  `json:"password" validate:"required"`
}

// UserResponse represents user data returned to clients (without sensitive fields)
type UserResponse struct {
	ID                      string          `json:"id"`
	Email                   *string         `json:"email,omitempty"`
	PhoneNumber             *string         `json:"phoneNumber,omitempty"`
	FirstName               *string         `json:"firstName,omitempty"`
	LastName                *string         `json:"lastName,omitempty"`
	ProfileImageURL         *string         `json:"profileImageUrl,omitempty"`
	Role                    UserRole        `json:"role"`
	Username                *string         `json:"username,omitempty"`
	DisplayName             *string         `json:"displayName,omitempty"`
	Bio                     *string         `json:"bio,omitempty"`
	SubscriptionPrice       decimal.Decimal `json:"subscriptionPrice"`
	IsVerified              bool            `json:"isVerified"`
	EmailVerified           bool            `json:"emailVerified"`
	PhoneVerified           bool            `json:"phoneVerified"`
	TwoFactorEnabled        bool            `json:"twoFactorEnabled"`
	SubscriberCount         int             `json:"subscriberCount"`
	CreatorStatus           CreatorStatus   `json:"creatorStatus"`
	LastPostDate            *time.Time      `json:"lastPostDate,omitempty"`
	WeeklyPostCount         int             `json:"weeklyPostCount"`
	MonthlyPostCount        int             `json:"monthlyPostCount"`
	CreatedAt               time.Time       `json:"createdAt"`
	UpdatedAt               time.Time       `json:"updatedAt"`
}

// ToUserResponse converts User to UserResponse (removes sensitive fields)
func (u *User) ToUserResponse() *UserResponse {
	return &UserResponse{
		ID:                u.ID,
		Email:             u.Email,
		PhoneNumber:       u.PhoneNumber,
		FirstName:         u.FirstName,
		LastName:          u.LastName,
		ProfileImageURL:   u.ProfileImageURL,
		Role:              u.Role,
		Username:          u.Username,
		DisplayName:       u.DisplayName,
		Bio:               u.Bio,
		SubscriptionPrice: u.SubscriptionPrice,
		IsVerified:        u.IsVerified,
		EmailVerified:     u.EmailVerified,
		PhoneVerified:     u.PhoneVerified,
		TwoFactorEnabled:  u.TwoFactorEnabled,
		SubscriberCount:   u.SubscriberCount,
		CreatorStatus:     u.CreatorStatus,
		LastPostDate:      u.LastPostDate,
		WeeklyPostCount:   u.WeeklyPostCount,
		MonthlyPostCount:  u.MonthlyPostCount,
		CreatedAt:         u.CreatedAt,
		UpdatedAt:         u.UpdatedAt,
	}
}

// AuthProvider represents oauth providers table
type AuthProviderRecord struct {
	ID           string       `json:"id" db:"id"`
	UserID       string       `json:"userId" db:"user_id"`
	Provider     AuthProvider `json:"provider" db:"provider"`
	ProviderID   string       `json:"providerId" db:"provider_id"`
	ProviderEmail *string     `json:"providerEmail,omitempty" db:"provider_email"`
	AccessToken  *string      `json:"-" db:"access_token"` // Never include in JSON
	RefreshToken *string      `json:"-" db:"refresh_token"` // Never include in JSON
	ExpiresAt    *time.Time   `json:"expiresAt,omitempty" db:"expires_at"`
	CreatedAt    time.Time    `json:"createdAt" db:"created_at"`
	UpdatedAt    time.Time    `json:"updatedAt" db:"updated_at"`
}

// VerificationCode represents verification codes table
type VerificationCode struct {
	ID          string     `json:"id" db:"id"`
	UserID      *string    `json:"userId,omitempty" db:"user_id"`
	Email       *string    `json:"email,omitempty" db:"email"`
	PhoneNumber *string    `json:"phoneNumber,omitempty" db:"phone_number"`
	Code        string     `json:"-" db:"code"` // Never include in JSON
	Type        string     `json:"type" db:"type"`
	ExpiresAt   time.Time  `json:"expiresAt" db:"expires_at"`
	IsUsed      bool       `json:"isUsed" db:"is_used"`
	CreatedAt   time.Time  `json:"createdAt" db:"created_at"`
}

// ContentBlurSettings represents content blur settings table
type ContentBlurSettings struct {
	ID                       string    `json:"id" db:"id"`
	UserID                   string    `json:"userId" db:"user_id"`
	AgeVerificationRequired  bool      `json:"ageVerificationRequired" db:"age_verification_required"`
	VerifyMyCompleted        bool      `json:"verifyMyCompleted" db:"verify_my_completed"`
	ComplianceCompleted      bool      `json:"complianceCompleted" db:"compliance_completed"`
	ContentBlurred           bool      `json:"contentBlurred" db:"content_blurred"`
	BlurLevel                string    `json:"blurLevel" db:"blur_level"`
	AllowedContentTypes      []string  `json:"allowedContentTypes" db:"allowed_content_types"`
	LastVerificationCheck    *time.Time `json:"lastVerificationCheck,omitempty" db:"last_verification_check"`
	CreatedAt                time.Time `json:"createdAt" db:"created_at"`
	UpdatedAt                time.Time `json:"updatedAt" db:"updated_at"`
}