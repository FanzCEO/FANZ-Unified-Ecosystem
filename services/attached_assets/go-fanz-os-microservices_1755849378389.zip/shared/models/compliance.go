package models

import (
	"time"
	"github.com/shopspring/decimal"
)

// ComplianceRecord represents the compliance_records table for 2257 compliance
type ComplianceRecord struct {
	ID                   string           `json:"id" db:"id"`
	UserID               string           `json:"userId" db:"user_id"`
	LegalName            string           `json:"legalName" db:"legal_name"`
	StageName            *string          `json:"stageName,omitempty" db:"stage_name"`
	MaidenName           *string          `json:"maidenName,omitempty" db:"maiden_name"`
	PreviousLegalName    *string          `json:"previousLegalName,omitempty" db:"previous_legal_name"`
	OtherKnownNames      *string          `json:"otherKnownNames,omitempty" db:"other_known_names"`
	DateOfBirth          time.Time        `json:"dateOfBirth" db:"date_of_birth"`
	Age                  int              `json:"age" db:"age"`
	IDType               IDType           `json:"idType" db:"id_type"`
	IDNumber             string           `json:"idNumber" db:"id_number"`
	IDState              *string          `json:"idState,omitempty" db:"id_state"`
	IDCountry            string           `json:"idCountry" db:"id_country"`
	Address              string           `json:"address" db:"address"`
	City                 string           `json:"city" db:"city"`
	State                string           `json:"state" db:"state"`
	ZipCode              string           `json:"zipCode" db:"zip_code"`
	CellPhone            *string          `json:"cellPhone,omitempty" db:"cell_phone"`
	HomePhone            *string          `json:"homePhone,omitempty" db:"home_phone"`
	IDImageURL           string           `json:"idImageUrl" db:"id_image_url"`
	SignatureImageURL    *string          `json:"signatureImageUrl,omitempty" db:"signature_image_url"`
	VerificationType     VerificationType `json:"verificationType" db:"verification_type"`
	Status               ComplianceStatus `json:"status" db:"status"`
	ApprovedBy           *string          `json:"approvedBy,omitempty" db:"approved_by"`
	ApprovedAt           *time.Time       `json:"approvedAt,omitempty" db:"approved_at"`
	ExpiresAt            *time.Time       `json:"expiresAt,omitempty" db:"expires_at"`
	FormData             map[string]interface{} `json:"formData,omitempty" db:"form_data"`
	CreatedAt            time.Time        `json:"createdAt" db:"created_at"`
	UpdatedAt            time.Time        `json:"updatedAt" db:"updated_at"`
}

// CreateComplianceRecordRequest represents request payload for 2257 compliance
type CreateComplianceRecordRequest struct {
	LegalName            string           `json:"legalName" validate:"required,max=100"`
	StageName            *string          `json:"stageName,omitempty" validate:"omitempty,max=100"`
	MaidenName           *string          `json:"maidenName,omitempty" validate:"omitempty,max=100"`
	PreviousLegalName    *string          `json:"previousLegalName,omitempty" validate:"omitempty,max=100"`
	OtherKnownNames      *string          `json:"otherKnownNames,omitempty" validate:"omitempty,max=500"`
	DateOfBirth          time.Time        `json:"dateOfBirth" validate:"required"`
	Age                  int              `json:"age" validate:"required,min=18,max=120"`
	IDType               IDType           `json:"idType" validate:"required"`
	IDNumber             string           `json:"idNumber" validate:"required,max=50"`
	IDState              *string          `json:"idState,omitempty" validate:"omitempty,max=50"`
	IDCountry            string           `json:"idCountry" validate:"required,max=50"`
	Address              string           `json:"address" validate:"required,max=200"`
	City                 string           `json:"city" validate:"required,max=100"`
	State                string           `json:"state" validate:"required,max=50"`
	ZipCode              string           `json:"zipCode" validate:"required,max=20"`
	CellPhone            *string          `json:"cellPhone,omitempty" validate:"omitempty,phone"`
	HomePhone            *string          `json:"homePhone,omitempty" validate:"omitempty,phone"`
	IDImageURL           string           `json:"idImageUrl" validate:"required,url"`
	SignatureImageURL    *string          `json:"signatureImageUrl,omitempty" validate:"omitempty,url"`
	VerificationType     VerificationType `json:"verificationType" validate:"required"`
}

// CostarVerification represents the costar_verifications table
type CostarVerification struct {
	ID                    string           `json:"id" db:"id"`
	PrimaryCreatorID      string           `json:"primaryCreatorId" db:"primary_creator_id"`
	CostarUserID          *string          `json:"costarUserId,omitempty" db:"costar_user_id"`
	CostarEmail           string           `json:"costarEmail" db:"costar_email"`
	CostarName            string           `json:"costarName" db:"costar_name"`
	ComplianceRecordID    *string          `json:"complianceRecordId,omitempty" db:"compliance_record_id"`
	ContentCreationDate   time.Time        `json:"contentCreationDate" db:"content_creation_date"`
	PostID                *string          `json:"postId,omitempty" db:"post_id"`
	Status                ComplianceStatus `json:"status" db:"status"`
	VerificationToken     *string          `json:"verificationToken,omitempty" db:"verification_token"`
	QRCodeURL             *string          `json:"qrCodeUrl,omitempty" db:"qr_code_url"`
	InviteEmailSent       bool             `json:"inviteEmailSent" db:"invite_email_sent"`
	FormCompletedAt       *time.Time       `json:"formCompletedAt,omitempty" db:"form_completed_at"`
	CreatedAt             time.Time        `json:"createdAt" db:"created_at"`
	UpdatedAt             time.Time        `json:"updatedAt" db:"updated_at"`
}

// CreateCostarVerificationRequest represents request payload for co-star verification
type CreateCostarVerificationRequest struct {
	CostarEmail           string    `json:"costarEmail" validate:"required,email"`
	CostarName            string    `json:"costarName" validate:"required,max=100"`
	ContentCreationDate   time.Time `json:"contentCreationDate" validate:"required"`
	PostID                *string   `json:"postId,omitempty" validate:"omitempty,uuid"`
}

// CostarInvitation represents the costar_invitations table
type CostarInvitation struct {
	ID               string    `json:"id" db:"id"`
	PrimaryCreatorID string    `json:"primaryCreatorId" db:"primary_creator_id"`
	CostarEmail      string    `json:"costarEmail" db:"costar_email"`
	CostarName       string    `json:"costarName" db:"costar_name"`
	InviteToken      string    `json:"inviteToken" db:"invite_token"`
	QRCode           *string   `json:"qrCode,omitempty" db:"qr_code"`
	InviteURL        string    `json:"inviteUrl" db:"invite_url"`
	EmailSent        bool      `json:"emailSent" db:"email_sent"`
	IsUsed           bool      `json:"isUsed" db:"is_used"`
	ExpiresAt        time.Time `json:"expiresAt" db:"expires_at"`
	UsedAt           *time.Time `json:"usedAt,omitempty" db:"used_at"`
	CreatedAt        time.Time `json:"createdAt" db:"created_at"`
}

// CreateCostarInvitationRequest represents request payload for creating co-star invitation
type CreateCostarInvitationRequest struct {
	CostarEmail string `json:"costarEmail" validate:"required,email"`
	CostarName  string `json:"costarName" validate:"required,max=100"`
	ExpiresAt   time.Time `json:"expiresAt" validate:"required"`
}

// VerifyMyVerification represents the verify_my_verifications table
type VerifyMyVerification struct {
	ID                 string           `json:"id" db:"id"`
	UserID             string           `json:"userId" db:"user_id"`
	VerifyMySessionID  *string          `json:"verifyMySessionId,omitempty" db:"verify_my_session_id"`
	VerificationType   string           `json:"verificationType" db:"verification_type"`
	Status             VerifyMyStatus   `json:"status" db:"status"`
	AgeVerified        bool             `json:"ageVerified" db:"age_verified"`
	DocumentsVerified  bool             `json:"documentsVerified" db:"documents_verified"`
	IdentityScore      *decimal.Decimal `json:"identityScore,omitempty" db:"identity_score"`
	RiskScore          *decimal.Decimal `json:"riskScore,omitempty" db:"risk_score"`
	VerificationData   map[string]interface{} `json:"verificationData,omitempty" db:"verification_data"`
	CallbackURL        *string          `json:"callbackUrl,omitempty" db:"callback_url"`
	ExpiresAt          *time.Time       `json:"expiresAt,omitempty" db:"expires_at"`
	VerifiedAt         *time.Time       `json:"verifiedAt,omitempty" db:"verified_at"`
	FailureReason      *string          `json:"failureReason,omitempty" db:"failure_reason"`
	RetryCount         int              `json:"retryCount" db:"retry_count"`
	CreatedAt          time.Time        `json:"createdAt" db:"created_at"`
	UpdatedAt          time.Time        `json:"updatedAt" db:"updated_at"`
}

// UploadedDocument represents the uploaded_documents table
type UploadedDocument struct {
	ID                       string       `json:"id" db:"id"`
	UserID                   string       `json:"userId" db:"user_id"`
	VaultID                  *string      `json:"vaultId,omitempty" db:"vault_id"`
	VerifyMyVerificationID   *string      `json:"verifyMyVerificationId,omitempty" db:"verify_my_verification_id"`
	ComplianceRecordID       *string      `json:"complianceRecordId,omitempty" db:"compliance_record_id"`
	DocumentType             DocumentType `json:"documentType" db:"document_type"`
	FileName                 string       `json:"fileName" db:"file_name"`
	FileURL                  string       `json:"fileUrl" db:"file_url"`
	FileSize                 *int         `json:"fileSize,omitempty" db:"file_size"`
	MimeType                 *string      `json:"mimeType,omitempty" db:"mime_type"`
	IsVerified               bool         `json:"isVerified" db:"is_verified"`
	VerificationData         map[string]interface{} `json:"verificationData,omitempty" db:"verification_data"`
	IsPrivate                bool         `json:"isPrivate" db:"is_private"`
	IsAdminOnly              bool         `json:"isAdminOnly" db:"is_admin_only"`
	PropagateAsLogo          bool         `json:"propagateAsLogo" db:"propagate_as_logo"`
	ExpiresAt                *time.Time   `json:"expiresAt,omitempty" db:"expires_at"`
	Metadata                 map[string]interface{} `json:"metadata,omitempty" db:"metadata"`
	CreatedAt                time.Time    `json:"createdAt" db:"created_at"`
	UpdatedAt                time.Time    `json:"updatedAt" db:"updated_at"`
}

// CreateUploadedDocumentRequest represents request payload for uploading documents
type CreateUploadedDocumentRequest struct {
	VaultID                  *string      `json:"vaultId,omitempty" validate:"omitempty,uuid"`
	VerifyMyVerificationID   *string      `json:"verifyMyVerificationId,omitempty" validate:"omitempty,uuid"`
	ComplianceRecordID       *string      `json:"complianceRecordId,omitempty" validate:"omitempty,uuid"`
	DocumentType             DocumentType `json:"documentType" validate:"required"`
	FileName                 string       `json:"fileName" validate:"required,max=255"`
	FileURL                  string       `json:"fileUrl" validate:"required,url"`
	FileSize                 *int         `json:"fileSize,omitempty" validate:"omitempty,min=1"`
	MimeType                 *string      `json:"mimeType,omitempty" validate:"omitempty"`
	IsPrivate                bool         `json:"isPrivate"`
	IsAdminOnly              bool         `json:"isAdminOnly"`
	PropagateAsLogo          bool         `json:"propagateAsLogo"`
	ExpiresAt                *time.Time   `json:"expiresAt,omitempty"`
}

// CreatorVault represents the creator_vaults table
type CreatorVault struct {
	ID                  string     `json:"id" db:"id"`
	CreatorID           string     `json:"creatorId" db:"creator_id"`
	TotalStorageUsed    int        `json:"totalStorageUsed" db:"total_storage_used"`
	StorageLimit        int        `json:"storageLimit" db:"storage_limit"`
	DocumentCount       int        `json:"documentCount" db:"document_count"`
	LogoURL             *string    `json:"logoUrl,omitempty" db:"logo_url"`
	WatermarkLogoURL    *string    `json:"watermarkLogoUrl,omitempty" db:"watermark_logo_url"`
	W9FormURL           *string    `json:"w9FormUrl,omitempty" db:"w9_form_url"`
	W9SubmittedAt       *time.Time `json:"w9SubmittedAt,omitempty" db:"w9_submitted_at"`
	W9ApprovedAt        *time.Time `json:"w9ApprovedAt,omitempty" db:"w9_approved_at"`
	IsLocked            bool       `json:"isLocked" db:"is_locked"`
	LockedReason        *string    `json:"lockedReason,omitempty" db:"locked_reason"`
	CreatedAt           time.Time  `json:"createdAt" db:"created_at"`
	UpdatedAt           time.Time  `json:"updatedAt" db:"updated_at"`
}

// DocumentAccessRequest represents the document_access_requests table
type DocumentAccessRequest struct {
	ID                string     `json:"id" db:"id"`
	DocumentID        string     `json:"documentId" db:"document_id"`
	RequesterID       string     `json:"requesterId" db:"requester_id"`
	DocumentOwnerID   string     `json:"documentOwnerId" db:"document_owner_id"`
	RequestType       string     `json:"requestType" db:"request_type"`
	RequestReason     *string    `json:"requestReason,omitempty" db:"request_reason"`
	Status            string     `json:"status" db:"status"`
	ApprovedBy        *string    `json:"approvedBy,omitempty" db:"approved_by"`
	ApprovedAt        *time.Time `json:"approvedAt,omitempty" db:"approved_at"`
	DeniedReason      *string    `json:"deniedReason,omitempty" db:"denied_reason"`
	AccessExpiresAt   *time.Time `json:"accessExpiresAt,omitempty" db:"access_expires_at"`
	CreatedAt         time.Time  `json:"createdAt" db:"created_at"`
}

// DocumentShareLink represents the document_share_links table
type DocumentShareLink struct {
	ID         string     `json:"id" db:"id"`
	DocumentID string     `json:"documentId" db:"document_id"`
	CreatedBy  string     `json:"createdBy" db:"created_by"`
	ShareToken string     `json:"shareToken" db:"share_token"`
	Password   *string    `json:"-" db:"password"` // Never include in JSON
	MaxViews   *int       `json:"maxViews,omitempty" db:"max_views"`
	ViewCount  int        `json:"viewCount" db:"view_count"`
	ExpiresAt  time.Time  `json:"expiresAt" db:"expires_at"`
	IsActive   bool       `json:"isActive" db:"is_active"`
	CreatedAt  time.Time  `json:"createdAt" db:"created_at"`
}