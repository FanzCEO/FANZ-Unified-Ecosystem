package models

// UserRole represents user roles in the system
type UserRole string

const (
	UserRoleFanz    UserRole = "fanz"
	UserRoleCreator UserRole = "creator"
	UserRoleAdmin   UserRole = "admin"
)

// AuthProvider represents authentication providers
type AuthProvider string

const (
	AuthProviderEmail     AuthProvider = "email"
	AuthProviderPhone     AuthProvider = "phone"
	AuthProviderGoogle    AuthProvider = "google"
	AuthProviderFacebook  AuthProvider = "facebook"
	AuthProviderTwitter   AuthProvider = "twitter"
	AuthProviderInstagram AuthProvider = "instagram"
	AuthProviderReddit    AuthProvider = "reddit"
	AuthProviderTikTok    AuthProvider = "tiktok"
	AuthProviderDiscord   AuthProvider = "discord"
	AuthProviderApple     AuthProvider = "apple"
)

// NotificationType represents notification types
type NotificationType string

const (
	NotificationNewSubscriber     NotificationType = "new_subscriber"
	NotificationNewMessage        NotificationType = "new_message"
	NotificationNewTip            NotificationType = "new_tip"
	NotificationContentLiked      NotificationType = "content_liked"
	NotificationContentCommented  NotificationType = "content_commented"
	NotificationPPVPurchased      NotificationType = "ppv_purchased"
	NotificationCreatorPosted     NotificationType = "creator_posted"
	NotificationReminderToPost    NotificationType = "reminder_to_post"
	NotificationAccountWarning    NotificationType = "account_warning"
	NotificationAchievementUnlocked NotificationType = "achievement_unlocked"
	NotificationLiveStreamStarted NotificationType = "live_stream_started"
	NotificationPaymentReceived   NotificationType = "payment_received"
	NotificationWithdrawalProcessed NotificationType = "withdrawal_processed"
)

// CreatorStatus represents creator account status
type CreatorStatus string

const (
	CreatorStatusActive      CreatorStatus = "active"
	CreatorStatusInactive    CreatorStatus = "inactive"
	CreatorStatusWarning     CreatorStatus = "warning"
	CreatorStatusSuspended   CreatorStatus = "suspended"
	CreatorStatusTopPerformer CreatorStatus = "top_performer"
)

// PostType represents post visibility and monetization
type PostType string

const (
	PostTypeFree            PostType = "free"
	PostTypePPV             PostType = "ppv"
	PostTypeSubscriptionOnly PostType = "subscription_only"
)

// TransactionType represents transaction types
type TransactionType string

const (
	TransactionSubscription TransactionType = "subscription"
	TransactionTip          TransactionType = "tip"
	TransactionPPVUnlock    TransactionType = "ppv_unlock"
	TransactionWithdrawal   TransactionType = "withdrawal"
	TransactionDeposit      TransactionType = "deposit"
)

// ComplianceStatus represents compliance verification status
type ComplianceStatus string

const (
	ComplianceStatusPending     ComplianceStatus = "pending"
	ComplianceStatusApproved    ComplianceStatus = "approved"
	ComplianceStatusRejected    ComplianceStatus = "rejected"
	ComplianceStatusExpired     ComplianceStatus = "expired"
	ComplianceStatusUnderReview ComplianceStatus = "under_review"
)

// IDType represents government ID types
type IDType string

const (
	IDTypeDriversLicense  IDType = "drivers_license"
	IDTypePassport        IDType = "passport"
	IDTypeCitizenship     IDType = "citizenship"
	IDTypeSocialSecurity  IDType = "social_security"
	IDTypeOther           IDType = "other"
)

// VerificationType represents 2257 verification types
type VerificationType string

const (
	VerificationTypePrimaryStar     VerificationType = "primary_star"
	VerificationTypeCoStar          VerificationType = "co_star"
	VerificationTypeAgeVerification VerificationType = "age_verification"
)

// AuditAction represents audit log actions
type AuditAction string

const (
	AuditActionCreated  AuditAction = "created"
	AuditActionUpdated  AuditAction = "updated"
	AuditActionDeleted  AuditAction = "deleted"
	AuditActionApproved AuditAction = "approved"
	AuditActionRejected AuditAction = "rejected"
	AuditActionViewed   AuditAction = "viewed"
	AuditActionExported AuditAction = "exported"
)

// VerifyMyStatus represents VerifyMy verification status
type VerifyMyStatus string

const (
	VerifyMyStatusPending      VerifyMyStatus = "pending"
	VerifyMyStatusInProgress   VerifyMyStatus = "in_progress"
	VerifyMyStatusVerified     VerifyMyStatus = "verified"
	VerifyMyStatusFailed       VerifyMyStatus = "failed"
	VerifyMyStatusExpired      VerifyMyStatus = "expired"
	VerifyMyStatusManualReview VerifyMyStatus = "manual_review"
)

// DocumentType represents document types
type DocumentType string

const (
	DocumentTypeGovernmentID       DocumentType = "government_id"
	DocumentTypePassport           DocumentType = "passport"
	DocumentTypeDriversLicense     DocumentType = "drivers_license"
	DocumentTypeW9Form             DocumentType = "w9_form"
	DocumentTypeW8Form             DocumentType = "w8_form"
	DocumentTypeTaxForm            DocumentType = "tax_form"
	DocumentTypeSelfieWithID       DocumentType = "selfie_with_id"
	DocumentTypeProofOfAddress     DocumentType = "proof_of_address"
	DocumentTypeLogo               DocumentType = "logo"
	DocumentTypeProfileLogo        DocumentType = "profile_logo"
	DocumentTypeWatermarkLogo      DocumentType = "watermark_logo"
	DocumentTypeBanner             DocumentType = "banner"
	DocumentTypeCostarVerification DocumentType = "costar_verification"
	DocumentTypeContract           DocumentType = "contract"
	DocumentTypeReleaseForm        DocumentType = "release_form"
	DocumentTypeOther              DocumentType = "other"
)

// ModerationStatus represents content moderation status
type ModerationStatus string

const (
	ModerationStatusPending       ModerationStatus = "pending"
	ModerationStatusApproved      ModerationStatus = "approved"
	ModerationStatusRejected      ModerationStatus = "rejected"
	ModerationStatusFlagged       ModerationStatus = "flagged"
	ModerationStatusManualReview  ModerationStatus = "manual_review"
	ModerationStatusAppealPending ModerationStatus = "appeal_pending"
)

// ContentClassification represents AI content classification
type ContentClassification string

const (
	ContentClassificationSafe           ContentClassification = "safe"
	ContentClassificationAdultContent   ContentClassification = "adult_content"
	ContentClassificationExplicitNudity ContentClassification = "explicit_nudity"
	ContentClassificationViolence       ContentClassification = "violence"
	ContentClassificationHateSpeech     ContentClassification = "hate_speech"
	ContentClassificationSpam           ContentClassification = "spam"
	ContentClassificationOtherViolation ContentClassification = "other_violation"
)

// ShortVideoStatus represents short video processing status
type ShortVideoStatus string

const (
	ShortVideoStatusDraft      ShortVideoStatus = "draft"
	ShortVideoStatusProcessing ShortVideoStatus = "processing"
	ShortVideoStatusPublished  ShortVideoStatus = "published"
	ShortVideoStatusArchived   ShortVideoStatus = "archived"
	ShortVideoStatusRemoved    ShortVideoStatus = "removed"
)

// VideoEffectType represents video effect types
type VideoEffectType string

const (
	VideoEffectTypeFilter     VideoEffectType = "filter"
	VideoEffectTypeOverlay    VideoEffectType = "overlay"
	VideoEffectTypeTransition VideoEffectType = "transition"
	VideoEffectTypeText       VideoEffectType = "text"
	VideoEffectTypeSticker    VideoEffectType = "sticker"
	VideoEffectTypeMusic      VideoEffectType = "music"
	VideoEffectTypeSpeed      VideoEffectType = "speed"
)

// ReactionType represents user reaction types
type ReactionType string

const (
	ReactionTypeLike      ReactionType = "like"
	ReactionTypeLove      ReactionType = "love"
	ReactionTypeFire      ReactionType = "fire"
	ReactionTypeWow       ReactionType = "wow"
	ReactionTypeLaugh     ReactionType = "laugh"
	ReactionTypeHeartEyes ReactionType = "heart_eyes"
	ReactionTypeTongue    ReactionType = "tongue"
	ReactionTypeWink      ReactionType = "wink"
)

// HashtagCategory represents hashtag categories
type HashtagCategory string

const (
	HashtagCategoryTrending  HashtagCategory = "trending"
	HashtagCategoryAdult     HashtagCategory = "adult"
	HashtagCategoryLifestyle HashtagCategory = "lifestyle"
	HashtagCategoryFitness   HashtagCategory = "fitness"
	HashtagCategoryFashion   HashtagCategory = "fashion"
	HashtagCategoryBeauty    HashtagCategory = "beauty"
	HashtagCategoryFood      HashtagCategory = "food"
	HashtagCategoryTravel    HashtagCategory = "travel"
	HashtagCategoryMusic     HashtagCategory = "music"
	HashtagCategoryDance     HashtagCategory = "dance"
	HashtagCategoryComedy    HashtagCategory = "comedy"
	HashtagCategoryEducation HashtagCategory = "education"
	HashtagCategoryDIY       HashtagCategory = "diy"
	HashtagCategoryOther     HashtagCategory = "other"
)