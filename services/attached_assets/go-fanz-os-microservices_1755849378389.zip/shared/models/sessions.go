package models

import (
	"time"
)

// Session represents the sessions table for session storage
type Session struct {
	Sid    string                 `json:"sid" db:"sid"`
	Sess   map[string]interface{} `json:"sess" db:"sess"`
	Expire time.Time              `json:"expire" db:"expire"`
}

// PerfectCRMSync represents the perfect_crm_sync table
type PerfectCRMSync struct {
	ID           string                 `json:"id" db:"id"`
	EntityType   string                 `json:"entityType" db:"entity_type"`
	EntityID     string                 `json:"entityId" db:"entity_id"`
	CRMContactID *string                `json:"crmContactId,omitempty" db:"crm_contact_id"`
	SyncStatus   string                 `json:"syncStatus" db:"sync_status"`
	LastSyncAt   *time.Time             `json:"lastSyncAt,omitempty" db:"last_sync_at"`
	SyncData     map[string]interface{} `json:"syncData,omitempty" db:"sync_data"`
	ErrorMessage *string                `json:"errorMessage,omitempty" db:"error_message"`
	RetryCount   int                    `json:"retryCount" db:"retry_count"`
	CreatedAt    time.Time              `json:"createdAt" db:"created_at"`
	UpdatedAt    time.Time              `json:"updatedAt" db:"updated_at"`
}

// LiveStream represents live streaming sessions
type LiveStream struct {
	ID               string                 `json:"id" db:"id"`
	CreatorID        string                 `json:"creatorId" db:"creator_id"`
	Title            string                 `json:"title" db:"title"`
	Description      *string                `json:"description,omitempty" db:"description"`
	ThumbnailURL     *string                `json:"thumbnailUrl,omitempty" db:"thumbnail_url"`
	StreamKey        string                 `json:"streamKey" db:"stream_key"`
	StreamURL        string                 `json:"streamUrl" db:"stream_url"`
	PlaybackURL      string                 `json:"playbackUrl" db:"playback_url"`
	Status           string                 `json:"status" db:"status"` // scheduled, live, ended, cancelled
	IsPrivate        bool                   `json:"isPrivate" db:"is_private"`
	MaxViewers       *int                   `json:"maxViewers,omitempty" db:"max_viewers"`
	CurrentViewers   int                    `json:"currentViewers" db:"current_viewers"`
	TotalViews       int                    `json:"totalViews" db:"total_views"`
	Duration         *int                   `json:"duration,omitempty" db:"duration"` // seconds
	ScheduledAt      *time.Time             `json:"scheduledAt,omitempty" db:"scheduled_at"`
	StartedAt        *time.Time             `json:"startedAt,omitempty" db:"started_at"`
	EndedAt          *time.Time             `json:"endedAt,omitempty" db:"ended_at"`
	Settings         map[string]interface{} `json:"settings,omitempty" db:"settings"`
	CreatedAt        time.Time              `json:"createdAt" db:"created_at"`
	UpdatedAt        time.Time              `json:"updatedAt" db:"updated_at"`
}

// CreateLiveStreamRequest represents request payload for creating a live stream
type CreateLiveStreamRequest struct {
	Title        string                 `json:"title" validate:"required,max=200"`
	Description  *string                `json:"description,omitempty" validate:"omitempty,max=1000"`
	ThumbnailURL *string                `json:"thumbnailUrl,omitempty" validate:"omitempty,url"`
	IsPrivate    bool                   `json:"isPrivate"`
	MaxViewers   *int                   `json:"maxViewers,omitempty" validate:"omitempty,min=1,max=10000"`
	ScheduledAt  *time.Time             `json:"scheduledAt,omitempty"`
	Settings     map[string]interface{} `json:"settings,omitempty"`
}

// LiveStreamViewer represents viewers in live streams
type LiveStreamViewer struct {
	ID           string     `json:"id" db:"id"`
	StreamID     string     `json:"streamId" db:"stream_id"`
	UserID       *string    `json:"userId,omitempty" db:"user_id"`
	JoinedAt     time.Time  `json:"joinedAt" db:"joined_at"`
	LeftAt       *time.Time `json:"leftAt,omitempty" db:"left_at"`
	WatchTime    int        `json:"watchTime" db:"watch_time"` // seconds
	IsActive     bool       `json:"isActive" db:"is_active"`
	DeviceType   *string    `json:"deviceType,omitempty" db:"device_type"`
	ConnectionQuality string `json:"connectionQuality" db:"connection_quality"`
}

// LiveStreamChat represents chat messages in live streams
type LiveStreamChat struct {
	ID        string    `json:"id" db:"id"`
	StreamID  string    `json:"streamId" db:"stream_id"`
	UserID    *string   `json:"userId,omitempty" db:"user_id"`
	Username  *string   `json:"username,omitempty" db:"username"`
	Message   string    `json:"message" db:"message"`
	IsDeleted bool      `json:"isDeleted" db:"is_deleted"`
	DeletedBy *string   `json:"deletedBy,omitempty" db:"deleted_by"`
	CreatedAt time.Time `json:"createdAt" db:"created_at"`
}

// CreateLiveStreamChatRequest represents request payload for live stream chat
type CreateLiveStreamChatRequest struct {
	StreamID string `json:"streamId" validate:"required,uuid"`
	Message  string `json:"message" validate:"required,max=500"`
}

// WebRTCConnection represents WebRTC peer connections
type WebRTCConnection struct {
	ID           string                 `json:"id" db:"id"`
	StreamID     string                 `json:"streamId" db:"stream_id"`
	UserID       *string                `json:"userId,omitempty" db:"user_id"`
	PeerID       string                 `json:"peerId" db:"peer_id"`
	ConnectionType string               `json:"connectionType" db:"connection_type"` // publisher, subscriber
	Status       string                 `json:"status" db:"status"`
	ICEState     string                 `json:"iceState" db:"ice_state"`
	SignalingState string              `json:"signalingState" db:"signaling_state"`
	Quality      map[string]interface{} `json:"quality,omitempty" db:"quality"`
	CreatedAt    time.Time              `json:"createdAt" db:"created_at"`
	UpdatedAt    time.Time              `json:"updatedAt" db:"updated_at"`
}