package models

import (
	"time"
	"github.com/shopspring/decimal"
)

// Subscription represents the subscriptions table
type Subscription struct {
	ID        string          `json:"id" db:"id"`
	FanID     string          `json:"fanId" db:"fan_id"`
	CreatorID string          `json:"creatorId" db:"creator_id"`
	IsActive  bool            `json:"isActive" db:"is_active"`
	StartDate time.Time       `json:"startDate" db:"start_date"`
	EndDate   *time.Time      `json:"endDate,omitempty" db:"end_date"`
	Price     decimal.Decimal `json:"price" db:"price"`
	CreatedAt time.Time       `json:"createdAt" db:"created_at"`
	UpdatedAt time.Time       `json:"updatedAt" db:"updated_at"`
}

// CreateSubscriptionRequest represents request payload for creating a subscription
type CreateSubscriptionRequest struct {
	CreatorID string          `json:"creatorId" validate:"required,uuid"`
	Price     decimal.Decimal `json:"price" validate:"required,min=0"`
}

// Message represents the messages table
type Message struct {
	ID         string           `json:"id" db:"id"`
	SenderID   string           `json:"senderId" db:"sender_id"`
	ReceiverID string           `json:"receiverId" db:"receiver_id"`
	Content    string           `json:"content" db:"content"`
	MediaURL   *string          `json:"mediaUrl,omitempty" db:"media_url"`
	IsRead     bool             `json:"isRead" db:"is_read"`
	IsPPV      bool             `json:"isPpv" db:"is_ppv"`
	PPVPrice   *decimal.Decimal `json:"ppvPrice,omitempty" db:"ppv_price"`
	CreatedAt  time.Time        `json:"createdAt" db:"created_at"`
}

// CreateMessageRequest represents request payload for creating a message
type CreateMessageRequest struct {
	ReceiverID string           `json:"receiverId" validate:"required,uuid"`
	Content    string           `json:"content" validate:"required,max=2000"`
	MediaURL   *string          `json:"mediaUrl,omitempty" validate:"omitempty,url"`
	IsPPV      bool             `json:"isPpv"`
	PPVPrice   *decimal.Decimal `json:"ppvPrice,omitempty" validate:"omitempty,min=0"`
}

// Like represents the likes table
type Like struct {
	ID        string    `json:"id" db:"id"`
	UserID    string    `json:"userId" db:"user_id"`
	PostID    string    `json:"postId" db:"post_id"`
	CreatedAt time.Time `json:"createdAt" db:"created_at"`
}

// Comment represents the comments table
type Comment struct {
	ID           string     `json:"id" db:"id"`
	UserID       string     `json:"userId" db:"user_id"`
	PostID       *string    `json:"postId,omitempty" db:"post_id"`
	ShortVideoID *string    `json:"shortVideoId,omitempty" db:"short_video_id"`
	Content      string     `json:"content" db:"content"`
	CreatedAt    time.Time  `json:"createdAt" db:"created_at"`
}

// CreateCommentRequest represents request payload for creating a comment
type CreateCommentRequest struct {
	PostID       *string `json:"postId,omitempty" validate:"required_without=ShortVideoId,omitempty,uuid"`
	ShortVideoID *string `json:"shortVideoId,omitempty" validate:"required_without=PostId,omitempty,uuid"`
	Content      string  `json:"content" validate:"required,max=1000"`
}

// Follow represents following relationships between users
type Follow struct {
	ID          string    `json:"id" db:"id"`
	FollowerID  string    `json:"followerId" db:"follower_id"`
	FollowingID string    `json:"followingId" db:"following_id"`
	CreatedAt   time.Time `json:"createdAt" db:"created_at"`
}

// CreateFollowRequest represents request payload for following a user
type CreateFollowRequest struct {
	FollowingID string `json:"followingId" validate:"required,uuid"`
}

// Notification represents the notifications table
type Notification struct {
	ID           string           `json:"id" db:"id"`
	UserID       string           `json:"userId" db:"user_id"`
	Type         NotificationType `json:"type" db:"type"`
	Title        string           `json:"title" db:"title"`
	Message      string           `json:"message" db:"message"`
	Data         map[string]interface{} `json:"data,omitempty" db:"data"`
	IsRead       bool             `json:"isRead" db:"is_read"`
	IsPushSent   bool             `json:"isPushSent" db:"is_push_sent"`
	IsEmailSent  bool             `json:"isEmailSent" db:"is_email_sent"`
	IsSMSSent    bool             `json:"isSmsSent" db:"is_sms_sent"`
	CreatedAt    time.Time        `json:"createdAt" db:"created_at"`
}

// CreateNotificationRequest represents request payload for creating a notification
type CreateNotificationRequest struct {
	UserID  string           `json:"userId" validate:"required,uuid"`
	Type    NotificationType `json:"type" validate:"required"`
	Title   string           `json:"title" validate:"required,max=100"`
	Message string           `json:"message" validate:"required,max=500"`
	Data    map[string]interface{} `json:"data,omitempty"`
}

// PushSubscription represents the push_subscriptions table
type PushSubscription struct {
	ID         string                 `json:"id" db:"id"`
	UserID     string                 `json:"userId" db:"user_id"`
	Endpoint   string                 `json:"endpoint" db:"endpoint"`
	Keys       map[string]interface{} `json:"keys" db:"keys"`
	DeviceType *string                `json:"deviceType,omitempty" db:"device_type"`
	IsActive   bool                   `json:"isActive" db:"is_active"`
	CreatedAt  time.Time              `json:"createdAt" db:"created_at"`
	UpdatedAt  time.Time              `json:"updatedAt" db:"updated_at"`
}

// CreatePushSubscriptionRequest represents request payload for creating a push subscription
type CreatePushSubscriptionRequest struct {
	Endpoint   string                 `json:"endpoint" validate:"required,url"`
	Keys       map[string]interface{} `json:"keys" validate:"required"`
	DeviceType *string                `json:"deviceType,omitempty" validate:"omitempty,oneof=web ios android"`
}