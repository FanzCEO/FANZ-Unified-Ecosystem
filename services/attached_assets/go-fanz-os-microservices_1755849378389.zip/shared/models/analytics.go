package models

import (
	"time"
	"github.com/shopspring/decimal"
)

// CreatorPerformance represents the creator_performance table
type CreatorPerformance struct {
	ID                  string          `json:"id" db:"id"`
	CreatorID           string          `json:"creatorId" db:"creator_id"`
	WeekStartDate       time.Time       `json:"weekStartDate" db:"week_start_date"`
	WeekEndDate         time.Time       `json:"weekEndDate" db:"week_end_date"`
	PostsCount          int             `json:"postsCount" db:"posts_count"`
	LikesReceived       int             `json:"likesReceived" db:"likes_received"`
	CommentsReceived    int             `json:"commentsReceived" db:"comments_received"`
	NewSubscribers      int             `json:"newSubscribers" db:"new_subscribers"`
	EarningsAmount      decimal.Decimal `json:"earningsAmount" db:"earnings_amount"`
	IsTopPerformer      bool            `json:"isTopPerformer" db:"is_top_performer"`
	LastReminderSent    *time.Time      `json:"lastReminderSent,omitempty" db:"last_reminder_sent"`
	ReminderCount       int             `json:"reminderCount" db:"reminder_count"`
	CreatedAt           time.Time       `json:"createdAt" db:"created_at"`
}

// StreamingMetrics represents the streaming_metrics table
type StreamingMetrics struct {
	ID               string     `json:"id" db:"id"`
	UserID           *string    `json:"userId,omitempty" db:"user_id"`
	MediaID          *string    `json:"mediaId,omitempty" db:"media_id"`
	BufferingTime    int        `json:"bufferingTime" db:"buffering_time"`
	LoadTime         int        `json:"loadTime" db:"load_time"`
	QualitySwitches  int        `json:"qualitySwitches" db:"quality_switches"`
	Dropouts         int        `json:"dropouts" db:"dropouts"`
	AverageBitrate   int        `json:"averageBitrate" db:"average_bitrate"`
	UserAgent        *string    `json:"userAgent,omitempty" db:"user_agent"`
	ConnectionSpeed  int        `json:"connectionSpeed" db:"connection_speed"`
	Timestamp        time.Time  `json:"timestamp" db:"timestamp"`
}

// CreateStreamingMetricsRequest represents request payload for streaming metrics
type CreateStreamingMetricsRequest struct {
	MediaID          *string `json:"mediaId,omitempty" validate:"omitempty,uuid"`
	BufferingTime    int     `json:"bufferingTime" validate:"min=0"`
	LoadTime         int     `json:"loadTime" validate:"min=0"`
	QualitySwitches  int     `json:"qualitySwitches" validate:"min=0"`
	Dropouts         int     `json:"dropouts" validate:"min=0"`
	AverageBitrate   int     `json:"averageBitrate" validate:"min=0"`
	ConnectionSpeed  int     `json:"connectionSpeed" validate:"min=0"`
}

// AnalyticsEvent represents custom analytics events
type AnalyticsEvent struct {
	ID         string                 `json:"id" db:"id"`
	UserID     *string                `json:"userId,omitempty" db:"user_id"`
	SessionID  *string                `json:"sessionId,omitempty" db:"session_id"`
	EventType  string                 `json:"eventType" db:"event_type"`
	EventName  string                 `json:"eventName" db:"event_name"`
	Properties map[string]interface{} `json:"properties,omitempty" db:"properties"`
	DeviceInfo map[string]interface{} `json:"deviceInfo,omitempty" db:"device_info"`
	Location   map[string]interface{} `json:"location,omitempty" db:"location"`
	Timestamp  time.Time              `json:"timestamp" db:"timestamp"`
}

// CreateAnalyticsEventRequest represents request payload for analytics events
type CreateAnalyticsEventRequest struct {
	SessionID  *string                `json:"sessionId,omitempty" validate:"omitempty,uuid"`
	EventType  string                 `json:"eventType" validate:"required,max=50"`
	EventName  string                 `json:"eventName" validate:"required,max=100"`
	Properties map[string]interface{} `json:"properties,omitempty"`
	DeviceInfo map[string]interface{} `json:"deviceInfo,omitempty"`
	Location   map[string]interface{} `json:"location,omitempty"`
}

// UserSession represents user session tracking
type UserSession struct {
	ID            string                 `json:"id" db:"id"`
	UserID        *string                `json:"userId,omitempty" db:"user_id"`
	SessionToken  string                 `json:"sessionToken" db:"session_token"`
	DeviceInfo    map[string]interface{} `json:"deviceInfo,omitempty" db:"device_info"`
	IPAddress     string                 `json:"ipAddress" db:"ip_address"`
	UserAgent     string                 `json:"userAgent" db:"user_agent"`
	StartTime     time.Time              `json:"startTime" db:"start_time"`
	LastActivity  time.Time              `json:"lastActivity" db:"last_activity"`
	Duration      *int                   `json:"duration,omitempty" db:"duration"` // seconds
	IsActive      bool                   `json:"isActive" db:"is_active"`
	EndTime       *time.Time             `json:"endTime,omitempty" db:"end_time"`
}

// ContentAnalytics represents content performance analytics
type ContentAnalytics struct {
	ID                string          `json:"id" db:"id"`
	ContentType       string          `json:"contentType" db:"content_type"`
	ContentID         string          `json:"contentId" db:"content_id"`
	CreatorID         string          `json:"creatorId" db:"creator_id"`
	Views             int             `json:"views" db:"views"`
	UniqueViews       int             `json:"uniqueViews" db:"unique_views"`
	Likes             int             `json:"likes" db:"likes"`
	Comments          int             `json:"comments" db:"comments"`
	Shares            int             `json:"shares" db:"shares"`
	EngagementRate    decimal.Decimal `json:"engagementRate" db:"engagement_rate"`
	AvgWatchTime      *int            `json:"avgWatchTime,omitempty" db:"avg_watch_time"`
	CompletionRate    *decimal.Decimal `json:"completionRate,omitempty" db:"completion_rate"`
	Revenue           decimal.Decimal `json:"revenue" db:"revenue"`
	Date              time.Time       `json:"date" db:"date"`
	CreatedAt         time.Time       `json:"createdAt" db:"created_at"`
	UpdatedAt         time.Time       `json:"updatedAt" db:"updated_at"`
}

// RevenueAnalytics represents revenue tracking and analytics
type RevenueAnalytics struct {
	ID                    string          `json:"id" db:"id"`
	UserID                string          `json:"userId" db:"user_id"`
	Date                  time.Time       `json:"date" db:"date"`
	SubscriptionRevenue   decimal.Decimal `json:"subscriptionRevenue" db:"subscription_revenue"`
	TipRevenue            decimal.Decimal `json:"tipRevenue" db:"tip_revenue"`
	PPVRevenue            decimal.Decimal `json:"ppvRevenue" db:"ppv_revenue"`
	TotalRevenue          decimal.Decimal `json:"totalRevenue" db:"total_revenue"`
	PlatformFees          decimal.Decimal `json:"platformFees" db:"platform_fees"`
	NetRevenue            decimal.Decimal `json:"netRevenue" db:"net_revenue"`
	NewSubscribers        int             `json:"newSubscribers" db:"new_subscribers"`
	TotalSubscribers      int             `json:"totalSubscribers" db:"total_subscribers"`
	ChurnedSubscribers    int             `json:"churnedSubscribers" db:"churned_subscribers"`
	RetentionRate         decimal.Decimal `json:"retentionRate" db:"retention_rate"`
	CreatedAt             time.Time       `json:"createdAt" db:"created_at"`
	UpdatedAt             time.Time       `json:"updatedAt" db:"updated_at"`
}

// PlatformAnalytics represents overall platform analytics
type PlatformAnalytics struct {
	ID                  string          `json:"id" db:"id"`
	Date                time.Time       `json:"date" db:"date"`
	TotalUsers          int             `json:"totalUsers" db:"total_users"`
	ActiveUsers         int             `json:"activeUsers" db:"active_users"`
	NewSignups          int             `json:"newSignups" db:"new_signups"`
	TotalCreators       int             `json:"totalCreators" db:"total_creators"`
	ActiveCreators      int             `json:"activeCreators" db:"active_creators"`
	TotalRevenue        decimal.Decimal `json:"totalRevenue" db:"total_revenue"`
	PlatformRevenue     decimal.Decimal `json:"platformRevenue" db:"platform_revenue"`
	CreatorEarnings     decimal.Decimal `json:"creatorEarnings" db:"creator_earnings"`
	TotalContent        int             `json:"totalContent" db:"total_content"`
	ContentViews        int             `json:"contentViews" db:"content_views"`
	AvgSessionDuration  int             `json:"avgSessionDuration" db:"avg_session_duration"`
	CreatedAt           time.Time       `json:"createdAt" db:"created_at"`
}

// EngagementMetrics represents user engagement tracking
type EngagementMetrics struct {
	ID                string          `json:"id" db:"id"`
	UserID            string          `json:"userId" db:"user_id"`
	Date              time.Time       `json:"date" db:"date"`
	SessionCount      int             `json:"sessionCount" db:"session_count"`
	TotalSessionTime  int             `json:"totalSessionTime" db:"total_session_time"`
	ContentViewed     int             `json:"contentViewed" db:"content_viewed"`
	LikesGiven        int             `json:"likesGiven" db:"likes_given"`
	CommentsPosted    int             `json:"commentsPosted" db:"comments_posted"`
	SharesPerformed   int             `json:"sharesPerformed" db:"shares_performed"`
	MessagesExchanged int             `json:"messagesExchanged" db:"messages_exchanged"`
	EngagementScore   decimal.Decimal `json:"engagementScore" db:"engagement_score"`
	CreatedAt         time.Time       `json:"createdAt" db:"created_at"`
}