package models

import (
	"time"
	"github.com/shopspring/decimal"
)

// Transaction represents the transactions table
type Transaction struct {
	ID             string            `json:"id" db:"id"`
	UserID         string            `json:"userId" db:"user_id"`
	RecipientID    *string           `json:"recipientId,omitempty" db:"recipient_id"`
	Type           TransactionType   `json:"type" db:"type"`
	Amount         decimal.Decimal   `json:"amount" db:"amount"`
	Description    *string           `json:"description,omitempty" db:"description"`
	PostID         *string           `json:"postId,omitempty" db:"post_id"`
	MessageID      *string           `json:"messageId,omitempty" db:"message_id"`
	SubscriptionID *string           `json:"subscriptionId,omitempty" db:"subscription_id"`
	CreatedAt      time.Time         `json:"createdAt" db:"created_at"`
}

// CreateTransactionRequest represents request payload for creating a transaction
type CreateTransactionRequest struct {
	RecipientID    *string         `json:"recipientId,omitempty" validate:"omitempty,uuid"`
	Type           TransactionType `json:"type" validate:"required,oneof=subscription tip ppv_unlock withdrawal deposit"`
	Amount         decimal.Decimal `json:"amount" validate:"required,min=0"`
	Description    *string         `json:"description,omitempty" validate:"omitempty,max=500"`
	PostID         *string         `json:"postId,omitempty" validate:"omitempty,uuid"`
	MessageID      *string         `json:"messageId,omitempty" validate:"omitempty,uuid"`
	SubscriptionID *string         `json:"subscriptionId,omitempty" validate:"omitempty,uuid"`
}

// PPVUnlock represents the ppv_unlocks table
type PPVUnlock struct {
	ID        string          `json:"id" db:"id"`
	UserID    string          `json:"userId" db:"user_id"`
	PostID    *string         `json:"postId,omitempty" db:"post_id"`
	MessageID *string         `json:"messageId,omitempty" db:"message_id"`
	Price     decimal.Decimal `json:"price" db:"price"`
	CreatedAt time.Time       `json:"createdAt" db:"created_at"`
}

// CreatePPVUnlockRequest represents request payload for unlocking PPV content
type CreatePPVUnlockRequest struct {
	PostID    *string         `json:"postId,omitempty" validate:"required_without=MessageId,omitempty,uuid"`
	MessageID *string         `json:"messageId,omitempty" validate:"required_without=PostId,omitempty,uuid"`
	Price     decimal.Decimal `json:"price" validate:"required,min=0"`
}

// PaymentMethod represents supported payment methods
type PaymentMethod struct {
	ID         string    `json:"id" db:"id"`
	UserID     string    `json:"userId" db:"user_id"`
	Type       string    `json:"type" db:"type"` // stripe, crypto, ccbill
	Provider   string    `json:"provider" db:"provider"`
	ExternalID string    `json:"externalId" db:"external_id"`
	IsDefault  bool      `json:"isDefault" db:"is_default"`
	IsActive   bool      `json:"isActive" db:"is_active"`
	Metadata   map[string]interface{} `json:"metadata" db:"metadata"`
	CreatedAt  time.Time `json:"createdAt" db:"created_at"`
	UpdatedAt  time.Time `json:"updatedAt" db:"updated_at"`
}

// CreatePaymentMethodRequest represents request payload for adding a payment method
type CreatePaymentMethodRequest struct {
	Type       string                 `json:"type" validate:"required,oneof=stripe crypto ccbill"`
	Provider   string                 `json:"provider" validate:"required"`
	ExternalID string                 `json:"externalId" validate:"required"`
	IsDefault  bool                   `json:"isDefault"`
	Metadata   map[string]interface{} `json:"metadata,omitempty"`
}

// Withdrawal represents withdrawal requests
type Withdrawal struct {
	ID            string          `json:"id" db:"id"`
	UserID        string          `json:"userId" db:"user_id"`
	Amount        decimal.Decimal `json:"amount" db:"amount"`
	Method        string          `json:"method" db:"method"`
	Status        string          `json:"status" db:"status"`
	ProcessedAt   *time.Time      `json:"processedAt,omitempty" db:"processed_at"`
	ExternalTxnID *string         `json:"externalTxnId,omitempty" db:"external_txn_id"`
	CreatedAt     time.Time       `json:"createdAt" db:"created_at"`
	UpdatedAt     time.Time       `json:"updatedAt" db:"updated_at"`
}

// CreateWithdrawalRequest represents request payload for withdrawal
type CreateWithdrawalRequest struct {
	Amount decimal.Decimal `json:"amount" validate:"required,min=10"`
	Method string          `json:"method" validate:"required,oneof=bank_transfer crypto paypal"`
}

// Tip represents tipping transactions
type Tip struct {
	ID          string          `json:"id" db:"id"`
	SenderID    string          `json:"senderId" db:"sender_id"`
	RecipientID string          `json:"recipientId" db:"recipient_id"`
	Amount      decimal.Decimal `json:"amount" db:"amount"`
	Message     *string         `json:"message,omitempty" db:"message"`
	PostID      *string         `json:"postId,omitempty" db:"post_id"`
	IsAnonymous bool            `json:"isAnonymous" db:"is_anonymous"`
	CreatedAt   time.Time       `json:"createdAt" db:"created_at"`
}

// CreateTipRequest represents request payload for tipping
type CreateTipRequest struct {
	RecipientID string          `json:"recipientId" validate:"required,uuid"`
	Amount      decimal.Decimal `json:"amount" validate:"required,min=1"`
	Message     *string         `json:"message,omitempty" validate:"omitempty,max=200"`
	PostID      *string         `json:"postId,omitempty" validate:"omitempty,uuid"`
	IsAnonymous bool            `json:"isAnonymous"`
}

// Earning represents creator earnings breakdown
type Earning struct {
	ID            string          `json:"id" db:"id"`
	UserID        string          `json:"userId" db:"user_id"`
	SourceType    string          `json:"sourceType" db:"source_type"` // subscription, tip, ppv, etc.
	SourceID      *string         `json:"sourceId,omitempty" db:"source_id"`
	Amount        decimal.Decimal `json:"amount" db:"amount"`
	PlatformFee   decimal.Decimal `json:"platformFee" db:"platform_fee"`
	NetAmount     decimal.Decimal `json:"netAmount" db:"net_amount"`
	PayoutStatus  string          `json:"payoutStatus" db:"payout_status"`
	PayoutDate    *time.Time      `json:"payoutDate,omitempty" db:"payout_date"`
	CreatedAt     time.Time       `json:"createdAt" db:"created_at"`
}