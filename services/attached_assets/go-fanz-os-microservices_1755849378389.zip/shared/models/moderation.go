package models

import (
	"time"
	"github.com/shopspring/decimal"
)

// ModerationResult represents the moderation_results table for AI content moderation
type ModerationResult struct {
	ID                    string                 `json:"id" db:"id"`
	EntityType            string                 `json:"entityType" db:"entity_type"`
	EntityID              string                 `json:"entityId" db:"entity_id"`
	ModerationService     string                 `json:"moderationService" db:"moderation_service"`
	Status                ModerationStatus       `json:"status" db:"status"`
	Classification        ContentClassification `json:"classification" db:"classification"`
	ConfidenceScore       *decimal.Decimal       `json:"confidenceScore,omitempty" db:"confidence_score"`
	FlaggedCategories     []string              `json:"flaggedCategories" db:"flagged_categories"`
	ModerationData        map[string]interface{} `json:"moderationData,omitempty" db:"moderation_data"`
	HumanReviewRequired   bool                   `json:"humanReviewRequired" db:"human_review_required"`
	ReviewedBy            *string                `json:"reviewedBy,omitempty" db:"reviewed_by"`
	ReviewedAt            *time.Time             `json:"reviewedAt,omitempty" db:"reviewed_at"`
	ReviewNotes           *string                `json:"reviewNotes,omitempty" db:"review_notes"`
	AppealSubmitted       bool                   `json:"appealSubmitted" db:"appeal_submitted"`
	AppealData            map[string]interface{} `json:"appealData,omitempty" db:"appeal_data"`
	CreatedAt             time.Time              `json:"createdAt" db:"created_at"`
	UpdatedAt             time.Time              `json:"updatedAt" db:"updated_at"`
}

// CreateModerationResultRequest represents request payload for moderation results
type CreateModerationResultRequest struct {
	EntityType            string                 `json:"entityType" validate:"required,max=50"`
	EntityID              string                 `json:"entityId" validate:"required,uuid"`
	ModerationService     string                 `json:"moderationService" validate:"required,max=50"`
	Status                ModerationStatus       `json:"status" validate:"required"`
	Classification        ContentClassification `json:"classification" validate:"required"`
	ConfidenceScore       *decimal.Decimal       `json:"confidenceScore,omitempty" validate:"omitempty,min=0,max=100"`
	FlaggedCategories     []string              `json:"flaggedCategories,omitempty"`
	ModerationData        map[string]interface{} `json:"moderationData,omitempty"`
	HumanReviewRequired   bool                   `json:"humanReviewRequired"`
}

// UpdateModerationResultRequest represents request payload for updating moderation results
type UpdateModerationResultRequest struct {
	Status       ModerationStatus       `json:"status" validate:"required"`
	ReviewNotes  *string                `json:"reviewNotes,omitempty" validate:"omitempty,max=1000"`
	AppealData   map[string]interface{} `json:"appealData,omitempty"`
}

// AuditLog represents the audit_log table for compliance and security tracking
type AuditLog struct {
	ID            string                 `json:"id" db:"id"`
	EntityType    string                 `json:"entityType" db:"entity_type"`
	EntityID      string                 `json:"entityId" db:"entity_id"`
	Action        AuditAction            `json:"action" db:"action"`
	PerformedBy   string                 `json:"performedBy" db:"performed_by"`
	IPAddress     *string                `json:"ipAddress,omitempty" db:"ip_address"`
	UserAgent     *string                `json:"userAgent,omitempty" db:"user_agent"`
	Changes       map[string]interface{} `json:"changes,omitempty" db:"changes"`
	Reason        *string                `json:"reason,omitempty" db:"reason"`
	Timestamp     time.Time              `json:"timestamp" db:"timestamp"`
	RetentionUntil time.Time             `json:"retentionUntil" db:"retention_until"`
}

// CreateAuditLogRequest represents request payload for audit logging
type CreateAuditLogRequest struct {
	EntityType  string                 `json:"entityType" validate:"required,max=50"`
	EntityID    string                 `json:"entityId" validate:"required,uuid"`
	Action      AuditAction            `json:"action" validate:"required"`
	IPAddress   *string                `json:"ipAddress,omitempty" validate:"omitempty,ip"`
	UserAgent   *string                `json:"userAgent,omitempty" validate:"omitempty,max=500"`
	Changes     map[string]interface{} `json:"changes,omitempty"`
	Reason      *string                `json:"reason,omitempty" validate:"omitempty,max=500"`
}

// ReportedContent represents user reports for content moderation
type ReportedContent struct {
	ID           string    `json:"id" db:"id"`
	ReporterID   string    `json:"reporterId" db:"reporter_id"`
	ContentType  string    `json:"contentType" db:"content_type"`
	ContentID    string    `json:"contentId" db:"content_id"`
	ReportType   string    `json:"reportType" db:"report_type"`
	Description  *string   `json:"description,omitempty" db:"description"`
	Status       string    `json:"status" db:"status"`
	ReviewedBy   *string   `json:"reviewedBy,omitempty" db:"reviewed_by"`
	ReviewedAt   *time.Time `json:"reviewedAt,omitempty" db:"reviewed_at"`
	Resolution   *string   `json:"resolution,omitempty" db:"resolution"`
	CreatedAt    time.Time `json:"createdAt" db:"created_at"`
	UpdatedAt    time.Time `json:"updatedAt" db:"updated_at"`
}

// CreateReportRequest represents request payload for reporting content
type CreateReportRequest struct {
	ContentType string  `json:"contentType" validate:"required,oneof=post message user profile"`
	ContentID   string  `json:"contentId" validate:"required,uuid"`
	ReportType  string  `json:"reportType" validate:"required,oneof=spam harassment hate_speech violence copyright nudity other"`
	Description *string `json:"description,omitempty" validate:"omitempty,max=1000"`
}

// ContentFlag represents automated content flagging
type ContentFlag struct {
	ID             string                 `json:"id" db:"id"`
	ContentType    string                 `json:"contentType" db:"content_type"`
	ContentID      string                 `json:"contentId" db:"content_id"`
	FlagType       string                 `json:"flagType" db:"flag_type"`
	Confidence     decimal.Decimal        `json:"confidence" db:"confidence"`
	Source         string                 `json:"source" db:"source"` // ai, user_report, admin
	Metadata       map[string]interface{} `json:"metadata,omitempty" db:"metadata"`
	Status         string                 `json:"status" db:"status"`
	ReviewedBy     *string                `json:"reviewedBy,omitempty" db:"reviewed_by"`
	ReviewedAt     *time.Time             `json:"reviewedAt,omitempty" db:"reviewed_at"`
	CreatedAt      time.Time              `json:"createdAt" db:"created_at"`
	UpdatedAt      time.Time              `json:"updatedAt" db:"updated_at"`
}

// TrustScore represents user trust and safety scores
type TrustScore struct {
	ID                    string          `json:"id" db:"id"`
	UserID                string          `json:"userId" db:"user_id"`
	OverallScore          decimal.Decimal `json:"overallScore" db:"overall_score"`
	ContentQualityScore   decimal.Decimal `json:"contentQualityScore" db:"content_quality_score"`
	CommunityEngagement   decimal.Decimal `json:"communityEngagement" db:"community_engagement"`
	ComplianceScore       decimal.Decimal `json:"complianceScore" db:"compliance_score"`
	WarningCount          int             `json:"warningCount" db:"warning_count"`
	SuspensionCount       int             `json:"suspensionCount" db:"suspension_count"`
	LastViolationDate     *time.Time      `json:"lastViolationDate,omitempty" db:"last_violation_date"`
	LastCalculatedAt      time.Time       `json:"lastCalculatedAt" db:"last_calculated_at"`
	CreatedAt             time.Time       `json:"createdAt" db:"created_at"`
	UpdatedAt             time.Time       `json:"updatedAt" db:"updated_at"`
}