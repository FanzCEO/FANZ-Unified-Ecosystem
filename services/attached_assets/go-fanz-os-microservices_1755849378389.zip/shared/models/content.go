package models

import (
	"time"
	"github.com/shopspring/decimal"
)

// Post represents the posts table
type Post struct {
	ID            string          `json:"id" db:"id"`
	CreatorID     string          `json:"creatorId" db:"creator_id"`
	Title         *string         `json:"title,omitempty" db:"title"`
	Content       string          `json:"content" db:"content"`
	MediaURL      *string         `json:"mediaUrl,omitempty" db:"media_url"`
	MediaType     *string         `json:"mediaType,omitempty" db:"media_type"`
	ContentType   string          `json:"contentType" db:"content_type"`
	PostType      PostType        `json:"postType" db:"post_type"`
	Visibility    string          `json:"visibility" db:"visibility"`
	Tags          *string         `json:"tags,omitempty" db:"tags"`
	PPVPrice      *decimal.Decimal `json:"ppvPrice,omitempty" db:"ppv_price"`
	LikesCount    int             `json:"likesCount" db:"likes_count"`
	CommentsCount int             `json:"commentsCount" db:"comments_count"`
	ViewsCount    int             `json:"viewsCount" db:"views_count"`
	SharesCount   int             `json:"sharesCount" db:"shares_count"`
	CreatedAt     time.Time       `json:"createdAt" db:"created_at"`
	UpdatedAt     time.Time       `json:"updatedAt" db:"updated_at"`
}

// CreatePostRequest represents request payload for creating a post
type CreatePostRequest struct {
	Title       *string         `json:"title,omitempty" validate:"omitempty,max=200"`
	Content     string          `json:"content" validate:"required,max=5000"`
	MediaURL    *string         `json:"mediaUrl,omitempty" validate:"omitempty,url"`
	MediaType   *string         `json:"mediaType,omitempty" validate:"omitempty,oneof=image video audio"`
	ContentType string          `json:"contentType" validate:"omitempty,max=50"`
	PostType    PostType        `json:"postType" validate:"required,oneof=free ppv subscription_only"`
	Visibility  string          `json:"visibility" validate:"omitempty,oneof=public private"`
	Tags        *string         `json:"tags,omitempty" validate:"omitempty,max=500"`
	PPVPrice    *decimal.Decimal `json:"ppvPrice,omitempty" validate:"omitempty,min=0"`
}

// ShortVideo represents the short_videos table
type ShortVideo struct {
	ID               string               `json:"id" db:"id"`
	CreatorID        string               `json:"creatorId" db:"creator_id"`
	Title            *string              `json:"title,omitempty" db:"title"`
	Description      *string              `json:"description,omitempty" db:"description"`
	Tags             *string              `json:"tags,omitempty" db:"tags"`
	VideoURL         string               `json:"videoUrl" db:"video_url"`
	ThumbnailURL     *string              `json:"thumbnailUrl,omitempty" db:"thumbnail_url"`
	Duration         int                  `json:"duration" db:"duration"`
	AspectRatio      string               `json:"aspectRatio" db:"aspect_ratio"`
	Resolution       string               `json:"resolution" db:"resolution"`
	FileSize         *int                 `json:"fileSize,omitempty" db:"file_size"`
	Status           ShortVideoStatus     `json:"status" db:"status"`
	IsPublic         bool                 `json:"isPublic" db:"is_public"`
	AllowComments    bool                 `json:"allowComments" db:"allow_comments"`
	AllowDuets       bool                 `json:"allowDuets" db:"allow_duets"`
	AllowRemix       bool                 `json:"allowRemix" db:"allow_remix"`
	ViewsCount       int                  `json:"viewsCount" db:"views_count"`
	LikesCount       int                  `json:"likesCount" db:"likes_count"`
	CommentsCount    int                  `json:"commentsCount" db:"comments_count"`
	SharesCount      int                  `json:"sharesCount" db:"shares_count"`
	EngagementScore  decimal.Decimal      `json:"engagementScore" db:"engagement_score"`
	AlgorithmBoost   decimal.Decimal      `json:"algorithmBoost" db:"algorithm_boost"`
	CreatedAt        time.Time            `json:"createdAt" db:"created_at"`
	PublishedAt      *time.Time           `json:"publishedAt,omitempty" db:"published_at"`
	UpdatedAt        time.Time            `json:"updatedAt" db:"updated_at"`
}

// CreateShortVideoRequest represents request payload for creating a short video
type CreateShortVideoRequest struct {
	Title         *string              `json:"title,omitempty" validate:"omitempty,max=100"`
	Description   *string              `json:"description,omitempty" validate:"omitempty,max=1000"`
	Tags          *string              `json:"tags,omitempty" validate:"omitempty,max=500"`
	VideoURL      string               `json:"videoUrl" validate:"required,url"`
	ThumbnailURL  *string              `json:"thumbnailUrl,omitempty" validate:"omitempty,url"`
	Duration      int                  `json:"duration" validate:"required,min=1,max=300"`
	AspectRatio   string               `json:"aspectRatio" validate:"omitempty,oneof=9:16 16:9 1:1"`
	Resolution    string               `json:"resolution" validate:"omitempty"`
	IsPublic      bool                 `json:"isPublic"`
	AllowComments bool                 `json:"allowComments"`
	AllowDuets    bool                 `json:"allowDuets"`
	AllowRemix    bool                 `json:"allowRemix"`
}

// VideoEffect represents the video_effects table
type VideoEffect struct {
	ID           string               `json:"id" db:"id"`
	ShortVideoID string               `json:"shortVideoId" db:"short_video_id"`
	EffectType   VideoEffectType      `json:"effectType" db:"effect_type"`
	EffectID     string               `json:"effectId" db:"effect_id"`
	EffectName   string               `json:"effectName" db:"effect_name"`
	StartTime    *decimal.Decimal     `json:"startTime,omitempty" db:"start_time"`
	EndTime      *decimal.Decimal     `json:"endTime,omitempty" db:"end_time"`
	Intensity    decimal.Decimal      `json:"intensity" db:"intensity"`
	Parameters   map[string]interface{} `json:"parameters" db:"parameters"`
	LayerOrder   int                  `json:"layerOrder" db:"layer_order"`
	CreatedAt    time.Time            `json:"createdAt" db:"created_at"`
}

// Hashtag represents the hashtags table
type Hashtag struct {
	ID            string          `json:"id" db:"id"`
	Name          string          `json:"name" db:"name"`
	Category      HashtagCategory `json:"category" db:"category"`
	UsageCount    int             `json:"usageCount" db:"usage_count"`
	TrendingScore decimal.Decimal `json:"trendingScore" db:"trending_score"`
	IsBlocked     bool            `json:"isBlocked" db:"is_blocked"`
	CreatedAt     time.Time       `json:"createdAt" db:"created_at"`
	LastUsed      time.Time       `json:"lastUsed" db:"last_used"`
}

// ShortVideoHashtag represents the junction table between short videos and hashtags
type ShortVideoHashtag struct {
	ID           string    `json:"id" db:"id"`
	ShortVideoID string    `json:"shortVideoId" db:"short_video_id"`
	HashtagID    string    `json:"hashtagId" db:"hashtag_id"`
	CreatedAt    time.Time `json:"createdAt" db:"created_at"`
}

// ShortVideoReaction represents the short_video_reactions table
type ShortVideoReaction struct {
	ID           string       `json:"id" db:"id"`
	UserID       string       `json:"userId" db:"user_id"`
	ShortVideoID string       `json:"shortVideoId" db:"short_video_id"`
	ReactionType ReactionType `json:"reactionType" db:"reaction_type"`
	CreatedAt    time.Time    `json:"createdAt" db:"created_at"`
}

// ShortVideoView represents the short_video_views table for analytics
type ShortVideoView struct {
	ID            string     `json:"id" db:"id"`
	UserID        *string    `json:"userId,omitempty" db:"user_id"`
	ShortVideoID  string     `json:"shortVideoId" db:"short_video_id"`
	WatchTime     int        `json:"watchTime" db:"watch_time"`
	Completed     bool       `json:"completed" db:"completed"`
	CompletedView bool       `json:"completedView" db:"completed_view"`
	DeviceType    *string    `json:"deviceType,omitempty" db:"device_type"`
	IPAddress     *string    `json:"ipAddress,omitempty" db:"ip_address"`
	UserAgent     *string    `json:"userAgent,omitempty" db:"user_agent"`
	Referrer      *string    `json:"referrer,omitempty" db:"referrer"`
	CreatedAt     time.Time  `json:"createdAt" db:"created_at"`
}

// MediaAsset represents the media_assets table for processed media files
type MediaAsset struct {
	ID               string    `json:"id" db:"id"`
	UserID           string    `json:"userId" db:"user_id"`
	OriginalFilename string    `json:"originalFilename" db:"original_filename"`
	Quality          string    `json:"quality" db:"quality"`
	Format           string    `json:"format" db:"format"`
	Size             int       `json:"size" db:"size"`
	Dimensions       *string   `json:"dimensions,omitempty" db:"dimensions"`
	URL              string    `json:"url" db:"url"`
	Bitrate          *int      `json:"bitrate,omitempty" db:"bitrate"`
	Duration         *int      `json:"duration,omitempty" db:"duration"`
	ProcessingTime   *int      `json:"processingTime,omitempty" db:"processing_time"`
	Metadata         *string   `json:"metadata,omitempty" db:"metadata"`
	CreatedAt        time.Time `json:"createdAt" db:"created_at"`
	UpdatedAt        time.Time `json:"updatedAt" db:"updated_at"`
}

// BlogPost represents the blog_posts table for SEO-optimized content
type BlogPost struct {
	ID               string              `json:"id" db:"id"`
	CreatorID        string              `json:"creatorId" db:"creator_id"`
	Title            string              `json:"title" db:"title"`
	Content          string              `json:"content" db:"content"`
	Excerpt          *string             `json:"excerpt,omitempty" db:"excerpt"`
	Slug             string              `json:"slug" db:"slug"`
	FeaturedImage    *string             `json:"featuredImage,omitempty" db:"featured_image"`
	Tags             *string             `json:"tags,omitempty" db:"tags"`
	Categories       *string             `json:"categories,omitempty" db:"categories"`
	PublishedAt      *time.Time          `json:"publishedAt,omitempty" db:"published_at"`
	SEOOptimization  *string             `json:"seoOptimization,omitempty" db:"seo_optimization"`
	IsPublished      bool                `json:"isPublished" db:"is_published"`
	ViewCount        int                 `json:"viewCount" db:"view_count"`
	CreatedAt        time.Time           `json:"createdAt" db:"created_at"`
	UpdatedAt        time.Time           `json:"updatedAt" db:"updated_at"`
}

// SEOMetadata represents the seo_metadata table
type SEOMetadata struct {
	ID             string              `json:"id" db:"id"`
	ContentID      string              `json:"contentId" db:"content_id"`
	ContentType    string              `json:"contentType" db:"content_type"`
	Title          *string             `json:"title,omitempty" db:"title"`
	Description    *string             `json:"description,omitempty" db:"description"`
	Keywords       *string             `json:"keywords,omitempty" db:"keywords"`
	CanonicalURL   *string             `json:"canonicalUrl,omitempty" db:"canonical_url"`
	OGImage        *string             `json:"ogImage,omitempty" db:"og_image"`
	StructuredData *string             `json:"structuredData,omitempty" db:"structured_data"`
	SEOScore       int                 `json:"seoScore" db:"seo_score"`
	LastOptimized  time.Time           `json:"lastOptimized" db:"last_optimized"`
	CreatedAt      time.Time           `json:"createdAt" db:"created_at"`
	UpdatedAt      time.Time           `json:"updatedAt" db:"updated_at"`
}

// AlgorithmPreferences represents the algorithm_preferences table
type AlgorithmPreferences struct {
	ID                      string              `json:"id" db:"id"`
	UserID                  string              `json:"userId" db:"user_id"`
	PreferredCategories     map[string]interface{} `json:"preferredCategories" db:"preferred_categories"`
	InteractionWeights      map[string]interface{} `json:"interactionWeights" db:"interaction_weights"`
	ContentTypePreferences  map[string]interface{} `json:"contentTypePreferences" db:"content_type_preferences"`
	CreatorAffinities       map[string]interface{} `json:"creatorAffinities" db:"creator_affinities"`
	HashtagAffinities       map[string]interface{} `json:"hashtagAffinities" db:"hashtag_affinities"`
	SessionDuration         *int                `json:"sessionDuration,omitempty" db:"avg_session_duration"`
	DailyUsagePattern       map[string]interface{} `json:"dailyUsagePattern" db:"daily_usage_pattern"`
	LastUpdated             time.Time           `json:"lastUpdated" db:"last_updated"`
	CreatedAt               time.Time           `json:"createdAt" db:"created_at"`
}