package tracing

import (
	"context"
	"log"
	"os"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/exporters/jaeger"
	"go.opentelemetry.io/otel/sdk/resource"
	tracesdk "go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.17.0"
	"go.opentelemetry.io/otel/trace"
)

var tracer trace.Tracer

// InitTracer initializes the OpenTelemetry tracer with Jaeger exporter
func InitTracer(serviceName string) func(context.Context) error {
	// Create Jaeger exporter
	jaegerEndpoint := getEnv("JAEGER_ENDPOINT", "http://jaeger:14268/api/traces")
	
	exp, err := jaeger.New(jaeger.WithCollectorEndpoint(jaeger.WithEndpoint(jaegerEndpoint)))
	if err != nil {
		log.Printf("Warning: Failed to create Jaeger exporter: %v", err)
		return func(ctx context.Context) error { return nil }
	}

	// Create trace provider
	tp := tracesdk.NewTracerProvider(
		tracesdk.WithBatcher(exp),
		tracesdk.WithResource(resource.NewWithAttributes(
			semconv.SchemaURL,
			semconv.ServiceNameKey.String(serviceName),
			semconv.ServiceVersionKey.String("1.0.0"),
			attribute.String("environment", getEnv("ENVIRONMENT", "development")),
		)),
		tracesdk.WithSampler(tracesdk.TraceIDRatioBased(getSamplingRate())),
	)

	// Set global trace provider
	otel.SetTracerProvider(tp)
	tracer = otel.Tracer(serviceName)

	log.Printf("Tracing initialized for service: %s", serviceName)
	
	return tp.Shutdown
}

// StartSpan starts a new trace span
func StartSpan(ctx context.Context, spanName string, attrs ...attribute.KeyValue) (context.Context, trace.Span) {
	return tracer.Start(ctx, spanName, trace.WithAttributes(attrs...))
}

// AddSpanAttribute adds an attribute to the current span
func AddSpanAttribute(span trace.Span, key, value string) {
	span.SetAttributes(attribute.String(key, value))
}

// AddSpanEvent adds an event to the current span
func AddSpanEvent(span trace.Span, name string, attrs ...attribute.KeyValue) {
	span.AddEvent(name, trace.WithAttributes(attrs...))
}

// RecordError records an error in the current span
func RecordError(span trace.Span, err error) {
	if err != nil {
		span.RecordError(err)
		span.SetStatus(trace.Status{Code: trace.StatusCodeError, Description: err.Error()})
	}
}

// Business Context Helpers

// StartUserActionSpan starts a span for user actions
func StartUserActionSpan(ctx context.Context, action, userID string) (context.Context, trace.Span) {
	return StartSpan(ctx, "user."+action,
		attribute.String("user.id", userID),
		attribute.String("action.type", action),
	)
}

// StartPaymentSpan starts a span for payment operations
func StartPaymentSpan(ctx context.Context, operation string, amount float64, currency string) (context.Context, trace.Span) {
	return StartSpan(ctx, "payment."+operation,
		attribute.String("payment.operation", operation),
		attribute.Float64("payment.amount", amount),
		attribute.String("payment.currency", currency),
	)
}

// StartContentSpan starts a span for content operations
func StartContentSpan(ctx context.Context, operation, contentType string) (context.Context, trace.Span) {
	return StartSpan(ctx, "content."+operation,
		attribute.String("content.operation", operation),
		attribute.String("content.type", contentType),
	)
}

// StartStreamingSpan starts a span for streaming operations
func StartStreamingSpan(ctx context.Context, operation, streamID string) (context.Context, trace.Span) {
	return StartSpan(ctx, "streaming."+operation,
		attribute.String("streaming.operation", operation),
		attribute.String("streaming.stream_id", streamID),
	)
}

// StartMessagingSpan starts a span for messaging operations
func StartMessagingSpan(ctx context.Context, operation, messageType string) (context.Context, trace.Span) {
	return StartSpan(ctx, "messaging."+operation,
		attribute.String("messaging.operation", operation),
		attribute.String("messaging.type", messageType),
	)
}

// StartAISpan starts a span for AI operations
func StartAISpan(ctx context.Context, operation, model string) (context.Context, trace.Span) {
	return StartSpan(ctx, "ai."+operation,
		attribute.String("ai.operation", operation),
		attribute.String("ai.model", model),
	)
}

// StartDBSpan starts a span for database operations
func StartDBSpan(ctx context.Context, operation, table string) (context.Context, trace.Span) {
	return StartSpan(ctx, "db."+operation,
		attribute.String("db.operation", operation),
		attribute.String("db.table", table),
		attribute.String("db.system", "postgresql"),
	)
}

// StartCacheSpan starts a span for cache operations
func StartCacheSpan(ctx context.Context, operation, key string) (context.Context, trace.Span) {
	return StartSpan(ctx, "cache."+operation,
		attribute.String("cache.operation", operation),
		attribute.String("cache.key", key),
		attribute.String("cache.system", "redis"),
	)
}

// AddBusinessContext adds business-specific context to a span
func AddBusinessContext(span trace.Span, userID, creatorID, contentID string) {
	if userID != "" {
		AddSpanAttribute(span, "business.user_id", userID)
	}
	if creatorID != "" {
		AddSpanAttribute(span, "business.creator_id", creatorID)
	}
	if contentID != "" {
		AddSpanAttribute(span, "business.content_id", contentID)
	}
}

// AddPaymentContext adds payment-specific context to a span
func AddPaymentContext(span trace.Span, transactionID, paymentMethod string, amount float64) {
	AddSpanAttribute(span, "payment.transaction_id", transactionID)
	AddSpanAttribute(span, "payment.method", paymentMethod)
	span.SetAttributes(attribute.Float64("payment.amount", amount))
}

// AddContentContext adds content-specific context to a span
func AddContentContext(span trace.Span, contentID, contentType, visibility string, isPpv bool) {
	AddSpanAttribute(span, "content.id", contentID)
	AddSpanAttribute(span, "content.type", contentType)
	AddSpanAttribute(span, "content.visibility", visibility)
	span.SetAttributes(attribute.Bool("content.is_ppv", isPpv))
}

// AddStreamingContext adds streaming-specific context to a span
func AddStreamingContext(span trace.Span, streamID, streamType string, viewerCount int) {
	AddSpanAttribute(span, "streaming.id", streamID)
	AddSpanAttribute(span, "streaming.type", streamType)
	span.SetAttributes(attribute.Int("streaming.viewer_count", viewerCount))
}

// Helper functions

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func getSamplingRate() float64 {
	// Higher sampling for payment service, lower for high-volume services
	serviceName := getEnv("SERVICE_NAME", "unknown")
	switch serviceName {
	case "payment-service":
		return 1.0 // Sample 100% of payment traces
	case "streaming-service":
		return 0.2 // Sample 20% of streaming traces
	case "ai-service":
		return 0.3 // Sample 30% of AI traces
	case "api-gateway":
		return 0.5 // Sample 50% of gateway traces
	default:
		return 0.1 // Sample 10% by default
	}
}