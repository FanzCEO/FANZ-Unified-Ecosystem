package middleware

import (
        "bytes"
        "fmt"
        "io"
        "log"
        "strings"
        "time"

        "github.com/gin-gonic/gin"
)

// RequestLogger creates a custom logging middleware
func RequestLogger() gin.HandlerFunc {
        return gin.LoggerWithFormatter(func(param gin.LogFormatterParams) string {
                return fmt.Sprintf("[%s] %s %s %d %s %s %s\n",
                        param.TimeStamp.Format("2006-01-02 15:04:05"),
                        param.Method,
                        param.Path,
                        param.StatusCode,
                        param.Latency,
                        param.ClientIP,
                        param.ErrorMessage,
                )
        })
}

// DetailedLogger logs detailed request/response information
func DetailedLogger() gin.HandlerFunc {
        return func(c *gin.Context) {
                // Record start time
                start := time.Now()

                // Read request body
                var reqBody []byte
                if c.Request.Body != nil {
                        reqBody, _ = io.ReadAll(c.Request.Body)
                        c.Request.Body = io.NopCloser(bytes.NewBuffer(reqBody))
                }

                // Create response writer wrapper
                writer := &responseWriter{ResponseWriter: c.Writer, body: &bytes.Buffer{}}
                c.Writer = writer

                // Process request
                c.Next()

                // Log request details
                latency := time.Since(start)
                
                log.Printf(
                        "[%s] %s %s - Status: %d - Latency: %v - IP: %s - User-Agent: %s",
                        time.Now().Format("2006-01-02 15:04:05"),
                        c.Request.Method,
                        c.Request.URL.Path,
                        c.Writer.Status(),
                        latency,
                        c.ClientIP(),
                        c.Request.UserAgent(),
                )

                // Log request body for non-GET requests (excluding sensitive endpoints)
                if c.Request.Method != "GET" && !isSensitiveEndpoint(c.Request.URL.Path) {
                        if len(reqBody) > 0 && len(reqBody) < 1000 { // Limit body size in logs
                                log.Printf("Request Body: %s", string(reqBody))
                        }
                }

                // Log errors if any
                if len(c.Errors) > 0 {
                        log.Printf("Errors: %v", c.Errors)
                }
        }
}

// SecurityLogger logs security-related events
func SecurityLogger() gin.HandlerFunc {
        return func(c *gin.Context) {
                // Check for suspicious patterns
                userAgent := c.Request.UserAgent()
                if isSuspiciousUserAgent(userAgent) {
                        log.Printf("SECURITY: Suspicious User-Agent from %s: %s", c.ClientIP(), userAgent)
                }

                // Check for SQL injection patterns in query params
                for key, values := range c.Request.URL.Query() {
                        for _, value := range values {
                                if containsSQLInjectionPattern(value) {
                                        log.Printf("SECURITY: Potential SQL injection from %s in param %s: %s", c.ClientIP(), key, value)
                                }
                        }
                }

                c.Next()
        }
}

// responseWriter wraps gin.ResponseWriter to capture response body
type responseWriter struct {
        gin.ResponseWriter
        body *bytes.Buffer
}

func (w *responseWriter) Write(data []byte) (int, error) {
        w.body.Write(data)
        return w.ResponseWriter.Write(data)
}

// isSensitiveEndpoint checks if endpoint contains sensitive data
func isSensitiveEndpoint(path string) bool {
        sensitivePatterns := []string{
                "/auth/login",
                "/auth/register",
                "/auth/password",
                "/payment",
                "/compliance",
                "/documents",
        }

        for _, pattern := range sensitivePatterns {
                if strings.Contains(path, pattern) {
                        return true
                }
        }
        return false
}

// isSuspiciousUserAgent checks for bot or scanner user agents
func isSuspiciousUserAgent(userAgent string) bool {
        suspicious := []string{
                "sqlmap",
                "nikto",
                "dirb",
                "gobuster",
                "nmap",
                "masscan",
                "curl/7", // Basic curl requests might be suspicious
        }

        userAgentLower := strings.ToLower(userAgent)
        for _, pattern := range suspicious {
                if strings.Contains(userAgentLower, pattern) {
                        return true
                }
        }
        return false
}

// containsSQLInjectionPattern checks for common SQL injection patterns
func containsSQLInjectionPattern(input string) bool {
        patterns := []string{
                "' OR '1'='1",
                "' OR 1=1",
                "'; DROP TABLE",
                "'; DELETE FROM",
                "UNION SELECT",
                "<script>",
                "javascript:",
        }

        inputLower := strings.ToLower(input)
        for _, pattern := range patterns {
                if strings.Contains(inputLower, strings.ToLower(pattern)) {
                        return true
                }
        }
        return false
}