package middleware

import (
	"context"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/fanz-os/shared/cache"
)

// RateLimitConfig holds rate limiting configuration
type RateLimitConfig struct {
	Requests int           // Number of requests allowed
	Window   time.Duration // Time window
	KeyFunc  func(*gin.Context) string // Function to generate rate limit key
}

// DefaultRateLimitConfig returns a default rate limit configuration
func DefaultRateLimitConfig() *RateLimitConfig {
	return &RateLimitConfig{
		Requests: 100,
		Window:   time.Minute,
		KeyFunc:  defaultKeyFunc,
	}
}

// APIRateLimitConfig returns rate limiting for API endpoints
func APIRateLimitConfig() *RateLimitConfig {
	return &RateLimitConfig{
		Requests: 1000,
		Window:   time.Hour,
		KeyFunc:  userBasedKeyFunc,
	}
}

// AuthRateLimitConfig returns rate limiting for authentication endpoints
func AuthRateLimitConfig() *RateLimitConfig {
	return &RateLimitConfig{
		Requests: 5,
		Window:   time.Minute,
		KeyFunc:  ipBasedKeyFunc,
	}
}

// UploadRateLimitConfig returns rate limiting for upload endpoints
func UploadRateLimitConfig() *RateLimitConfig {
	return &RateLimitConfig{
		Requests: 10,
		Window:   time.Minute,
		KeyFunc:  userBasedKeyFunc,
	}
}

// RateLimit middleware with Redis backend
func RateLimit(redisClient *cache.RedisClient, config *RateLimitConfig) gin.HandlerFunc {
	if config == nil {
		config = DefaultRateLimitConfig()
	}

	return func(c *gin.Context) {
		key := config.KeyFunc(c)
		if key == "" {
			c.Next()
			return
		}

		// Create rate limit key
		rateLimitKey := fmt.Sprintf("rate_limit:%s", key)
		
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()

		// Get current count
		current, err := redisClient.Increment(ctx, rateLimitKey)
		if err != nil {
			// If Redis is down, allow the request
			c.Next()
			return
		}

		// Set expiration on first request
		if current == 1 {
			if err := redisClient.Expire(ctx, rateLimitKey, config.Window); err != nil {
				// Log error but continue
			}
		}

		// Check if limit exceeded
		if current > int64(config.Requests) {
			c.Header("X-RateLimit-Limit", strconv.Itoa(config.Requests))
			c.Header("X-RateLimit-Remaining", "0")
			c.Header("X-RateLimit-Reset", strconv.FormatInt(time.Now().Add(config.Window).Unix(), 10))
			
			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": "Rate limit exceeded",
				"retry_after": config.Window.Seconds(),
			})
			c.Abort()
			return
		}

		// Set rate limit headers
		remaining := config.Requests - int(current)
		c.Header("X-RateLimit-Limit", strconv.Itoa(config.Requests))
		c.Header("X-RateLimit-Remaining", strconv.Itoa(remaining))
		c.Header("X-RateLimit-Reset", strconv.FormatInt(time.Now().Add(config.Window).Unix(), 10))

		c.Next()
	}
}

// defaultKeyFunc uses IP address as rate limit key
func defaultKeyFunc(c *gin.Context) string {
	return c.ClientIP()
}

// ipBasedKeyFunc uses IP address as rate limit key with prefix
func ipBasedKeyFunc(c *gin.Context) string {
	return fmt.Sprintf("ip:%s", c.ClientIP())
}

// userBasedKeyFunc uses user ID as rate limit key
func userBasedKeyFunc(c *gin.Context) string {
	userID, exists := c.Get("user_id")
	if !exists {
		// Fall back to IP if user not authenticated
		return fmt.Sprintf("ip:%s", c.ClientIP())
	}

	if id, ok := userID.(string); ok {
		return fmt.Sprintf("user:%s", id)
	}

	return fmt.Sprintf("ip:%s", c.ClientIP())
}

// endpointBasedKeyFunc combines user/IP with endpoint
func endpointBasedKeyFunc(c *gin.Context) string {
	base := userBasedKeyFunc(c)
	endpoint := c.Request.URL.Path
	return fmt.Sprintf("%s:%s", base, endpoint)
}