package utils

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"

	"golang.org/x/crypto/bcrypt"
)

// HashPassword hashes a password using bcrypt
func HashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	return string(bytes), err
}

// CheckPasswordHash compares a password with its hash
func CheckPasswordHash(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

// GenerateRandomBytes generates n random bytes
func GenerateRandomBytes(n int) ([]byte, error) {
	b := make([]byte, n)
	_, err := rand.Read(b)
	if err != nil {
		return nil, err
	}
	return b, nil
}

// GenerateRandomString generates a random string of specified length
func GenerateRandomString(length int) (string, error) {
	bytes, err := GenerateRandomBytes(length)
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes)[:length], nil
}

// GenerateVerificationCode generates a numeric verification code
func GenerateVerificationCode(length int) (string, error) {
	if length < 4 || length > 8 {
		return "", fmt.Errorf("verification code length must be between 4 and 8")
	}

	bytes, err := GenerateRandomBytes(length)
	if err != nil {
		return "", err
	}

	code := ""
	for i := 0; i < length; i++ {
		code += fmt.Sprintf("%d", int(bytes[i])%10)
	}

	return code, nil
}

// GenerateSecureToken generates a secure random token
func GenerateSecureToken() (string, error) {
	bytes, err := GenerateRandomBytes(32)
	if err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes), nil
}

// HashSHA256 creates a SHA256 hash of the input
func HashSHA256(input string) string {
	hash := sha256.Sum256([]byte(input))
	return hex.EncodeToString(hash[:])
}

// GenerateAPIKey generates a random API key
func GenerateAPIKey() (string, error) {
	bytes, err := GenerateRandomBytes(32)
	if err != nil {
		return "", err
	}
	return "fanz_" + hex.EncodeToString(bytes), nil
}