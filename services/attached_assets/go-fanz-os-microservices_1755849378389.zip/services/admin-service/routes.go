package main

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/fanz-os/shared/utils"
)

// setupRoutes configures all Admin Service routes
func setupRoutes(
	r *gin.Engine,
	userModerationService *UserModerationService,
	contentModerationService *ContentModerationService,
	complianceService *ComplianceService,
	analyticsService *AnalyticsService,
	systemService *SystemService,
	auditService *AuditService,
) {
	// Health check
	r.GET("/health", healthCheck)
	r.GET("/", rootHandler)

	// User moderation routes
	users := r.Group("/users")
	{
		users.GET("", userModerationService.GetUsers)
		users.GET("/:id", userModerationService.GetUser)
		users.PUT("/:id/status", userModerationService.UpdateUserStatus)
		users.PUT("/:id/suspend", userModerationService.SuspendUser)
		users.PUT("/:id/unsuspend", userModerationService.UnsuspendUser)
		users.PUT("/:id/ban", userModerationService.BanUser)
		users.PUT("/:id/unban", userModerationService.UnbanUser)
		users.DELETE("/:id", userModerationService.DeleteUser)
		users.GET("/:id/activity", userModerationService.GetUserActivity)
		users.GET("/:id/violations", userModerationService.GetUserViolations)
		users.POST("/:id/warning", userModerationService.IssueWarning)
		users.GET("/flagged", userModerationService.GetFlaggedUsers)
		users.GET("/suspended", userModerationService.GetSuspendedUsers)
		users.GET("/banned", userModerationService.GetBannedUsers)
		users.PUT("/:id/age-verification", userModerationService.UpdateAgeVerification)
		users.GET("/:id/identity-documents", userModerationService.GetIdentityDocuments)
		users.PUT("/:id/identity-documents/approve", userModerationService.ApproveIdentityDocuments)
		users.PUT("/:id/identity-documents/reject", userModerationService.RejectIdentityDocuments)
	}

	// Content moderation routes
	content := r.Group("/content")
	{
		content.GET("/reported", contentModerationService.GetReportedContent)
		content.GET("/flagged", contentModerationService.GetFlaggedContent)
		content.PUT("/:type/:id/moderate", contentModerationService.ModerateContent)
		content.PUT("/:type/:id/approve", contentModerationService.ApproveContent)
		content.PUT("/:type/:id/reject", contentModerationService.RejectContent)
		content.DELETE("/:type/:id", contentModerationService.DeleteContent)
		content.GET("/reports", contentModerationService.GetContentReports)
		content.PUT("/reports/:id/resolve", contentModerationService.ResolveContentReport)
		content.GET("/violations", contentModerationService.GetContentViolations)
		content.POST("/takedown", contentModerationService.IssueTakedownNotice)
		content.GET("/ai-moderation", contentModerationService.GetAIModerationResults)
		content.PUT("/ai-moderation/:id/review", contentModerationService.ReviewAIModerationResult)
	}

	// Compliance and legal routes
	compliance := r.Group("/compliance")
	{
		// 2257 Compliance
		compliance.GET("/2257/records", complianceService.Get2257Records)
		compliance.PUT("/2257/records/:id/approve", complianceService.Approve2257Record)
		compliance.PUT("/2257/records/:id/reject", complianceService.Reject2257Record)
		compliance.GET("/2257/custodian", complianceService.GetCustodianOfRecords)
		compliance.PUT("/2257/custodian", complianceService.UpdateCustodianOfRecords)
		
		// DMCA
		compliance.GET("/dmca/takedowns", complianceService.GetDMCATakedowns)
		compliance.POST("/dmca/takedowns", complianceService.CreateDMCATakedown)
		compliance.PUT("/dmca/takedowns/:id/process", complianceService.ProcessDMCATakedown)
		compliance.POST("/dmca/counter-notices", complianceService.CreateDMCACounterNotice)
		
		// Legal requests
		compliance.GET("/legal-requests", complianceService.GetLegalRequests)
		compliance.POST("/legal-requests", complianceService.CreateLegalRequest)
		compliance.PUT("/legal-requests/:id/respond", complianceService.RespondToLegalRequest)
		
		// Privacy and data protection
		compliance.GET("/gdpr/requests", complianceService.GetGDPRRequests)
		compliance.PUT("/gdpr/requests/:id/process", complianceService.ProcessGDPRRequest)
		compliance.GET("/data-exports", complianceService.GetDataExports)
		compliance.POST("/data-exports", complianceService.CreateDataExport)
		compliance.GET("/data-deletions", complianceService.GetDataDeletions)
		compliance.POST("/data-deletions", complianceService.CreateDataDeletion)
		
		// Terms of service violations
		compliance.GET("/tos-violations", complianceService.GetTOSViolations)
		compliance.POST("/tos-violations", complianceService.CreateTOSViolation)
		compliance.PUT("/tos-violations/:id/resolve", complianceService.ResolveTOSViolation)
	}

	// Platform analytics and insights
	analytics := r.Group("/analytics")
	{
		// User analytics
		analytics.GET("/users/overview", analyticsService.GetUserAnalyticsOverview)
		analytics.GET("/users/growth", analyticsService.GetUserGrowthAnalytics)
		analytics.GET("/users/engagement", analyticsService.GetUserEngagementAnalytics)
		analytics.GET("/users/demographics", analyticsService.GetUserDemographics)
		analytics.GET("/users/retention", analyticsService.GetUserRetentionAnalytics)
		
		// Content analytics
		analytics.GET("/content/overview", analyticsService.GetContentAnalyticsOverview)
		analytics.GET("/content/performance", analyticsService.GetContentPerformanceAnalytics)
		analytics.GET("/content/trends", analyticsService.GetContentTrends)
		analytics.GET("/content/violations", analyticsService.GetContentViolationAnalytics)
		
		// Financial analytics
		analytics.GET("/revenue/overview", analyticsService.GetRevenueOverview)
		analytics.GET("/revenue/streams", analyticsService.GetRevenueStreams)
		analytics.GET("/revenue/creators", analyticsService.GetCreatorRevenueAnalytics)
		analytics.GET("/revenue/platform-fees", analyticsService.GetPlatformFeeAnalytics)
		analytics.GET("/revenue/payouts", analyticsService.GetPayoutAnalytics)
		
		// Platform health
		analytics.GET("/platform/health", analyticsService.GetPlatformHealth)
		analytics.GET("/platform/performance", analyticsService.GetPlatformPerformance)
		analytics.GET("/platform/errors", analyticsService.GetErrorAnalytics)
		analytics.GET("/platform/traffic", analyticsService.GetTrafficAnalytics)
		
		// Moderation analytics
		analytics.GET("/moderation/overview", analyticsService.GetModerationOverview)
		analytics.GET("/moderation/queue-times", analyticsService.GetModerationQueueTimes)
		analytics.GET("/moderation/moderator-performance", analyticsService.GetModeratorPerformance)
	}

	// System management routes
	system := r.Group("/system")
	{
		// Configuration management
		system.GET("/config", systemService.GetSystemConfig)
		system.PUT("/config", systemService.UpdateSystemConfig)
		system.GET("/feature-flags", systemService.GetFeatureFlags)
		system.PUT("/feature-flags/:flag", systemService.UpdateFeatureFlag)
		
		// Database management
		system.GET("/database/stats", systemService.GetDatabaseStats)
		system.POST("/database/backup", systemService.CreateDatabaseBackup)
		system.GET("/database/backups", systemService.GetDatabaseBackups)
		system.POST("/database/migrate", systemService.RunDatabaseMigration)
		system.GET("/database/migrations", systemService.GetMigrationHistory)
		
		// Cache management
		system.GET("/cache/stats", systemService.GetCacheStats)
		system.POST("/cache/clear", systemService.ClearCache)
		system.POST("/cache/warm", systemService.WarmCache)
		
		// File storage management
		system.GET("/storage/stats", systemService.GetStorageStats)
		system.POST("/storage/cleanup", systemService.CleanupOrphanedFiles)
		system.GET("/storage/usage", systemService.GetStorageUsage)
		
		// Background jobs
		system.GET("/jobs", systemService.GetBackgroundJobs)
		system.POST("/jobs/:id/retry", systemService.RetryJob)
		system.DELETE("/jobs/:id", systemService.DeleteJob)
		system.GET("/jobs/stats", systemService.GetJobStats)
		
		// Maintenance mode
		system.PUT("/maintenance/enable", systemService.EnableMaintenanceMode)
		system.PUT("/maintenance/disable", systemService.DisableMaintenanceMode)
		system.GET("/maintenance/status", systemService.GetMaintenanceStatus)
		
		// API rate limiting
		system.GET("/rate-limits", systemService.GetRateLimits)
		system.PUT("/rate-limits", systemService.UpdateRateLimits)
		system.POST("/rate-limits/reset/:userId", systemService.ResetUserRateLimit)
	}

	// Audit and logging routes
	audit := r.Group("/audit")
	{
		audit.GET("/logs", auditService.GetAuditLogs)
		audit.GET("/logs/:id", auditService.GetAuditLog)
		audit.GET("/user-actions/:userId", auditService.GetUserActions)
		audit.GET("/admin-actions", auditService.GetAdminActions)
		audit.GET("/security-events", auditService.GetSecurityEvents)
		audit.GET("/login-attempts", auditService.GetLoginAttempts)
		audit.GET("/suspicious-activity", auditService.GetSuspiciousActivity)
		audit.POST("/security-events/:id/investigate", auditService.InvestigateSecurityEvent)
	}

	// Communication and notifications
	communication := r.Group("/communication")
	{
		// Platform announcements
		communication.GET("/announcements", systemService.GetAnnouncements)
		communication.POST("/announcements", systemService.CreateAnnouncement)
		communication.PUT("/announcements/:id", systemService.UpdateAnnouncement)
		communication.DELETE("/announcements/:id", systemService.DeleteAnnouncement)
		
		// Email campaigns
		communication.GET("/email-campaigns", systemService.GetEmailCampaigns)
		communication.POST("/email-campaigns", systemService.CreateEmailCampaign)
		communication.PUT("/email-campaigns/:id/send", systemService.SendEmailCampaign)
		communication.GET("/email-campaigns/:id/stats", systemService.GetEmailCampaignStats)
		
		// Push notifications
		communication.POST("/push-notifications/send", systemService.SendPushNotification)
		communication.GET("/push-notifications/stats", systemService.GetPushNotificationStats)
		
		// Support tickets
		communication.GET("/support-tickets", systemService.GetSupportTickets)
		communication.GET("/support-tickets/:id", systemService.GetSupportTicket)
		communication.PUT("/support-tickets/:id/assign", systemService.AssignSupportTicket)
		communication.PUT("/support-tickets/:id/respond", systemService.RespondToSupportTicket)
		communication.PUT("/support-tickets/:id/close", systemService.CloseSupportTicket)
	}

	// Financial management
	financial := r.Group("/financial")
	{
		// Payment oversight
		financial.GET("/transactions/overview", analyticsService.GetTransactionOverview)
		financial.GET("/transactions/suspicious", analyticsService.GetSuspiciousTransactions)
		financial.PUT("/transactions/:id/flag", analyticsService.FlagTransaction)
		financial.PUT("/transactions/:id/approve", analyticsService.ApproveTransaction)
		
		// Creator payouts
		financial.GET("/payouts/pending", analyticsService.GetPendingPayouts)
		financial.PUT("/payouts/:id/approve", analyticsService.ApprovePayout)
		financial.PUT("/payouts/:id/reject", analyticsService.RejectPayout)
		financial.GET("/payouts/history", analyticsService.GetPayoutHistory)
		
		// Tax and compliance
		financial.GET("/tax/forms", analyticsService.GetTaxForms)
		financial.POST("/tax/forms/generate", analyticsService.GenerateTaxForms)
		financial.GET("/tax/reports", analyticsService.GetTaxReports)
		
		// Chargeback management
		financial.GET("/chargebacks", analyticsService.GetChargebacks)
		financial.PUT("/chargebacks/:id/dispute", analyticsService.DisputeChargeback)
		financial.GET("/chargeback-stats", analyticsService.GetChargebackStats)
	}

	// Security management
	security := r.Group("/security")
	{
		// IP management
		security.GET("/ip-bans", systemService.GetIPBans)
		security.POST("/ip-bans", systemService.CreateIPBan)
		security.DELETE("/ip-bans/:id", systemService.RemoveIPBan)
		security.GET("/ip-whitelist", systemService.GetIPWhitelist)
		security.POST("/ip-whitelist", systemService.AddToIPWhitelist)
		
		// Bot detection
		security.GET("/bot-detection", systemService.GetBotDetectionStats)
		security.PUT("/bot-detection/settings", systemService.UpdateBotDetectionSettings)
		security.GET("/suspicious-accounts", systemService.GetSuspiciousAccounts)
		
		// Fraud prevention
		security.GET("/fraud-alerts", systemService.GetFraudAlerts)
		security.PUT("/fraud-alerts/:id/investigate", systemService.InvestigateFraudAlert)
		security.GET("/fraud-patterns", systemService.GetFraudPatterns)
		
		// API security
		security.GET("/api-keys", systemService.GetAPIKeys)
		security.POST("/api-keys", systemService.CreateAPIKey)
		security.PUT("/api-keys/:id/revoke", systemService.RevokeAPIKey)
		security.GET("/api-usage", systemService.GetAPIUsageStats)
	}
}

// healthCheck returns the health status of the Admin Service
func healthCheck(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"status":    "healthy",
		"service":   "admin-service",
		"timestamp": time.Now().Unix(),
	})
}

// rootHandler returns service information
func rootHandler(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"name":        "Fanz OS Admin Service",
		"version":     "1.0.0",
		"description": "Platform administration, compliance, and moderation tools",
		"endpoints": gin.H{
			"health":        "/health",
			"users":         "/users",
			"content":       "/content",
			"compliance":    "/compliance",
			"analytics":     "/analytics",
			"system":        "/system",
			"audit":         "/audit",
			"communication": "/communication",
			"financial":     "/financial",
			"security":      "/security",
		},
	})
}