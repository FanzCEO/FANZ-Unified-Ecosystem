package main

import (
	"database/sql"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// UserModerationService handles user moderation operations
type UserModerationService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewUserModerationService creates a new user moderation service instance
func NewUserModerationService(db *database.DB, redis *cache.RedisClient) *UserModerationService {
	return &UserModerationService{
		db:    db,
		redis: redis,
	}
}

// GetUsers gets users with filtering and pagination
func (s *UserModerationService) GetUsers(c *gin.Context) {
	// Get query parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "50"))
	status := c.Query("status")
	role := c.Query("role")
	search := c.Query("search")

	// Validate pagination
	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 50
	}

	offset := (page - 1) * limit

	// Build query
	whereClause := []string{"1=1"}
	args := []interface{}{}
	argIndex := 1

	// Filter by status
	if status != "" {
		whereClause = append(whereClause, fmt.Sprintf("account_status = $%d", argIndex))
		args = append(args, status)
		argIndex++
	}

	// Filter by role
	if role != "" {
		whereClause = append(whereClause, fmt.Sprintf("role = $%d", argIndex))
		args = append(args, role)
		argIndex++
	}

	// Search by name or email
	if search != "" {
		whereClause = append(whereClause, fmt.Sprintf("(display_name ILIKE $%d OR email ILIKE $%d)", argIndex, argIndex))
		args = append(args, "%"+search+"%")
		argIndex++
	}

	// Get total count
	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM users WHERE %s", strings.Join(whereClause, " AND "))
	var total int
	err := s.db.QueryRow(countQuery, args...).Scan(&total)
	if err != nil {
		utils.InternalServerError(c, "Failed to count users")
		return
	}

	// Get users
	query := fmt.Sprintf(`
		SELECT id, email, display_name, role, account_status, is_verified, 
			   age_verification_status, created_at, last_seen, subscriber_count,
			   profile_image_url, bio, location
		FROM users 
		WHERE %s
		ORDER BY created_at DESC
		LIMIT $%d OFFSET $%d
	`, strings.Join(whereClause, " AND "), argIndex, argIndex+1)

	args = append(args, limit, offset)

	rows, err := s.db.Query(query, args...)
	if err != nil {
		utils.InternalServerError(c, "Failed to get users")
		return
	}
	defer rows.Close()

	var users []map[string]interface{}
	for rows.Next() {
		var user models.User
		err := rows.Scan(
			&user.ID, &user.Email, &user.DisplayName, &user.Role,
			&user.AccountStatus, &user.IsVerified, &user.AgeVerificationStatus,
			&user.CreatedAt, &user.LastSeen, &user.SubscriberCount,
			&user.ProfileImageURL, &user.Bio, &user.Location,
		)
		if err != nil {
			continue
		}

		userData := map[string]interface{}{
			"id":                       user.ID,
			"email":                    user.Email,
			"display_name":             user.DisplayName,
			"role":                     user.Role,
			"account_status":           user.AccountStatus,
			"is_verified":              user.IsVerified,
			"age_verification_status":  user.AgeVerificationStatus,
			"created_at":               user.CreatedAt,
			"last_seen":                user.LastSeen,
			"subscriber_count":         user.SubscriberCount,
			"profile_image_url":        user.ProfileImageURL,
			"bio":                      user.Bio,
			"location":                 user.Location,
		}

		users = append(users, userData)
	}

	// Calculate pagination metadata
	totalPages := (total + limit - 1) / limit
	meta := &utils.Meta{
		Page:       page,
		Limit:      limit,
		Total:      total,
		TotalPages: totalPages,
	}

	utils.SuccessResponseWithMeta(c, users, meta)
}

// GetUser gets a specific user by ID
func (s *UserModerationService) GetUser(c *gin.Context) {
	userID := c.Param("id")
	if userID == "" {
		utils.BadRequestError(c, "User ID is required")
		return
	}

	user, err := s.getUserByID(userID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "User not found")
		} else {
			utils.InternalServerError(c, "Failed to get user")
		}
		return
	}

	// Get additional user information
	userInfo := map[string]interface{}{
		"user": user,
	}

	// Get user statistics
	stats, _ := s.getUserStats(userID)
	userInfo["stats"] = stats

	// Get recent violations
	violations, _ := s.getRecentViolations(userID)
	userInfo["recent_violations"] = violations

	// Get account history
	history, _ := s.getAccountHistory(userID)
	userInfo["account_history"] = history

	utils.SuccessResponse(c, userInfo)
}

// SuspendUser suspends a user account
func (s *UserModerationService) SuspendUser(c *gin.Context) {
	adminID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "Admin not found in context")
		return
	}

	userID := c.Param("id")
	if userID == "" {
		utils.BadRequestError(c, "User ID is required")
		return
	}

	var req struct {
		Reason   string     `json:"reason" binding:"required"`
		Duration *time.Time `json:"duration,omitempty"` // Optional suspension end date
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Check if user exists
	user, err := s.getUserByID(userID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "User not found")
		} else {
			utils.InternalServerError(c, "Failed to get user")
		}
		return
	}

	if user.AccountStatus == models.UserStatusSuspended {
		utils.ConflictError(c, "User is already suspended")
		return
	}

	// Suspend the user
	now := time.Now()
	_, err = s.db.Exec(`
		UPDATE users 
		SET account_status = $1, suspension_reason = $2, suspension_end = $3, updated_at = $4
		WHERE id = $5
	`, models.UserStatusSuspended, req.Reason, req.Duration, now, userID)

	if err != nil {
		utils.InternalServerError(c, "Failed to suspend user")
		return
	}

	// Create audit log
	s.createAuditLog(adminID, "user_suspended", map[string]interface{}{
		"user_id":  userID,
		"reason":   req.Reason,
		"duration": req.Duration,
	})

	utils.SuccessResponse(c, gin.H{
		"message":     "User suspended successfully",
		"user_id":     userID,
		"suspended_at": now,
		"reason":      req.Reason,
		"duration":    req.Duration,
	})
}

// UnsuspendUser unsuspends a user account
func (s *UserModerationService) UnsuspendUser(c *gin.Context) {
	adminID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "Admin not found in context")
		return
	}

	userID := c.Param("id")
	if userID == "" {
		utils.BadRequestError(c, "User ID is required")
		return
	}

	// Check if user exists and is suspended
	user, err := s.getUserByID(userID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "User not found")
		} else {
			utils.InternalServerError(c, "Failed to get user")
		}
		return
	}

	if user.AccountStatus != models.UserStatusSuspended {
		utils.ConflictError(c, "User is not suspended")
		return
	}

	// Unsuspend the user
	now := time.Now()
	_, err = s.db.Exec(`
		UPDATE users 
		SET account_status = $1, suspension_reason = NULL, suspension_end = NULL, updated_at = $2
		WHERE id = $3
	`, models.UserStatusActive, now, userID)

	if err != nil {
		utils.InternalServerError(c, "Failed to unsuspend user")
		return
	}

	// Create audit log
	s.createAuditLog(adminID, "user_unsuspended", map[string]interface{}{
		"user_id": userID,
	})

	utils.SuccessResponse(c, gin.H{
		"message":       "User unsuspended successfully",
		"user_id":       userID,
		"unsuspended_at": now,
	})
}

// BanUser permanently bans a user account
func (s *UserModerationService) BanUser(c *gin.Context) {
	adminID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "Admin not found in context")
		return
	}

	userID := c.Param("id")
	if userID == "" {
		utils.BadRequestError(c, "User ID is required")
		return
	}

	var req struct {
		Reason string `json:"reason" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Check if user exists
	user, err := s.getUserByID(userID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "User not found")
		} else {
			utils.InternalServerError(c, "Failed to get user")
		}
		return
	}

	if user.AccountStatus == models.UserStatusBanned {
		utils.ConflictError(c, "User is already banned")
		return
	}

	// Ban the user
	now := time.Now()
	_, err = s.db.Exec(`
		UPDATE users 
		SET account_status = $1, ban_reason = $2, banned_at = $3, updated_at = $4
		WHERE id = $5
	`, models.UserStatusBanned, req.Reason, now, now, userID)

	if err != nil {
		utils.InternalServerError(c, "Failed to ban user")
		return
	}

	// Create audit log
	s.createAuditLog(adminID, "user_banned", map[string]interface{}{
		"user_id": userID,
		"reason":  req.Reason,
	})

	utils.SuccessResponse(c, gin.H{
		"message":  "User banned successfully",
		"user_id":  userID,
		"banned_at": now,
		"reason":   req.Reason,
	})
}

// Helper functions

func (s *UserModerationService) getUserByID(userID string) (*models.User, error) {
	var user models.User
	err := s.db.QueryRow(`
		SELECT id, email, display_name, role, account_status, is_verified,
			   age_verification_status, created_at, last_seen, subscriber_count,
			   profile_image_url, bio, location, suspension_reason, ban_reason
		FROM users WHERE id = $1
	`, userID).Scan(
		&user.ID, &user.Email, &user.DisplayName, &user.Role,
		&user.AccountStatus, &user.IsVerified, &user.AgeVerificationStatus,
		&user.CreatedAt, &user.LastSeen, &user.SubscriberCount,
		&user.ProfileImageURL, &user.Bio, &user.Location,
		&user.SuspensionReason, &user.BanReason,
	)
	return &user, err
}

func (s *UserModerationService) getUserStats(userID string) (map[string]interface{}, error) {
	stats := map[string]interface{}{}

	// Get post count
	var postCount int
	s.db.QueryRow("SELECT COUNT(*) FROM posts WHERE creator_id = $1", userID).Scan(&postCount)
	stats["post_count"] = postCount

	// Get subscriber count
	var subscriberCount int
	s.db.QueryRow("SELECT COUNT(*) FROM subscriptions WHERE creator_id = $1 AND is_active = true", userID).Scan(&subscriberCount)
	stats["subscriber_count"] = subscriberCount

	// Get total earnings (placeholder)
	stats["total_earnings"] = 0

	// Get violation count
	var violationCount int
	s.db.QueryRow("SELECT COUNT(*) FROM user_violations WHERE user_id = $1", userID).Scan(&violationCount)
	stats["violation_count"] = violationCount

	return stats, nil
}

func (s *UserModerationService) getRecentViolations(userID string) ([]map[string]interface{}, error) {
	rows, err := s.db.Query(`
		SELECT id, violation_type, description, severity, created_at
		FROM user_violations 
		WHERE user_id = $1 
		ORDER BY created_at DESC 
		LIMIT 10
	`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var violations []map[string]interface{}
	for rows.Next() {
		var violation map[string]interface{}
		var id, violationType, description, severity string
		var createdAt time.Time

		err := rows.Scan(&id, &violationType, &description, &severity, &createdAt)
		if err != nil {
			continue
		}

		violation = map[string]interface{}{
			"id":             id,
			"violation_type": violationType,
			"description":    description,
			"severity":       severity,
			"created_at":     createdAt,
		}

		violations = append(violations, violation)
	}

	return violations, nil
}

func (s *UserModerationService) getAccountHistory(userID string) ([]map[string]interface{}, error) {
	rows, err := s.db.Query(`
		SELECT action, description, admin_id, created_at
		FROM audit_logs 
		WHERE target_user_id = $1 
		ORDER BY created_at DESC 
		LIMIT 20
	`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var history []map[string]interface{}
	for rows.Next() {
		var historyItem map[string]interface{}
		var action, description, adminID string
		var createdAt time.Time

		err := rows.Scan(&action, &description, &adminID, &createdAt)
		if err != nil {
			continue
		}

		historyItem = map[string]interface{}{
			"action":      action,
			"description": description,
			"admin_id":    adminID,
			"created_at":  createdAt,
		}

		history = append(history, historyItem)
	}

	return history, nil
}

func (s *UserModerationService) createAuditLog(adminID, action string, details map[string]interface{}) {
	auditID := uuid.New().String()
	s.db.Exec(`
		INSERT INTO audit_logs (id, admin_id, action, details, created_at)
		VALUES ($1, $2, $3, $4, $5)
	`, auditID, adminID, action, details, time.Now())
}

// Placeholder implementations for remaining methods
func (s *UserModerationService) UpdateUserStatus(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Update user status not yet implemented")
}

func (s *UserModerationService) UnbanUser(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Unban user not yet implemented")
}

func (s *UserModerationService) DeleteUser(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Delete user not yet implemented")
}

func (s *UserModerationService) GetUserActivity(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get user activity not yet implemented")
}

func (s *UserModerationService) GetUserViolations(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get user violations not yet implemented")
}

func (s *UserModerationService) IssueWarning(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Issue warning not yet implemented")
}

func (s *UserModerationService) GetFlaggedUsers(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get flagged users not yet implemented")
}

func (s *UserModerationService) GetSuspendedUsers(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get suspended users not yet implemented")
}

func (s *UserModerationService) GetBannedUsers(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get banned users not yet implemented")
}

func (s *UserModerationService) UpdateAgeVerification(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Update age verification not yet implemented")
}

func (s *UserModerationService) GetIdentityDocuments(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get identity documents not yet implemented")
}

func (s *UserModerationService) ApproveIdentityDocuments(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Approve identity documents not yet implemented")
}

func (s *UserModerationService) RejectIdentityDocuments(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Reject identity documents not yet implemented")
}