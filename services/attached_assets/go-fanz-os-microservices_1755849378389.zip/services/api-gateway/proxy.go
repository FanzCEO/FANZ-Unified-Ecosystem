package main

import (
        "bytes"
        "encoding/json"
        "fmt"
        "io"
        "net/http"
        "net/http/httputil"
        "net/url"
        "strings"
        "time"

        "github.com/gin-gonic/gin"
        "github.com/fanz-os/shared/utils"
)

// createReverseProxy creates a reverse proxy for a target service
func createReverseProxy(targetURL string) *httputil.ReverseProxy {
        target, _ := url.Parse(targetURL)
        
        proxy := httputil.NewSingleHostReverseProxy(target)
        
        // Custom director to modify the request
        originalDirector := proxy.Director
        proxy.Director = func(req *http.Request) {
                originalDirector(req)
                req.Host = target.Host
                req.Header.Set("X-Forwarded-Host", req.Header.Get("Host"))
                req.Header.Set("X-Forwarded-Proto", "http")
        }

        // Custom error handler
        proxy.ErrorHandler = func(w http.ResponseWriter, r *http.Request, err error) {
                w.Header().Set("Content-Type", "application/json")
                w.WriteHeader(http.StatusBadGateway)
                
                response := utils.APIResponse{
                        Success: false,
                        Error: &utils.APIError{
                                Code:    "SERVICE_UNAVAILABLE",
                                Message: "The requested service is temporarily unavailable",
                                Details: fmt.Sprintf("Failed to connect to upstream service: %v", err),
                        },
                }
                
                // Write JSON response
                if jsonData, jsonErr := json.Marshal(response); jsonErr == nil {
                        w.Write(jsonData)
                }
        }

        return proxy
}

// proxyToUserService proxies requests to the User Service
func proxyToUserService(c *gin.Context) {
        proxy := createReverseProxy(userServiceURL)
        proxy.ServeHTTP(c.Writer, c.Request)
}

// proxyToContentService proxies requests to the Content Service
func proxyToContentService(c *gin.Context) {
        proxy := createReverseProxy(contentServiceURL)
        proxy.ServeHTTP(c.Writer, c.Request)
}

// proxyToPaymentService proxies requests to the Payment Service
func proxyToPaymentService(c *gin.Context) {
        proxy := createReverseProxy(paymentServiceURL)
        proxy.ServeHTTP(c.Writer, c.Request)
}

// proxyToStreamingService proxies requests to the Streaming Service
func proxyToStreamingService(c *gin.Context) {
        proxy := createReverseProxy(streamingServiceURL)
        proxy.ServeHTTP(c.Writer, c.Request)
}

// proxyToMessagingService proxies requests to the Messaging Service
func proxyToMessagingService(c *gin.Context) {
        proxy := createReverseProxy(messagingServiceURL)
        proxy.ServeHTTP(c.Writer, c.Request)
}

// proxyToAdminService proxies requests to the Admin Service
func proxyToAdminService(c *gin.Context) {
        proxy := createReverseProxy(adminServiceURL)
        proxy.ServeHTTP(c.Writer, c.Request)
}

// proxyToAIService proxies requests to the AI Service
func proxyToAIService(c *gin.Context) {
        proxy := createReverseProxy(aiServiceURL)
        proxy.ServeHTTP(c.Writer, c.Request)
}

// proxyWebSocketToMessagingService handles WebSocket proxying for messaging
func proxyWebSocketToMessagingService(c *gin.Context) {
        // Extract target URL and modify path
        target := strings.Replace(messagingServiceURL, "http://", "", 1)
        target = strings.Replace(target, "https://", "", 1)
        
        // Forward WebSocket connection
        proxyWebSocket(c, target, "/ws")
}

// proxyWebSocketToStreamingService handles WebSocket proxying for streaming
func proxyWebSocketToStreamingService(c *gin.Context) {
        streamID := c.Param("streamId")
        target := strings.Replace(streamingServiceURL, "http://", "", 1)
        target = strings.Replace(target, "https://", "", 1)
        
        // Forward WebSocket connection with stream ID
        proxyWebSocket(c, target, fmt.Sprintf("/ws/stream/%s", streamID))
}

// proxyWebSocket proxies WebSocket connections
func proxyWebSocket(c *gin.Context, target, path string) {
        // This is a simplified WebSocket proxy
        // In production, you'd want to use a proper WebSocket proxy library
        
        // For now, return an error as WebSocket proxying requires additional setup
        utils.ServiceUnavailableError(c, "WebSocket proxying not yet implemented")
}

// LoadBalancer handles load balancing between multiple service instances
type LoadBalancer struct {
        services map[string][]*ServiceInstance
        current  map[string]int
}

// ServiceInstance represents a service instance
type ServiceInstance struct {
        URL       string
        Healthy   bool
        LastCheck time.Time
}

// NewLoadBalancer creates a new load balancer
func NewLoadBalancer() *LoadBalancer {
        return &LoadBalancer{
                services: make(map[string][]*ServiceInstance),
                current:  make(map[string]int),
        }
}

// AddService adds a service instance to the load balancer
func (lb *LoadBalancer) AddService(serviceName, url string) {
        instance := &ServiceInstance{
                URL:       url,
                Healthy:   true,
                LastCheck: time.Now(),
        }
        
        lb.services[serviceName] = append(lb.services[serviceName], instance)
}

// GetNextService returns the next healthy service instance using round-robin
func (lb *LoadBalancer) GetNextService(serviceName string) *ServiceInstance {
        instances := lb.services[serviceName]
        if len(instances) == 0 {
                return nil
        }

        // Find next healthy instance
        startIndex := lb.current[serviceName]
        for i := 0; i < len(instances); i++ {
                index := (startIndex + i) % len(instances)
                instance := instances[index]
                
                if instance.Healthy {
                        lb.current[serviceName] = (index + 1) % len(instances)
                        return instance
                }
        }

        // No healthy instances found
        return nil
}

// HealthCheck performs health checks on service instances
func (lb *LoadBalancer) HealthCheck() {
        for serviceName, instances := range lb.services {
                for _, instance := range instances {
                        go func(svc string, inst *ServiceInstance) {
                                client := &http.Client{
                                        Timeout: 5 * time.Second,
                                }
                                
                                resp, err := client.Get(inst.URL + "/health")
                                if err != nil {
                                        inst.Healthy = false
                                } else {
                                        inst.Healthy = resp.StatusCode == http.StatusOK
                                        resp.Body.Close()
                                }
                                
                                inst.LastCheck = time.Now()
                        }(serviceName, instance)
                }
        }
}

// Circuit Breaker pattern for service resilience
type CircuitBreaker struct {
        maxFailures int
        failures    int
        lastFailure time.Time
        timeout     time.Duration
        state       string // "closed", "open", "half-open"
}

// NewCircuitBreaker creates a new circuit breaker
func NewCircuitBreaker(maxFailures int, timeout time.Duration) *CircuitBreaker {
        return &CircuitBreaker{
                maxFailures: maxFailures,
                timeout:     timeout,
                state:       "closed",
        }
}

// Call executes a function with circuit breaker protection
func (cb *CircuitBreaker) Call(fn func() error) error {
        if cb.state == "open" {
                if time.Since(cb.lastFailure) > cb.timeout {
                        cb.state = "half-open"
                } else {
                        return fmt.Errorf("circuit breaker is open")
                }
        }

        err := fn()
        if err != nil {
                cb.failures++
                cb.lastFailure = time.Now()
                
                if cb.failures >= cb.maxFailures {
                        cb.state = "open"
                }
                return err
        }

        // Success - reset circuit breaker
        cb.failures = 0
        cb.state = "closed"
        return nil
}