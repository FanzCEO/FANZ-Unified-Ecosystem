package main

import (
        "net/http"
        "os"
        "time"

        "github.com/gin-gonic/gin"
        "github.com/fanz-os/shared/cache"
        "github.com/fanz-os/shared/middleware"
        "github.com/fanz-os/shared/utils"
)

// Service URLs
var (
        userServiceURL      = getEnv("USER_SERVICE_URL", "http://localhost:8001")
        contentServiceURL   = getEnv("CONTENT_SERVICE_URL", "http://localhost:8002")
        paymentServiceURL   = getEnv("PAYMENT_SERVICE_URL", "http://localhost:8003")
        streamingServiceURL = getEnv("STREAMING_SERVICE_URL", "http://localhost:8004")
        messagingServiceURL = getEnv("MESSAGING_SERVICE_URL", "http://localhost:8005")
        adminServiceURL     = getEnv("ADMIN_SERVICE_URL", "http://localhost:8006")
        aiServiceURL        = getEnv("AI_SERVICE_URL", "http://localhost:8007")
)

// setupRoutes configures all API Gateway routes
func setupRoutes(r *gin.Engine, redisClient *cache.RedisClient) {
        // Health check
        r.GET("/health", healthCheck)
        r.GET("/", rootHandler)

        // API versioning
        v1 := r.Group("/api/v1")
        {
                // Authentication routes (no auth required)
                auth := v1.Group("/auth")
                {
                        if redisClient != nil {
                                auth.Use(middleware.RateLimit(redisClient, middleware.AuthRateLimitConfig()))
                        }
                        auth.POST("/register", proxyToUserService)
                        auth.POST("/login", proxyToUserService)
                        auth.POST("/logout", proxyToUserService)
                        auth.POST("/refresh", proxyToUserService)
                        auth.POST("/verify-email", proxyToUserService)
                        auth.POST("/verify-phone", proxyToUserService)
                        auth.POST("/forgot-password", proxyToUserService)
                        auth.POST("/reset-password", proxyToUserService)
                        auth.POST("/2fa/setup", middleware.AuthMiddleware(), proxyToUserService)
                        auth.POST("/2fa/verify", middleware.AuthMiddleware(), proxyToUserService)
                }

                // User routes (authentication required)
                users := v1.Group("/users")
                users.Use(middleware.AuthMiddleware())
                {
                        users.GET("/profile", proxyToUserService)
                        users.PUT("/profile", proxyToUserService)
                        users.GET("/settings", proxyToUserService)
                        users.PUT("/settings", proxyToUserService)
                        users.POST("/follow/:userId", proxyToUserService)
                        users.DELETE("/follow/:userId", proxyToUserService)
                        users.GET("/followers", proxyToUserService)
                        users.GET("/following", proxyToUserService)
                        users.GET("/creator/stats", middleware.RequireRole("creator", "admin"), proxyToUserService)
                        users.GET("/earnings", middleware.RequireRole("creator", "admin"), proxyToUserService)
                }

                // Content routes
                content := v1.Group("/content")
                {
                        // Public content browsing
                        content.GET("/posts", middleware.OptionalAuth(), proxyToContentService)
                        content.GET("/posts/:id", middleware.OptionalAuth(), proxyToContentService)
                        content.GET("/short-videos", middleware.OptionalAuth(), proxyToContentService)
                        content.GET("/short-videos/:id", middleware.OptionalAuth(), proxyToContentService)
                        content.GET("/hashtags/trending", proxyToContentService)
                        
                        // Authenticated content actions
                        contentAuth := content.Group("")
                        contentAuth.Use(middleware.AuthMiddleware())
                        {
                                // Creator content management
                                contentAuth.POST("/posts", middleware.RequireRole("creator", "admin"), proxyToContentService)
                                contentAuth.PUT("/posts/:id", middleware.RequireRole("creator", "admin"), proxyToContentService)
                                contentAuth.DELETE("/posts/:id", middleware.RequireRole("creator", "admin"), proxyToContentService)
                                
                                contentAuth.POST("/short-videos", middleware.RequireRole("creator", "admin"), proxyToContentService)
                                contentAuth.PUT("/short-videos/:id", middleware.RequireRole("creator", "admin"), proxyToContentService)
                                contentAuth.DELETE("/short-videos/:id", middleware.RequireRole("creator", "admin"), proxyToContentService)
                                
                                // User interactions
                                contentAuth.POST("/posts/:id/like", proxyToContentService)
                                contentAuth.DELETE("/posts/:id/like", proxyToContentService)
                                contentAuth.POST("/posts/:id/comment", proxyToContentService)
                                contentAuth.GET("/posts/:id/comments", proxyToContentService)
                                
                                contentAuth.POST("/short-videos/:id/reaction", proxyToContentService)
                                contentAuth.POST("/short-videos/:id/comment", proxyToContentService)
                                contentAuth.GET("/short-videos/:id/comments", proxyToContentService)
                                
                                // PPV unlocks
                                contentAuth.POST("/posts/:id/unlock", proxyToContentService)
                                contentAuth.POST("/messages/:id/unlock", proxyToContentService)
                        }

                        // Media upload routes (with stricter rate limiting)
                        upload := content.Group("/upload")
                        upload.Use(middleware.AuthMiddleware())
                        upload.Use(middleware.RequireRole("creator", "admin"))
                        if redisClient != nil {
                                upload.Use(middleware.RateLimit(redisClient, middleware.UploadRateLimitConfig()))
                        }
                        {
                                upload.POST("/image", proxyToContentService)
                                upload.POST("/video", proxyToContentService)
                                upload.POST("/audio", proxyToContentService)
                        }
                }

                // Payment routes
                payments := v1.Group("/payments")
                payments.Use(middleware.AuthMiddleware())
                {
                        payments.GET("/methods", proxyToPaymentService)
                        payments.POST("/methods", proxyToPaymentService)
                        payments.DELETE("/methods/:id", proxyToPaymentService)
                        
                        payments.POST("/subscribe/:creatorId", proxyToPaymentService)
                        payments.DELETE("/subscribe/:creatorId", proxyToPaymentService)
                        payments.GET("/subscriptions", proxyToPaymentService)
                        
                        payments.POST("/tip", proxyToPaymentService)
                        payments.POST("/withdraw", middleware.RequireRole("creator", "admin"), proxyToPaymentService)
                        payments.GET("/transactions", proxyToPaymentService)
                        payments.GET("/earnings", middleware.RequireRole("creator", "admin"), proxyToPaymentService)
                }

                // Messaging routes
                messages := v1.Group("/messages")
                messages.Use(middleware.AuthMiddleware())
                {
                        messages.GET("/conversations", proxyToMessagingService)
                        messages.GET("/conversations/:userId", proxyToMessagingService)
                        messages.POST("/send", proxyToMessagingService)
                        messages.PUT("/:messageId/read", proxyToMessagingService)
                }

                // Live streaming routes
                streaming := v1.Group("/streaming")
                {
                        // Public streaming endpoints
                        streaming.GET("/streams", middleware.OptionalAuth(), proxyToStreamingService)
                        streaming.GET("/streams/:id", middleware.OptionalAuth(), proxyToStreamingService)
                        
                        // Authenticated streaming
                        streamAuth := streaming.Group("")
                        streamAuth.Use(middleware.AuthMiddleware())
                        {
                                // Creator streaming controls
                                streamAuth.POST("/streams", middleware.RequireRole("creator", "admin"), proxyToStreamingService)
                                streamAuth.PUT("/streams/:id", middleware.RequireRole("creator", "admin"), proxyToStreamingService)
                                streamAuth.DELETE("/streams/:id", middleware.RequireRole("creator", "admin"), proxyToStreamingService)
                                streamAuth.POST("/streams/:id/start", middleware.RequireRole("creator", "admin"), proxyToStreamingService)
                                streamAuth.POST("/streams/:id/end", middleware.RequireRole("creator", "admin"), proxyToStreamingService)
                                
                                // Viewer interactions
                                streamAuth.POST("/streams/:id/join", proxyToStreamingService)
                                streamAuth.POST("/streams/:id/leave", proxyToStreamingService)
                                streamAuth.POST("/streams/:id/chat", proxyToStreamingService)
                        }
                }

                // Admin routes
                admin := v1.Group("/admin")
                admin.Use(middleware.AuthMiddleware())
                admin.Use(middleware.RequireRole("admin"))
                {
                        admin.GET("/users", proxyToAdminService)
                        admin.GET("/users/:id", proxyToAdminService)
                        admin.PUT("/users/:id/status", proxyToAdminService)
                        admin.GET("/content/flagged", proxyToAdminService)
                        admin.PUT("/content/:id/moderate", proxyToAdminService)
                        admin.GET("/compliance/records", proxyToAdminService)
                        admin.PUT("/compliance/records/:id/approve", proxyToAdminService)
                        admin.PUT("/compliance/records/:id/reject", proxyToAdminService)
                        admin.GET("/analytics/platform", proxyToAdminService)
                        admin.GET("/reports", proxyToAdminService)
                }

                // AI service routes
                ai := v1.Group("/ai")
                ai.Use(middleware.AuthMiddleware())
                {
                        ai.POST("/moderate", middleware.RequireRole("admin"), proxyToAIService)
                        ai.GET("/recommendations", proxyToAIService)
                        ai.POST("/content/analyze", middleware.RequireRole("creator", "admin"), proxyToAIService)
                }

                // Compliance routes
                compliance := v1.Group("/compliance")
                compliance.Use(middleware.AuthMiddleware())
                compliance.Use(middleware.RequireRole("creator", "admin"))
                {
                        compliance.POST("/2257", proxyToUserService)
                        compliance.GET("/2257", proxyToUserService)
                        compliance.PUT("/2257/:id", proxyToUserService)
                        compliance.POST("/costar/invite", proxyToUserService)
                        compliance.POST("/costar/verify", proxyToUserService)
                        compliance.GET("/documents", proxyToUserService)
                        compliance.POST("/documents", proxyToUserService)
                        compliance.DELETE("/documents/:id", proxyToUserService)
                }

                // Notifications
                notifications := v1.Group("/notifications")
                notifications.Use(middleware.AuthMiddleware())
                {
                        notifications.GET("", proxyToUserService)
                        notifications.PUT("/:id/read", proxyToUserService)
                        notifications.POST("/push/subscribe", proxyToUserService)
                        notifications.DELETE("/push/unsubscribe", proxyToUserService)
                }
        }

        // WebSocket routes (handled by messaging service)
        r.GET("/ws", middleware.AuthMiddleware(), proxyWebSocketToMessagingService)
        r.GET("/ws/stream/:streamId", middleware.AuthMiddleware(), proxyWebSocketToStreamingService)
}

// healthCheck returns the health status of the API Gateway
func healthCheck(c *gin.Context) {
        utils.SuccessResponse(c, gin.H{
                "status": "healthy",
                "service": "api-gateway",
                "timestamp": time.Now().Unix(),
        })
}

// rootHandler returns API information
func rootHandler(c *gin.Context) {
        utils.SuccessResponse(c, gin.H{
                "name": "Fanz Operating System API Gateway",
                "version": "1.0.0",
                "description": "High-performance Go microservices API for adult content creator platform",
                "endpoints": gin.H{
                        "health": "/health",
                        "api": "/api/v1",
                        "docs": "/docs",
                },
        })
}