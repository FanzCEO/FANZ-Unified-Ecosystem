package main

import (
	"database/sql"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/shopspring/decimal"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// TransactionService handles transaction operations
type TransactionService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewTransactionService creates a new transaction service instance
func NewTransactionService(db *database.DB, redis *cache.RedisClient) *TransactionService {
	return &TransactionService{
		db:    db,
		redis: redis,
	}
}

// GetTransactions gets user's transactions with pagination
func (s *TransactionService) GetTransactions(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	// Get query parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	transactionType := c.Query("type")

	// Validate pagination
	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 20
	}

	offset := (page - 1) * limit

	// Build query
	whereClause := []string{"user_id = $1"}
	args := []interface{}{userID}
	argIndex := 2

	if transactionType != "" {
		whereClause = append(whereClause, fmt.Sprintf("type = $%d", argIndex))
		args = append(args, transactionType)
		argIndex++
	}

	// Get total count
	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM transactions WHERE %s", strings.Join(whereClause, " AND "))
	var total int
	err = s.db.QueryRow(countQuery, args...).Scan(&total)
	if err != nil {
		utils.InternalServerError(c, "Failed to count transactions")
		return
	}

	// Get transactions
	query := fmt.Sprintf(`
		SELECT id, user_id, recipient_id, type, amount, description, 
			   post_id, message_id, subscription_id, created_at
		FROM transactions 
		WHERE %s
		ORDER BY created_at DESC
		LIMIT $%d OFFSET $%d
	`, strings.Join(whereClause, " AND "), argIndex, argIndex+1)

	args = append(args, limit, offset)

	rows, err := s.db.Query(query, args...)
	if err != nil {
		utils.InternalServerError(c, "Failed to get transactions")
		return
	}
	defer rows.Close()

	var transactions []models.Transaction
	for rows.Next() {
		var transaction models.Transaction
		err := rows.Scan(
			&transaction.ID, &transaction.UserID, &transaction.RecipientID,
			&transaction.Type, &transaction.Amount, &transaction.Description,
			&transaction.PostID, &transaction.MessageID, &transaction.SubscriptionID,
			&transaction.CreatedAt,
		)
		if err != nil {
			continue
		}
		transactions = append(transactions, transaction)
	}

	// Calculate pagination metadata
	totalPages := (total + limit - 1) / limit
	meta := &utils.Meta{
		Page:       page,
		Limit:      limit,
		Total:      total,
		TotalPages: totalPages,
	}

	utils.SuccessResponseWithMeta(c, transactions, meta)
}

// GetTransaction gets a specific transaction
func (s *TransactionService) GetTransaction(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	transactionID := c.Param("id")
	if transactionID == "" {
		utils.BadRequestError(c, "Transaction ID is required")
		return
	}

	var transaction models.Transaction
	err = s.db.QueryRow(`
		SELECT id, user_id, recipient_id, type, amount, description, 
			   post_id, message_id, subscription_id, created_at
		FROM transactions 
		WHERE id = $1 AND user_id = $2
	`, transactionID, userID).Scan(
		&transaction.ID, &transaction.UserID, &transaction.RecipientID,
		&transaction.Type, &transaction.Amount, &transaction.Description,
		&transaction.PostID, &transaction.MessageID, &transaction.SubscriptionID,
		&transaction.CreatedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Transaction not found")
		} else {
			utils.InternalServerError(c, "Failed to get transaction")
		}
		return
	}

	utils.SuccessResponse(c, transaction)
}

// SendTip sends a tip to a creator
func (s *TransactionService) SendTip(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	var req models.CreateTipRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	if req.Amount.LessThanOrEqual(decimal.Zero) {
		utils.BadRequestError(c, "Tip amount must be greater than 0")
	}

	if userID == req.RecipientID {
		utils.BadRequestError(c, "Cannot tip yourself")
		return
	}

	// Check user has sufficient balance (simplified check)
	// In production, this would involve payment processor integration

	// Create tip record
	tipID := uuid.New().String()
	now := time.Now()

	_, err = s.db.Exec(`
		INSERT INTO tips (id, sender_id, recipient_id, amount, message, post_id, is_anonymous, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
	`, tipID, userID, req.RecipientID, req.Amount, req.Message, req.PostID, req.IsAnonymous, now)

	if err != nil {
		utils.InternalServerError(c, "Failed to send tip")
		return
	}

	// Create transaction record
	transactionID := uuid.New().String()
	_, err = s.db.Exec(`
		INSERT INTO transactions (id, user_id, recipient_id, type, amount, description, post_id, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
	`, transactionID, userID, req.RecipientID, models.TransactionTypeTip, req.Amount, "Tip sent", req.PostID, now)

	if err != nil {
		// Log error but don't fail the tip
		utils.InternalServerError(c, "Tip sent but failed to record transaction")
		return
	}

	utils.CreatedResponse(c, gin.H{
		"tip_id":      tipID,
		"recipient_id": req.RecipientID,
		"amount":      req.Amount,
		"message":     "Tip sent successfully",
	})
}

// UnlockPPVContent unlocks pay-per-view content
func (s *TransactionService) UnlockPPVContent(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	var req models.CreatePPVUnlockRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	if req.Price.LessThanOrEqual(decimal.Zero) {
		utils.BadRequestError(c, "PPV price must be greater than 0")
		return
	}

	// Validate that either PostID or MessageID is provided
	if req.PostID == nil && req.MessageID == nil {
		utils.BadRequestError(c, "Either post ID or message ID is required")
		return
	}

	// Check if already unlocked
	var contentType string
	var contentID string
	if req.PostID != nil {
		contentType = "post"
		contentID = *req.PostID
	} else {
		contentType = "message"
		contentID = *req.MessageID
	}

	hasAccess, err := s.hasAccessToPPVContent(userID, contentType, contentID)
	if err != nil {
		utils.InternalServerError(c, "Failed to check access")
		return
	}
	if hasAccess {
		utils.ConflictError(c, "Content already unlocked")
		return
	}

	// Create PPV unlock record
	unlockID := uuid.New().String()
	now := time.Now()

	_, err = s.db.Exec(`
		INSERT INTO ppv_unlocks (id, user_id, post_id, message_id, price, created_at)
		VALUES ($1, $2, $3, $4, $5, $6)
	`, unlockID, userID, req.PostID, req.MessageID, req.Price, now)

	if err != nil {
		utils.InternalServerError(c, "Failed to unlock content")
		return
	}

	// Create transaction record
	transactionID := uuid.New().String()
	description := fmt.Sprintf("PPV unlock - %s", contentType)
	
	_, err = s.db.Exec(`
		INSERT INTO transactions (id, user_id, type, amount, description, post_id, message_id, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
	`, transactionID, userID, models.TransactionTypePPVUnlock, req.Price, description, req.PostID, req.MessageID, now)

	if err != nil {
		// Log error but don't fail the unlock
		utils.InternalServerError(c, "Content unlocked but failed to record transaction")
		return
	}

	utils.CreatedResponse(c, gin.H{
		"unlock_id":    unlockID,
		"content_type": contentType,
		"content_id":   contentID,
		"price":        req.Price,
		"message":      "Content unlocked successfully",
	})
}

// GetWalletBalance gets user's wallet balance
func (s *TransactionService) GetWalletBalance(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	var balance decimal.Decimal
	err = s.db.QueryRow(`
		SELECT COALESCE(balance, 0) FROM users WHERE id = $1
	`, userID).Scan(&balance)

	if err != nil {
		utils.InternalServerError(c, "Failed to get wallet balance")
		return
	}

	utils.SuccessResponse(c, gin.H{
		"balance": balance,
		"currency": "USD",
	})
}

// GetWalletStatement gets user's wallet statement
func (s *TransactionService) GetWalletStatement(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	// Get recent transactions
	rows, err := s.db.Query(`
		SELECT id, user_id, recipient_id, type, amount, description, created_at
		FROM transactions 
		WHERE user_id = $1 OR recipient_id = $1
		ORDER BY created_at DESC
		LIMIT 50
	`, userID)

	if err != nil {
		utils.InternalServerError(c, "Failed to get wallet statement")
		return
	}
	defer rows.Close()

	var transactions []map[string]interface{}
	for rows.Next() {
		var transaction models.Transaction
		err := rows.Scan(
			&transaction.ID, &transaction.UserID, &transaction.RecipientID,
			&transaction.Type, &transaction.Amount, &transaction.Description,
			&transaction.CreatedAt,
		)
		if err != nil {
			continue
		}

		// Determine if this is incoming or outgoing
		direction := "outgoing"
		if transaction.RecipientID != nil && *transaction.RecipientID == userID {
			direction = "incoming"
		}

		transactionData := map[string]interface{}{
			"id":          transaction.ID,
			"type":        transaction.Type,
			"amount":      transaction.Amount,
			"description": transaction.Description,
			"direction":   direction,
			"created_at":  transaction.CreatedAt,
		}

		transactions = append(transactions, transactionData)
	}

	// Get current balance
	var balance decimal.Decimal
	s.db.QueryRow(`SELECT COALESCE(balance, 0) FROM users WHERE id = $1`, userID).Scan(&balance)

	utils.SuccessResponse(c, gin.H{
		"balance":      balance,
		"transactions": transactions,
	})
}

// Helper functions

func (s *TransactionService) hasAccessToPPVContent(userID, contentType, contentID string) (bool, error) {
	var count int
	var query string

	if contentType == "post" {
		query = "SELECT COUNT(*) FROM ppv_unlocks WHERE user_id = $1 AND post_id = $2"
	} else {
		query = "SELECT COUNT(*) FROM ppv_unlocks WHERE user_id = $1 AND message_id = $2"
	}

	err := s.db.QueryRow(query, userID, contentID).Scan(&count)
	return count > 0, err
}

// Placeholder implementations for remaining methods
func (s *TransactionService) GetEarnings(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get earnings not yet implemented")
}

func (s *TransactionService) GetTransactionAnalytics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Transaction analytics not yet implemented")
}

func (s *TransactionService) TransferFunds(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Transfer funds not yet implemented")
}

func (s *TransactionService) CreateStripePaymentIntent(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Stripe payment intent not yet implemented")
}

func (s *TransactionService) ConfirmStripePayment(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Confirm Stripe payment not yet implemented")
}

func (s *TransactionService) GetStripePaymentStatus(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Stripe payment status not yet implemented")
}

func (s *TransactionService) CreateCryptoInvoice(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Crypto invoice not yet implemented")
}

func (s *TransactionService) GetCryptoInvoiceStatus(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Crypto invoice status not yet implemented")
}

func (s *TransactionService) VerifyCryptoPayment(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Verify crypto payment not yet implemented")
}

func (s *TransactionService) CreateCCBillTransaction(c *gin.Context) {
	utils.ServiceUnavailableError(c, "CCBill transaction not yet implemented")
}

func (s *TransactionService) GetCCBillTransactionStatus(c *gin.Context) {
	utils.ServiceUnavailableError(c, "CCBill transaction status not yet implemented")
}

func (s *TransactionService) GetAllTransactions(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get all transactions not yet implemented")
}

func (s *TransactionService) GetFlaggedTransactions(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Flagged transactions not yet implemented")
}

func (s *TransactionService) ReviewTransaction(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Review transaction not yet implemented")
}

func (s *TransactionService) GetPlatformPaymentAnalytics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Platform payment analytics not yet implemented")
}

func (s *TransactionService) GetPlatformRevenueAnalytics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Platform revenue analytics not yet implemented")
}

func (s *TransactionService) GetTaxForms(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Tax forms not yet implemented")
}

func (s *TransactionService) Generate1099Form(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Generate 1099 form not yet implemented")
}

func (s *TransactionService) GetTaxSummary(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Tax summary not yet implemented")
}

func (s *TransactionService) ExportTaxData(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Export tax data not yet implemented")
}

func (s *TransactionService) GetMarketplacePricing(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Marketplace pricing not yet implemented")
}

func (s *TransactionService) SetDynamicPricing(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Dynamic pricing not yet implemented")
}

func (s *TransactionService) GetAvailableDiscounts(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Available discounts not yet implemented")
}

func (s *TransactionService) ApplyDiscount(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Apply discount not yet implemented")
}