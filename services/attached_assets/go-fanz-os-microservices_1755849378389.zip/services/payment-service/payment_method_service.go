package main

import (
	"github.com/gin-gonic/gin"
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/utils"
)

// PaymentMethodService handles payment method operations
type PaymentMethodService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewPaymentMethodService creates a new payment method service instance
func NewPaymentMethodService(db *database.DB, redis *cache.RedisClient) *PaymentMethodService {
	return &PaymentMethodService{
		db:    db,
		redis: redis,
	}
}

// GetPaymentMethods gets user's payment methods
func (s *PaymentMethodService) GetPaymentMethods(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get payment methods not yet implemented")
}

// AddPaymentMethod adds a new payment method
func (s *PaymentMethodService) AddPaymentMethod(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Add payment method not yet implemented")
}

// SetDefaultPaymentMethod sets a payment method as default
func (s *PaymentMethodService) SetDefaultPaymentMethod(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Set default payment method not yet implemented")
}

// RemovePaymentMethod removes a payment method
func (s *PaymentMethodService) RemovePaymentMethod(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Remove payment method not yet implemented")
}

// CreateStripeSetupIntent creates a Stripe setup intent
func (s *PaymentMethodService) CreateStripeSetupIntent(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Stripe setup intent not yet implemented")
}

// AttachStripePaymentMethod attaches a Stripe payment method
func (s *PaymentMethodService) AttachStripePaymentMethod(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Attach Stripe payment method not yet implemented")
}

// AddCryptoWallet adds a crypto wallet
func (s *PaymentMethodService) AddCryptoWallet(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Add crypto wallet not yet implemented")
}

// GetSupportedCryptocurrencies gets supported cryptocurrencies
func (s *PaymentMethodService) GetSupportedCryptocurrencies(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Supported cryptocurrencies not yet implemented")
}

// GetAllPaymentMethods gets all payment methods (admin)
func (s *PaymentMethodService) GetAllPaymentMethods(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get all payment methods not yet implemented")
}

// UpdatePaymentMethodStatus updates payment method status (admin)
func (s *PaymentMethodService) UpdatePaymentMethodStatus(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Update payment method status not yet implemented")
}