package main

import (
	"database/sql"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/shopspring/decimal"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// SubscriptionService handles subscription operations
type SubscriptionService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewSubscriptionService creates a new subscription service instance
func NewSubscriptionService(db *database.DB, redis *cache.RedisClient) *SubscriptionService {
	return &SubscriptionService{
		db:    db,
		redis: redis,
	}
}

// Subscribe subscribes a fan to a creator
func (s *SubscriptionService) Subscribe(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	creatorID := c.Param("creatorId")
	if creatorID == "" {
		utils.BadRequestError(c, "Creator ID is required")
		return
	}

	if userID == creatorID {
		utils.BadRequestError(c, "Cannot subscribe to yourself")
		return
	}

	// Check if already subscribed
	exists, err := s.isSubscribed(userID, creatorID)
	if err != nil {
		utils.InternalServerError(c, "Failed to check subscription status")
		return
	}
	if exists {
		utils.ConflictError(c, "Already subscribed to this creator")
		return
	}

	// Get creator's subscription price
	price, err := s.getCreatorSubscriptionPrice(creatorID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get creator subscription price")
		return
	}

	// Create subscription
	subscriptionID := uuid.New().String()
	now := time.Now()
	endDate := now.AddDate(0, 1, 0) // 1 month subscription

	_, err = s.db.Exec(`
		INSERT INTO subscriptions (id, fan_id, creator_id, is_active, start_date, end_date, price, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
	`, subscriptionID, userID, creatorID, true, now, endDate, price, now, now)

	if err != nil {
		utils.InternalServerError(c, "Failed to create subscription")
		return
	}

	// Create transaction record
	transactionID := uuid.New().String()
	_, err = s.db.Exec(`
		INSERT INTO transactions (id, user_id, recipient_id, type, amount, subscription_id, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7)
	`, transactionID, userID, creatorID, models.TransactionTypeSubscription, price, subscriptionID, now)

	if err != nil {
		// Log error but don't fail the subscription
		utils.InternalServerError(c, "Subscription created but failed to record transaction")
		return
	}

	// Update creator subscriber count
	s.db.Exec(`
		UPDATE users SET subscriber_count = subscriber_count + 1 
		WHERE id = $1
	`, creatorID)

	utils.CreatedResponse(c, gin.H{
		"subscription_id": subscriptionID,
		"creator_id":      creatorID,
		"price":           price,
		"start_date":      now,
		"end_date":        endDate,
		"message":         "Successfully subscribed to creator",
	})
}

// Unsubscribe unsubscribes a fan from a creator
func (s *SubscriptionService) Unsubscribe(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	creatorID := c.Param("creatorId")
	if creatorID == "" {
		utils.BadRequestError(c, "Creator ID is required")
		return
	}

	// Check if subscribed
	exists, err := s.isSubscribed(userID, creatorID)
	if err != nil {
		utils.InternalServerError(c, "Failed to check subscription status")
		return
	}
	if !exists {
		utils.NotFoundError(c, "Subscription not found")
		return
	}

	// Deactivate subscription
	_, err = s.db.Exec(`
		UPDATE subscriptions 
		SET is_active = false, end_date = $1, updated_at = $2
		WHERE fan_id = $3 AND creator_id = $4 AND is_active = true
	`, time.Now(), time.Now(), userID, creatorID)

	if err != nil {
		utils.InternalServerError(c, "Failed to cancel subscription")
		return
	}

	// Update creator subscriber count
	s.db.Exec(`
		UPDATE users SET subscriber_count = GREATEST(subscriber_count - 1, 0) 
		WHERE id = $1
	`, creatorID)

	utils.SuccessResponse(c, gin.H{"message": "Successfully unsubscribed from creator"})
}

// GetUserSubscriptions gets user's subscriptions
func (s *SubscriptionService) GetUserSubscriptions(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	rows, err := s.db.Query(`
		SELECT s.id, s.fan_id, s.creator_id, s.is_active, s.start_date, s.end_date, 
			   s.price, s.created_at, s.updated_at, u.display_name, u.profile_image_url
		FROM subscriptions s
		JOIN users u ON s.creator_id = u.id
		WHERE s.fan_id = $1
		ORDER BY s.created_at DESC
	`, userID)

	if err != nil {
		utils.InternalServerError(c, "Failed to get subscriptions")
		return
	}
	defer rows.Close()

	var subscriptions []map[string]interface{}
	for rows.Next() {
		var subscription models.Subscription
		var creatorName, profileImageURL *string
		
		err := rows.Scan(
			&subscription.ID, &subscription.FanID, &subscription.CreatorID,
			&subscription.IsActive, &subscription.StartDate, &subscription.EndDate,
			&subscription.Price, &subscription.CreatedAt, &subscription.UpdatedAt,
			&creatorName, &profileImageURL,
		)
		if err != nil {
			continue
		}

		subscriptionData := map[string]interface{}{
			"id":          subscription.ID,
			"creator_id":  subscription.CreatorID,
			"is_active":   subscription.IsActive,
			"start_date":  subscription.StartDate,
			"end_date":    subscription.EndDate,
			"price":       subscription.Price,
			"created_at":  subscription.CreatedAt,
			"updated_at":  subscription.UpdatedAt,
			"creator_name": creatorName,
			"creator_avatar": profileImageURL,
		}

		subscriptions = append(subscriptions, subscriptionData)
	}

	utils.SuccessResponse(c, subscriptions)
}

// GetActiveSubscriptions gets user's active subscriptions
func (s *SubscriptionService) GetActiveSubscriptions(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	rows, err := s.db.Query(`
		SELECT s.id, s.fan_id, s.creator_id, s.is_active, s.start_date, s.end_date, 
			   s.price, s.created_at, s.updated_at, u.display_name, u.profile_image_url
		FROM subscriptions s
		JOIN users u ON s.creator_id = u.id
		WHERE s.fan_id = $1 AND s.is_active = true AND s.end_date > $2
		ORDER BY s.end_date DESC
	`, userID, time.Now())

	if err != nil {
		utils.InternalServerError(c, "Failed to get active subscriptions")
		return
	}
	defer rows.Close()

	var subscriptions []map[string]interface{}
	for rows.Next() {
		var subscription models.Subscription
		var creatorName, profileImageURL *string
		
		err := rows.Scan(
			&subscription.ID, &subscription.FanID, &subscription.CreatorID,
			&subscription.IsActive, &subscription.StartDate, &subscription.EndDate,
			&subscription.Price, &subscription.CreatedAt, &subscription.UpdatedAt,
			&creatorName, &profileImageURL,
		)
		if err != nil {
			continue
		}

		subscriptionData := map[string]interface{}{
			"id":          subscription.ID,
			"creator_id":  subscription.CreatorID,
			"is_active":   subscription.IsActive,
			"start_date":  subscription.StartDate,
			"end_date":    subscription.EndDate,
			"price":       subscription.Price,
			"created_at":  subscription.CreatedAt,
			"updated_at":  subscription.UpdatedAt,
			"creator_name": creatorName,
			"creator_avatar": profileImageURL,
		}

		subscriptions = append(subscriptions, subscriptionData)
	}

	utils.SuccessResponse(c, subscriptions)
}

// GetSubscribers gets creator's subscribers
func (s *SubscriptionService) GetSubscribers(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	rows, err := s.db.Query(`
		SELECT s.id, s.fan_id, s.creator_id, s.is_active, s.start_date, s.end_date, 
			   s.price, s.created_at, s.updated_at, u.display_name, u.profile_image_url
		FROM subscriptions s
		JOIN users u ON s.fan_id = u.id
		WHERE s.creator_id = $1 AND s.is_active = true
		ORDER BY s.created_at DESC
	`, userID)

	if err != nil {
		utils.InternalServerError(c, "Failed to get subscribers")
		return
	}
	defer rows.Close()

	var subscribers []map[string]interface{}
	for rows.Next() {
		var subscription models.Subscription
		var fanName, profileImageURL *string
		
		err := rows.Scan(
			&subscription.ID, &subscription.FanID, &subscription.CreatorID,
			&subscription.IsActive, &subscription.StartDate, &subscription.EndDate,
			&subscription.Price, &subscription.CreatedAt, &subscription.UpdatedAt,
			&fanName, &profileImageURL,
		)
		if err != nil {
			continue
		}

		subscriberData := map[string]interface{}{
			"subscription_id": subscription.ID,
			"fan_id":         subscription.FanID,
			"is_active":      subscription.IsActive,
			"start_date":     subscription.StartDate,
			"end_date":       subscription.EndDate,
			"price":          subscription.Price,
			"subscribed_at":  subscription.CreatedAt,
			"fan_name":       fanName,
			"fan_avatar":     profileImageURL,
		}

		subscribers = append(subscribers, subscriberData)
	}

	utils.SuccessResponse(c, subscribers)
}

// UpdateSubscriptionPrice updates creator's subscription price
func (s *SubscriptionService) UpdateSubscriptionPrice(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	var req struct {
		Price decimal.Decimal `json:"price" binding:"required,min=0"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Update user's subscription price
	_, err = s.db.Exec(`
		UPDATE users SET subscription_price = $1, updated_at = $2 
		WHERE id = $3
	`, req.Price, time.Now(), userID)

	if err != nil {
		utils.InternalServerError(c, "Failed to update subscription price")
		return
	}

	utils.SuccessResponse(c, gin.H{
		"message": "Subscription price updated successfully",
		"new_price": req.Price,
	})
}

// Helper functions

func (s *SubscriptionService) isSubscribed(fanID, creatorID string) (bool, error) {
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM subscriptions 
		WHERE fan_id = $1 AND creator_id = $2 AND is_active = true AND end_date > $3
	`, fanID, creatorID, time.Now()).Scan(&count)
	return count > 0, err
}

func (s *SubscriptionService) getCreatorSubscriptionPrice(creatorID string) (decimal.Decimal, error) {
	var price decimal.Decimal
	err := s.db.QueryRow(`
		SELECT subscription_price FROM users WHERE id = $1
	`, creatorID).Scan(&price)
	return price, err
}

// Placeholder implementations for remaining methods
func (s *SubscriptionService) GetSubscriptionHistory(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Subscription history not yet implemented")
}

func (s *SubscriptionService) GetSubscriptionAnalytics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Subscription analytics not yet implemented")
}

func (s *SubscriptionService) GetSubscriptionRevenue(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Subscription revenue not yet implemented")
}