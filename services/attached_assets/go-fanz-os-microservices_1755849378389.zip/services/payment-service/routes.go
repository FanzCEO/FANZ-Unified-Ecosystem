package main

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/utils"
)

// setupRoutes configures all Payment Service routes
func setupRoutes(
	r *gin.Engine,
	paymentMethodService *PaymentMethodService,
	subscriptionService *SubscriptionService,
	transactionService *TransactionService,
	withdrawalService *WithdrawalService,
	webhookService *WebhookService,
) {
	// Health check
	r.GET("/health", healthCheck)
	r.GET("/", rootHandler)

	// Payment methods routes
	methods := r.Group("/methods")
	methods.Use(middleware.AuthMiddleware())
	{
		methods.GET("", paymentMethodService.GetPaymentMethods)
		methods.POST("", paymentMethodService.AddPaymentMethod)
		methods.PUT("/:id/default", paymentMethodService.SetDefaultPaymentMethod)
		methods.DELETE("/:id", paymentMethodService.RemovePaymentMethod)
		
		// Stripe-specific routes
		methods.POST("/stripe/setup-intent", paymentMethodService.CreateStripeSetupIntent)
		methods.POST("/stripe/attach", paymentMethodService.AttachStripePaymentMethod)
		
		// Crypto payment methods
		methods.POST("/crypto/wallet", paymentMethodService.AddCryptoWallet)
		methods.GET("/crypto/supported", paymentMethodService.GetSupportedCryptocurrencies)
	}

	// Subscription routes
	subscriptions := r.Group("/subscriptions")
	subscriptions.Use(middleware.AuthMiddleware())
	{
		// Fan subscription management
		subscriptions.GET("", subscriptionService.GetUserSubscriptions)
		subscriptions.POST("/subscribe/:creatorId", subscriptionService.Subscribe)
		subscriptions.DELETE("/unsubscribe/:creatorId", subscriptionService.Unsubscribe)
		subscriptions.GET("/active", subscriptionService.GetActiveSubscriptions)
		subscriptions.GET("/history", subscriptionService.GetSubscriptionHistory)
		
		// Creator subscription management
		creator := subscriptions.Group("/creator")
		creator.Use(middleware.RequireRole("creator", "admin"))
		{
			creator.GET("/subscribers", subscriptionService.GetSubscribers)
			creator.PUT("/price", subscriptionService.UpdateSubscriptionPrice)
			creator.GET("/analytics", subscriptionService.GetSubscriptionAnalytics)
			creator.GET("/revenue", subscriptionService.GetSubscriptionRevenue)
		}
	}

	// Transaction routes
	transactions := r.Group("/transactions")
	transactions.Use(middleware.AuthMiddleware())
	{
		transactions.GET("", transactionService.GetTransactions)
		transactions.GET("/:id", transactionService.GetTransaction)
		transactions.POST("/tip", transactionService.SendTip)
		transactions.POST("/ppv-unlock", transactionService.UnlockPPVContent)
		transactions.GET("/earnings", middleware.RequireRole("creator", "admin"), transactionService.GetEarnings)
		transactions.GET("/analytics", middleware.RequireRole("creator", "admin"), transactionService.GetTransactionAnalytics)
	}

	// Withdrawal routes (creators only)
	withdrawals := r.Group("/withdrawals")
	withdrawals.Use(middleware.AuthMiddleware())
	withdrawals.Use(middleware.RequireRole("creator", "admin"))
	{
		withdrawals.GET("", withdrawalService.GetWithdrawals)
		withdrawals.POST("", withdrawalService.RequestWithdrawal)
		withdrawals.GET("/:id/status", withdrawalService.GetWithdrawalStatus)
		withdrawals.POST("/:id/cancel", withdrawalService.CancelWithdrawal)
		withdrawals.GET("/methods", withdrawalService.GetWithdrawalMethods)
	}

	// Wallet and balance routes
	wallet := r.Group("/wallet")
	wallet.Use(middleware.AuthMiddleware())
	{
		wallet.GET("/balance", transactionService.GetWalletBalance)
		wallet.GET("/statement", transactionService.GetWalletStatement)
		wallet.POST("/transfer", middleware.RequireRole("creator", "admin"), transactionService.TransferFunds)
	}

	// Payment processing routes
	payments := r.Group("/payments")
	{
		// Stripe payment processing
		stripe := payments.Group("/stripe")
		stripe.Use(middleware.AuthMiddleware())
		{
			stripe.POST("/create-intent", transactionService.CreateStripePaymentIntent)
			stripe.POST("/confirm-payment", transactionService.ConfirmStripePayment)
			stripe.GET("/payment-status/:intentId", transactionService.GetStripePaymentStatus)
		}

		// Crypto payment processing
		crypto := payments.Group("/crypto")
		crypto.Use(middleware.AuthMiddleware())
		{
			crypto.POST("/create-invoice", transactionService.CreateCryptoInvoice)
			crypto.GET("/invoice/:id/status", transactionService.GetCryptoInvoiceStatus)
			crypto.POST("/verify-payment", transactionService.VerifyCryptoPayment)
		}

		// CCBill integration
		ccbill := payments.Group("/ccbill")
		ccbill.Use(middleware.AuthMiddleware())
		{
			ccbill.POST("/create-transaction", transactionService.CreateCCBillTransaction)
			ccbill.GET("/transaction/:id/status", transactionService.GetCCBillTransactionStatus)
		}
	}

	// Webhook routes (no authentication required)
	webhooks := r.Group("/webhooks")
	{
		// Stripe webhooks
		webhooks.POST("/stripe", webhookService.HandleStripeWebhook)
		
		// Crypto payment webhooks
		webhooks.POST("/nowpayments", webhookService.HandleNowPaymentsWebhook)
		webhooks.POST("/triple-a", webhookService.HandleTripleAWebhook)
		
		// CCBill webhooks
		webhooks.POST("/ccbill", webhookService.HandleCCBillWebhook)
		
		// Banking/withdrawal webhooks
		webhooks.POST("/bankful", webhookService.HandleBankfulWebhook)
	}

	// Admin payment management routes
	admin := r.Group("/admin")
	admin.Use(middleware.AuthMiddleware())
	admin.Use(middleware.RequireRole("admin"))
	{
		admin.GET("/transactions", transactionService.GetAllTransactions)
		admin.GET("/transactions/flagged", transactionService.GetFlaggedTransactions)
		admin.PUT("/transactions/:id/review", transactionService.ReviewTransaction)
		
		admin.GET("/withdrawals/pending", withdrawalService.GetPendingWithdrawals)
		admin.PUT("/withdrawals/:id/approve", withdrawalService.ApproveWithdrawal)
		admin.PUT("/withdrawals/:id/reject", withdrawalService.RejectWithdrawal)
		
		admin.GET("/payment-analytics", transactionService.GetPlatformPaymentAnalytics)
		admin.GET("/revenue-analytics", transactionService.GetPlatformRevenueAnalytics)
		
		admin.GET("/payment-methods", paymentMethodService.GetAllPaymentMethods)
		admin.PUT("/payment-methods/:id/status", paymentMethodService.UpdatePaymentMethodStatus)
	}

	// Tax and compliance routes
	tax := r.Group("/tax")
	tax.Use(middleware.AuthMiddleware())
	tax.Use(middleware.RequireRole("creator", "admin"))
	{
		tax.GET("/forms", transactionService.GetTaxForms)
		tax.POST("/forms/1099", transactionService.Generate1099Form)
		tax.GET("/summary/:year", transactionService.GetTaxSummary)
		tax.GET("/export/:year", transactionService.ExportTaxData)
	}

	// Marketplace and pricing routes
	marketplace := r.Group("/marketplace")
	marketplace.Use(middleware.AuthMiddleware())
	{
		marketplace.GET("/pricing", transactionService.GetMarketplacePricing)
		marketplace.POST("/dynamic-pricing", middleware.RequireRole("creator", "admin"), transactionService.SetDynamicPricing)
		marketplace.GET("/discounts", transactionService.GetAvailableDiscounts)
		marketplace.POST("/apply-discount", transactionService.ApplyDiscount)
	}
}

// healthCheck returns the health status of the Payment Service
func healthCheck(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"status":    "healthy",
		"service":   "payment-service",
		"timestamp": time.Now().Unix(),
	})
}

// rootHandler returns service information
func rootHandler(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"name":        "Fanz OS Payment Service",
		"version":     "1.0.0",
		"description": "Payment processing, subscriptions, and financial transactions",
		"endpoints": gin.H{
			"health":        "/health",
			"methods":       "/methods",
			"subscriptions": "/subscriptions",
			"transactions":  "/transactions",
			"withdrawals":   "/withdrawals",
			"wallet":        "/wallet",
			"payments":      "/payments",
			"webhooks":      "/webhooks",
		},
	})
}