package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
)

func main() {
	// Set Gin mode
	if os.Getenv("GIN_MODE") == "release" {
		gin.SetMode(gin.ReleaseMode)
	}

	// Connect to database
	db, err := database.ConnectFromEnv()
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}
	defer db.Close()

	// Connect to Redis
	redisClient, err := cache.ConnectFromEnv()
	if err != nil {
		log.Printf("Warning: Failed to connect to Redis: %v", err)
		redisClient = nil
	}
	if redisClient != nil {
		defer redisClient.Close()
	}

	// Create services
	messageService := NewMessageService(db, redisClient)
	conversationService := NewConversationService(db, redisClient)
	groupChatService := NewGroupChatService(db, redisClient)
	notificationService := NewNotificationService(db, redisClient)

	// Create messaging hub for real-time features
	messagingHub := NewMessagingHub(db, redisClient)
	go messagingHub.Run()

	// Create Gin router
	r := gin.New()

	// Add middleware
	r.Use(gin.Recovery())
	r.Use(middleware.RequestLogger())
	r.Use(middleware.CORS(nil))

	// Add rate limiting if Redis is available
	if redisClient != nil {
		r.Use(middleware.RateLimit(redisClient, middleware.DefaultRateLimitConfig()))
	}

	// Setup routes
	setupRoutes(r, messageService, conversationService, groupChatService, notificationService, messagingHub)

	// Start server
	port := getEnv("PORT", "8005")
	server := &http.Server{
		Addr:         ":" + port,
		Handler:      r,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	// Start server in a goroutine
	go func() {
		log.Printf("🚀 Messaging Service starting on port %s", port)
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("Failed to start server: %v", err)
		}
	}()

	// Wait for interrupt signal to gracefully shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	log.Println("Shutting down Messaging Service...")

	// Graceful shutdown with timeout
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	if err := server.Shutdown(ctx); err != nil {
		log.Fatal("Messaging Service forced to shutdown:", err)
	}

	log.Println("Messaging Service exited")
}

// getEnv gets environment variable with default value
func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}