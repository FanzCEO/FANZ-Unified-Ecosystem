package main

import (
	"encoding/json"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
)

// MessagingHub manages all messaging WebSocket connections
type MessagingHub struct {
	// Database and cache connections
	db    *database.DB
	redis *cache.RedisClient
	
	// Connected clients by user ID
	clients map[string]*MessagingClient
	
	// Register requests from clients
	register chan *MessagingClient
	
	// Unregister requests from clients
	unregister chan *MessagingClient
	
	// Message broadcast channel
	broadcast chan *MessageBroadcast
	
	// Typing notifications channel
	typing chan *TypingNotification
	
	// Presence updates channel
	presence chan *PresenceUpdate
	
	// Mutex for thread-safe operations
	mutex sync.RWMutex
}

// MessagingClient represents a WebSocket client for messaging
type MessagingClient struct {
	// The WebSocket connection
	conn *websocket.Conn
	
	// User ID of the connected user
	userID string
	
	// Buffered channel of outbound messages
	send chan []byte
	
	// Hub reference
	hub *MessagingHub
	
	// Last activity timestamp
	lastActivity time.Time
}

// MessageBroadcast represents a message to broadcast to specific users
type MessageBroadcast struct {
	Recipients []string    `json:"recipients"`
	Type       string      `json:"type"`
	Data       interface{} `json:"data"`
	SenderID   string      `json:"sender_id,omitempty"`
}

// TypingNotification represents a typing indicator
type TypingNotification struct {
	UserID       string `json:"user_id"`
	ConversationID string `json:"conversation_id"`
	IsTyping     bool   `json:"is_typing"`
}

// PresenceUpdate represents a user presence update
type PresenceUpdate struct {
	UserID string `json:"user_id"`
	Status string `json:"status"` // online, offline, away
}

// WebSocket upgrader for messaging
var messagingUpgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		// Allow all origins in development
		// In production, implement proper origin checking
		return true
	},
}

// NewMessagingHub creates a new messaging hub
func NewMessagingHub(db *database.DB, redis *cache.RedisClient) *MessagingHub {
	return &MessagingHub{
		db:       db,
		redis:    redis,
		clients:  make(map[string]*MessagingClient),
		register: make(chan *MessagingClient),
		unregister: make(chan *MessagingClient),
		broadcast: make(chan *MessageBroadcast),
		typing:   make(chan *TypingNotification),
		presence: make(chan *PresenceUpdate),
	}
}

// Run starts the messaging hub
func (h *MessagingHub) Run() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case client := <-h.register:
			h.registerClient(client)
			
		case client := <-h.unregister:
			h.unregisterClient(client)
			
		case message := <-h.broadcast:
			h.broadcastMessage(message)
			
		case typing := <-h.typing:
			h.handleTypingNotification(typing)
			
		case presence := <-h.presence:
			h.handlePresenceUpdate(presence)
			
		case <-ticker.C:
			// Cleanup inactive clients
			h.cleanupInactiveClients()
		}
	}
}

// registerClient registers a new messaging client
func (h *MessagingHub) registerClient(client *MessagingClient) {
	h.mutex.Lock()
	defer h.mutex.Unlock()
	
	// Close existing connection if user is already connected
	if existingClient, exists := h.clients[client.userID]; exists {
		close(existingClient.send)
	}
	
	h.clients[client.userID] = client
	
	log.Printf("User %s connected to messaging", client.userID)
	
	// Update user presence to online
	h.updateUserPresence(client.userID, "online")
	
	// Send presence update to contacts
	h.notifyContactsOfPresenceChange(client.userID, "online")
}

// unregisterClient unregisters a messaging client
func (h *MessagingHub) unregisterClient(client *MessagingClient) {
	h.mutex.Lock()
	defer h.mutex.Unlock()
	
	if _, exists := h.clients[client.userID]; exists {
		delete(h.clients, client.userID)
		close(client.send)
		
		log.Printf("User %s disconnected from messaging", client.userID)
		
		// Update user presence to offline
		h.updateUserPresence(client.userID, "offline")
		
		// Send presence update to contacts
		h.notifyContactsOfPresenceChange(client.userID, "offline")
	}
}

// broadcastMessage broadcasts a message to specific recipients
func (h *MessagingHub) broadcastMessage(message *MessageBroadcast) {
	h.mutex.RLock()
	defer h.mutex.RUnlock()
	
	data, err := json.Marshal(map[string]interface{}{
		"type": message.Type,
		"data": message.Data,
		"sender_id": message.SenderID,
		"timestamp": time.Now().Unix(),
	})
	if err != nil {
		log.Printf("Error marshaling broadcast message: %v", err)
		return
	}
	
	for _, recipientID := range message.Recipients {
		if client, exists := h.clients[recipientID]; exists {
			select {
			case client.send <- data:
			default:
				// Client's send channel is full, remove it
				delete(h.clients, recipientID)
				close(client.send)
			}
		}
	}
}

// handleTypingNotification handles typing indicators
func (h *MessagingHub) handleTypingNotification(typing *TypingNotification) {
	// Get the other user in the conversation and send typing notification
	otherUserID, err := h.getOtherUserInConversation(typing.ConversationID, typing.UserID)
	if err != nil {
		return
	}
	
	h.mutex.RLock()
	client, exists := h.clients[otherUserID]
	h.mutex.RUnlock()
	
	if !exists {
		return
	}
	
	data, err := json.Marshal(map[string]interface{}{
		"type": "typing_indicator",
		"data": map[string]interface{}{
			"user_id":         typing.UserID,
			"conversation_id": typing.ConversationID,
			"is_typing":       typing.IsTyping,
		},
		"timestamp": time.Now().Unix(),
	})
	if err != nil {
		return
	}
	
	select {
	case client.send <- data:
	default:
		// Client channel full
	}
}

// handlePresenceUpdate handles user presence updates
func (h *MessagingHub) handlePresenceUpdate(presence *PresenceUpdate) {
	h.updateUserPresence(presence.UserID, presence.Status)
	h.notifyContactsOfPresenceChange(presence.UserID, presence.Status)
}

// HandleWebSocket handles WebSocket connections for messaging
func (h *MessagingHub) HandleWebSocket(c *gin.Context, userID string) {
	conn, err := messagingUpgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("WebSocket upgrade error: %v", err)
		return
	}
	
	client := &MessagingClient{
		conn:         conn,
		userID:       userID,
		send:         make(chan []byte, 256),
		hub:          h,
		lastActivity: time.Now(),
	}
	
	// Register the client
	h.register <- client
	
	// Start goroutines for reading and writing
	go client.writePump()
	go client.readPump()
}

// SendMessageToUser sends a message to a specific user
func (h *MessagingHub) SendMessageToUser(userID, messageType string, data interface{}) {
	message := &MessageBroadcast{
		Recipients: []string{userID},
		Type:       messageType,
		Data:       data,
	}
	
	select {
	case h.broadcast <- message:
	default:
		log.Printf("Broadcast channel full, dropping message")
	}
}

// SendMessageToUsers sends a message to multiple users
func (h *MessagingHub) SendMessageToUsers(userIDs []string, messageType string, data interface{}) {
	message := &MessageBroadcast{
		Recipients: userIDs,
		Type:       messageType,
		Data:       data,
	}
	
	select {
	case h.broadcast <- message:
	default:
		log.Printf("Broadcast channel full, dropping message")
	}
}

// IsUserOnline checks if a user is currently online
func (h *MessagingHub) IsUserOnline(userID string) bool {
	h.mutex.RLock()
	defer h.mutex.RUnlock()
	
	_, exists := h.clients[userID]
	return exists
}

// Helper functions

func (h *MessagingHub) updateUserPresence(userID, status string) {
	// Update presence in Redis for fast lookup
	if h.redis != nil {
		h.redis.Set("presence:"+userID, status, 5*time.Minute)
	}
	
	// Update last seen in database
	h.db.Exec(`
		UPDATE users SET last_seen = $1 WHERE id = $2
	`, time.Now(), userID)
}

func (h *MessagingHub) notifyContactsOfPresenceChange(userID, status string) {
	// Get user's contacts (people they've messaged with)
	rows, err := h.db.Query(`
		SELECT DISTINCT 
			CASE 
				WHEN user1_id = $1 THEN user2_id 
				ELSE user1_id 
			END as contact_id
		FROM conversations 
		WHERE user1_id = $1 OR user2_id = $1
	`, userID)
	if err != nil {
		return
	}
	defer rows.Close()
	
	var contactIDs []string
	for rows.Next() {
		var contactID string
		if rows.Scan(&contactID) == nil {
			contactIDs = append(contactIDs, contactID)
		}
	}
	
	// Send presence update to all contacts
	h.SendMessageToUsers(contactIDs, "presence_update", map[string]interface{}{
		"user_id": userID,
		"status":  status,
	})
}

func (h *MessagingHub) getOtherUserInConversation(conversationID, userID string) (string, error) {
	var otherUserID string
	err := h.db.QueryRow(`
		SELECT 
			CASE 
				WHEN user1_id = $1 THEN user2_id 
				ELSE user1_id 
			END as other_user_id
		FROM conversations 
		WHERE id = $2
	`, userID, conversationID).Scan(&otherUserID)
	
	return otherUserID, err
}

func (h *MessagingHub) cleanupInactiveClients() {
	h.mutex.Lock()
	defer h.mutex.Unlock()
	
	cutoff := time.Now().Add(-10 * time.Minute)
	
	for userID, client := range h.clients {
		if client.lastActivity.Before(cutoff) {
			delete(h.clients, userID)
			close(client.send)
			log.Printf("Cleaned up inactive client for user %s", userID)
		}
	}
}

// Client methods

// readPump pumps messages from the WebSocket connection to the hub
func (c *MessagingClient) readPump() {
	defer func() {
		c.hub.unregister <- c
		c.conn.Close()
	}()
	
	// Set read limits and deadlines
	c.conn.SetReadLimit(512)
	c.conn.SetPongHandler(func(string) error {
		c.lastActivity = time.Now()
		return nil
	})
	
	for {
		var message map[string]interface{}
		err := c.conn.ReadJSON(&message)
		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				log.Printf("WebSocket error: %v", err)
			}
			break
		}
		
		c.lastActivity = time.Now()
		c.handleMessage(message)
	}
}

// writePump pumps messages from the hub to the WebSocket connection
func (c *MessagingClient) writePump() {
	ticker := time.NewTicker(54 * time.Second)
	defer func() {
		ticker.Stop()
		c.conn.Close()
	}()
	
	for {
		select {
		case message, ok := <-c.send:
			if !ok {
				c.conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}
			
			if err := c.conn.WriteMessage(websocket.TextMessage, message); err != nil {
				return
			}
			
		case <-ticker.C:
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}

// handleMessage processes incoming WebSocket messages
func (c *MessagingClient) handleMessage(message map[string]interface{}) {
	messageType, ok := message["type"].(string)
	if !ok {
		return
	}
	
	switch messageType {
	case "typing_start":
		if conversationID, ok := message["conversation_id"].(string); ok {
			c.hub.typing <- &TypingNotification{
				UserID:         c.userID,
				ConversationID: conversationID,
				IsTyping:       true,
			}
		}
		
	case "typing_stop":
		if conversationID, ok := message["conversation_id"].(string); ok {
			c.hub.typing <- &TypingNotification{
				UserID:         c.userID,
				ConversationID: conversationID,
				IsTyping:       false,
			}
		}
		
	case "presence_update":
		if status, ok := message["status"].(string); ok {
			c.hub.presence <- &PresenceUpdate{
				UserID: c.userID,
				Status: status,
			}
		}
		
	case "ping":
		// Handle ping for connection keepalive
		c.sendMessage("pong", map[string]interface{}{
			"timestamp": message["timestamp"],
		})
		
	default:
		log.Printf("Unknown message type: %s", messageType)
	}
}

// sendMessage sends a message to the client
func (c *MessagingClient) sendMessage(messageType string, data interface{}) {
	message := map[string]interface{}{
		"type": messageType,
		"data": data,
		"timestamp": time.Now().Unix(),
	}
	
	jsonData, err := json.Marshal(message)
	if err != nil {
		log.Printf("Error marshaling message: %v", err)
		return
	}
	
	select {
	case c.send <- jsonData:
	default:
		close(c.send)
	}
}