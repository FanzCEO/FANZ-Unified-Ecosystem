package main

import (
	"database/sql"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// ConversationService handles conversation operations
type ConversationService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewConversationService creates a new conversation service instance
func NewConversationService(db *database.DB, redis *cache.RedisClient) *ConversationService {
	return &ConversationService{
		db:    db,
		redis: redis,
	}
}

// GetConversations gets user's conversations with pagination
func (s *ConversationService) GetConversations(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	// Get query parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))

	// Validate pagination
	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 50 {
		limit = 20
	}

	offset := (page - 1) * limit

	// Get conversations
	query := `
		SELECT c.id, c.user1_id, c.user2_id, c.last_message_id, c.last_message_at,
			   c.is_muted, c.created_at, c.updated_at,
			   m.content as last_message_content, m.message_type as last_message_type,
			   u.display_name, u.profile_image_url, u.is_verified
		FROM conversations c
		LEFT JOIN messages m ON c.last_message_id = m.id
		LEFT JOIN users u ON (
			CASE 
				WHEN c.user1_id = $1 THEN c.user2_id 
				ELSE c.user1_id 
			END = u.id
		)
		WHERE c.user1_id = $1 OR c.user2_id = $1
		ORDER BY c.last_message_at DESC NULLS LAST
		LIMIT $2 OFFSET $3
	`

	rows, err := s.db.Query(query, userID, limit, offset)
	if err != nil {
		utils.InternalServerError(c, "Failed to get conversations")
		return
	}
	defer rows.Close()

	var conversations []map[string]interface{}
	for rows.Next() {
		var conversation models.Conversation
		var lastMessageContent, lastMessageType, displayName, profileImageURL *string
		var isVerified *bool

		err := rows.Scan(
			&conversation.ID, &conversation.User1ID, &conversation.User2ID,
			&conversation.LastMessageID, &conversation.LastMessageAt,
			&conversation.IsMuted, &conversation.CreatedAt, &conversation.UpdatedAt,
			&lastMessageContent, &lastMessageType, &displayName, &profileImageURL, &isVerified,
		)
		if err != nil {
			continue
		}

		// Determine the other user ID
		otherUserID := conversation.User2ID
		if conversation.User1ID != userID {
			otherUserID = conversation.User1ID
		}

		// Get unread count for this conversation
		unreadCount, _ := s.getUnreadCount(userID, conversation.ID)

		conversationData := map[string]interface{}{
			"id":                   conversation.ID,
			"other_user_id":        otherUserID,
			"other_user_name":      displayName,
			"other_user_avatar":    profileImageURL,
			"other_user_verified":  isVerified,
			"last_message_content": lastMessageContent,
			"last_message_type":    lastMessageType,
			"last_message_at":      conversation.LastMessageAt,
			"unread_count":         unreadCount,
			"is_muted":             conversation.IsMuted,
			"created_at":           conversation.CreatedAt,
			"updated_at":           conversation.UpdatedAt,
		}

		conversations = append(conversations, conversationData)
	}

	// Get total count
	var total int
	err = s.db.QueryRow(`
		SELECT COUNT(*) FROM conversations 
		WHERE user1_id = $1 OR user2_id = $1
	`, userID).Scan(&total)
	if err != nil {
		utils.InternalServerError(c, "Failed to count conversations")
		return
	}

	// Calculate pagination metadata
	totalPages := (total + limit - 1) / limit
	meta := &utils.Meta{
		Page:       page,
		Limit:      limit,
		Total:      total,
		TotalPages: totalPages,
	}

	utils.SuccessResponseWithMeta(c, conversations, meta)
}

// GetConversation gets a specific conversation with messages
func (s *ConversationService) GetConversation(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	otherUserID := c.Param("userId")
	if otherUserID == "" {
		utils.BadRequestError(c, "User ID is required")
		return
	}

	// Get or create conversation
	conversationID, err := s.getOrCreateConversationID(userID, otherUserID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get conversation")
		return
	}

	// Get pagination parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "50"))

	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 50
	}

	offset := (page - 1) * limit

	// Get messages in conversation
	query := `
		SELECT id, sender_id, recipient_id, conversation_id, content, 
			   media_url, media_type, message_type, ppv_price, is_read,
			   created_at, read_at
		FROM messages 
		WHERE conversation_id = $1 AND is_deleted = false
		ORDER BY created_at DESC
		LIMIT $2 OFFSET $3
	`

	rows, err := s.db.Query(query, conversationID, limit, offset)
	if err != nil {
		utils.InternalServerError(c, "Failed to get conversation messages")
		return
	}
	defer rows.Close()

	var messages []models.Message
	for rows.Next() {
		var message models.Message
		err := rows.Scan(
			&message.ID, &message.SenderID, &message.RecipientID,
			&message.ConversationID, &message.Content, &message.MediaURL,
			&message.MediaType, &message.MessageType, &message.PPVPrice,
			&message.IsRead, &message.CreatedAt, &message.ReadAt,
		)
		if err != nil {
			continue
		}

		// Check PPV access for messages not sent by current user
		if message.MessageType == models.MessageTypePPV && message.SenderID != userID {
			hasAccess, _ := s.hasAccessToPPVMessage(userID, message.ID)
			if !hasAccess {
				message.Content = "This message is locked. Unlock to view."
				message.MediaURL = nil
			}
		}

		messages = append(messages, message)
	}

	// Get conversation info
	conversation, err := s.getConversationByID(conversationID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get conversation info")
		return
	}

	// Get other user info
	otherUser, err := s.getUserByID(otherUserID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get other user info")
		return
	}

	response := map[string]interface{}{
		"conversation": conversation,
		"other_user":   otherUser,
		"messages":     messages,
	}

	utils.SuccessResponse(c, response)
}

// StartConversation starts a new conversation
func (s *ConversationService) StartConversation(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	otherUserID := c.Param("userId")
	if otherUserID == "" {
		utils.BadRequestError(c, "User ID is required")
		return
	}

	if userID == otherUserID {
		utils.BadRequestError(c, "Cannot start conversation with yourself")
		return
	}

	// Check if users can message each other
	canMessage, err := s.canUsersMessage(userID, otherUserID)
	if err != nil {
		utils.InternalServerError(c, "Failed to check messaging permissions")
		return
	}
	if !canMessage {
		utils.ForbiddenError(c, "You cannot start a conversation with this user")
		return
	}

	// Get or create conversation
	conversationID, err := s.getOrCreateConversationID(userID, otherUserID)
	if err != nil {
		utils.InternalServerError(c, "Failed to create conversation")
		return
	}

	conversation, err := s.getConversationByID(conversationID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get conversation")
		return
	}

	utils.SuccessResponse(c, conversation)
}

// MarkConversationAsRead marks all messages in a conversation as read
func (s *ConversationService) MarkConversationAsRead(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	otherUserID := c.Param("userId")
	if otherUserID == "" {
		utils.BadRequestError(c, "User ID is required")
		return
	}

	// Get conversation ID
	conversationID, err := s.getOrCreateConversationID(userID, otherUserID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get conversation")
		return
	}

	// Mark all unread messages as read
	_, err = s.db.Exec(`
		UPDATE messages 
		SET is_read = true, read_at = $1 
		WHERE conversation_id = $2 AND recipient_id = $3 AND is_read = false
	`, time.Now(), conversationID, userID)

	if err != nil {
		utils.InternalServerError(c, "Failed to mark conversation as read")
		return
	}

	utils.SuccessResponse(c, gin.H{"message": "Conversation marked as read"})
}

// Helper functions

func (s *ConversationService) getOrCreateConversationID(user1ID, user2ID string) (string, error) {
	// Try to find existing conversation
	var conversationID string
	err := s.db.QueryRow(`
		SELECT id FROM conversations 
		WHERE (user1_id = $1 AND user2_id = $2) 
		OR (user1_id = $2 AND user2_id = $1)
	`, user1ID, user2ID).Scan(&conversationID)

	if err == sql.ErrNoRows {
		// Create new conversation
		conversationID = uuid.New().String()
		_, err = s.db.Exec(`
			INSERT INTO conversations (id, user1_id, user2_id, created_at, updated_at)
			VALUES ($1, $2, $3, $4, $5)
		`, conversationID, user1ID, user2ID, time.Now(), time.Now())
		return conversationID, err
	}

	return conversationID, err
}

func (s *ConversationService) getConversationByID(conversationID string) (*models.Conversation, error) {
	var conversation models.Conversation
	err := s.db.QueryRow(`
		SELECT id, user1_id, user2_id, last_message_id, last_message_at,
			   is_muted, created_at, updated_at
		FROM conversations WHERE id = $1
	`, conversationID).Scan(
		&conversation.ID, &conversation.User1ID, &conversation.User2ID,
		&conversation.LastMessageID, &conversation.LastMessageAt,
		&conversation.IsMuted, &conversation.CreatedAt, &conversation.UpdatedAt,
	)
	return &conversation, err
}

func (s *ConversationService) getUserByID(userID string) (map[string]interface{}, error) {
	var user map[string]interface{}
	var displayName, profileImageURL *string
	var isVerified bool

	err := s.db.QueryRow(`
		SELECT display_name, profile_image_url, is_verified
		FROM users WHERE id = $1
	`, userID).Scan(&displayName, &profileImageURL, &isVerified)

	if err != nil {
		return nil, err
	}

	user = map[string]interface{}{
		"id":           userID,
		"display_name": displayName,
		"avatar":       profileImageURL,
		"is_verified":  isVerified,
	}

	return user, nil
}

func (s *ConversationService) getUnreadCount(userID, conversationID string) (int, error) {
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM messages 
		WHERE conversation_id = $1 AND recipient_id = $2 AND is_read = false AND is_deleted = false
	`, conversationID, userID).Scan(&count)
	return count, err
}

func (s *ConversationService) canUsersMessage(senderID, recipientID string) (bool, error) {
	// Check if users are blocked
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM blocked_users 
		WHERE (blocker_id = $1 AND blocked_id = $2) 
		OR (blocker_id = $2 AND blocked_id = $1)
	`, senderID, recipientID).Scan(&count)
	
	return count == 0, err
}

func (s *ConversationService) hasAccessToPPVMessage(userID, messageID string) (bool, error) {
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM ppv_unlocks 
		WHERE user_id = $1 AND message_id = $2
	`, userID, messageID).Scan(&count)
	return count > 0, err
}

// Placeholder implementations for remaining methods
func (s *ConversationService) DeleteConversation(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Delete conversation not yet implemented")
}

func (s *ConversationService) MuteConversation(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Mute conversation not yet implemented")
}

func (s *ConversationService) UnmuteConversation(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Unmute conversation not yet implemented")
}

func (s *ConversationService) BlockUser(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Block user not yet implemented")
}

func (s *ConversationService) UnblockUser(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Unblock user not yet implemented")
}

func (s *ConversationService) GetConversationMedia(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get conversation media not yet implemented")
}

func (s *ConversationService) SearchConversations(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Search conversations not yet implemented")
}

func (s *ConversationService) SearchUsers(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Search users not yet implemented")
}

func (s *ConversationService) GetAllConversations(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get all conversations not yet implemented")
}