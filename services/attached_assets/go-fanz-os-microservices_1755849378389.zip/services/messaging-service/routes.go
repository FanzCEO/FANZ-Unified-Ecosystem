package main

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/utils"
)

// setupRoutes configures all Messaging Service routes
func setupRoutes(
	r *gin.Engine,
	messageService *MessageService,
	conversationService *ConversationService,
	groupChatService *GroupChatService,
	notificationService *NotificationService,
	messagingHub *MessagingHub,
) {
	// Health check
	r.GET("/health", healthCheck)
	r.GET("/", rootHandler)

	// All messaging routes require authentication
	r.Use(middleware.AuthMiddleware())

	// Conversation routes
	conversations := r.Group("/conversations")
	{
		conversations.GET("", conversationService.GetConversations)
		conversations.GET("/:userId", conversationService.GetConversation)
		conversations.POST("/:userId/start", conversationService.StartConversation)
		conversations.DELETE("/:userId", conversationService.DeleteConversation)
		conversations.PUT("/:userId/mute", conversationService.MuteConversation)
		conversations.PUT("/:userId/unmute", conversationService.UnmuteConversation)
		conversations.PUT("/:userId/block", conversationService.BlockUser)
		conversations.PUT("/:userId/unblock", conversationService.UnblockUser)
		conversations.GET("/:userId/media", conversationService.GetConversationMedia)
		conversations.PUT("/:userId/read", conversationService.MarkConversationAsRead)
	}

	// Message routes
	messages := r.Group("/messages")
	{
		messages.POST("/send", messageService.SendMessage)
		messages.GET("/:id", messageService.GetMessage)
		messages.PUT("/:id/read", messageService.MarkMessageAsRead)
		messages.DELETE("/:id", messageService.DeleteMessage)
		messages.PUT("/:id/edit", messageService.EditMessage)
		messages.POST("/:id/react", messageService.ReactToMessage)
		messages.DELETE("/:id/react", messageService.RemoveReaction)
		messages.POST("/:id/report", messageService.ReportMessage)
		messages.POST("/:id/forward", messageService.ForwardMessage)
		
		// PPV message routes
		messages.POST("/:id/unlock", messageService.UnlockPPVMessage)
		messages.GET("/:id/ppv-status", messageService.GetPPVMessageStatus)
	}

	// Group chat routes
	groups := r.Group("/groups")
	{
		groups.POST("", groupChatService.CreateGroup)
		groups.GET("", groupChatService.GetUserGroups)
		groups.GET("/:id", groupChatService.GetGroup)
		groups.PUT("/:id", groupChatService.UpdateGroup)
		groups.DELETE("/:id", groupChatService.DeleteGroup)
		groups.POST("/:id/join", groupChatService.JoinGroup)
		groups.POST("/:id/leave", groupChatService.LeaveGroup)
		groups.GET("/:id/members", groupChatService.GetGroupMembers)
		groups.POST("/:id/invite", groupChatService.InviteToGroup)
		groups.DELETE("/:id/members/:userId", groupChatService.RemoveFromGroup)
		groups.PUT("/:id/members/:userId/role", groupChatService.UpdateMemberRole)
		groups.GET("/:id/messages", groupChatService.GetGroupMessages)
		groups.POST("/:id/messages", groupChatService.SendGroupMessage)
		groups.PUT("/:id/settings", groupChatService.UpdateGroupSettings)
	}

	// Media and file sharing routes
	media := r.Group("/media")
	{
		media.POST("/upload", messageService.UploadMessageMedia)
		media.GET("/:id", messageService.GetMediaFile)
		media.DELETE("/:id", messageService.DeleteMediaFile)
		media.POST("/voice-note", messageService.SendVoiceNote)
		media.POST("/location", messageService.ShareLocation)
		media.POST("/contact", messageService.ShareContact)
	}

	// Real-time messaging WebSocket
	realtime := r.Group("/realtime")
	{
		realtime.GET("/ws", func(c *gin.Context) {
			userID, _, err := middleware.GetUserFromContext(c)
			if err != nil {
				utils.UnauthorizedError(c, "Authentication required")
				return
			}
			
			messagingHub.HandleWebSocket(c, userID)
		})
		
		// Typing indicators
		realtime.POST("/typing/:userId/start", messageService.StartTyping)
		realtime.POST("/typing/:userId/stop", messageService.StopTyping)
		
		// Online presence
		realtime.POST("/presence/online", messageService.SetOnline)
		realtime.POST("/presence/offline", messageService.SetOffline)
		realtime.GET("/presence/:userId", messageService.GetUserPresence)
	}

	// Notification routes
	notifications := r.Group("/notifications")
	{
		notifications.GET("/settings", notificationService.GetNotificationSettings)
		notifications.PUT("/settings", notificationService.UpdateNotificationSettings)
		notifications.POST("/push/register", notificationService.RegisterPushToken)
		notifications.DELETE("/push/unregister", notificationService.UnregisterPushToken)
		notifications.GET("/unread-count", notificationService.GetUnreadCount)
		notifications.PUT("/mark-all-read", notificationService.MarkAllAsRead)
	}

	// Search and discovery routes
	search := r.Group("/search")
	{
		search.GET("/messages", messageService.SearchMessages)
		search.GET("/conversations", conversationService.SearchConversations)
		search.GET("/users", conversationService.SearchUsers)
		search.GET("/groups", groupChatService.SearchGroups)
	}

	// Creator-specific messaging features
	creator := r.Group("/creator")
	creator.Use(middleware.RequireRole("creator", "admin"))
	{
		creator.GET("/inbox", messageService.GetCreatorInbox)
		creator.POST("/broadcast", messageService.BroadcastMessage)
		creator.GET("/mass-messages", messageService.GetMassMessages)
		creator.POST("/auto-reply", messageService.SetAutoReply)
		creator.GET("/auto-reply", messageService.GetAutoReply)
		creator.DELETE("/auto-reply", messageService.DisableAutoReply)
		creator.GET("/message-analytics", messageService.GetMessageAnalytics)
		creator.GET("/fan-engagement", messageService.GetFanEngagementStats)
		creator.POST("/ppv-campaign", messageService.CreatePPVCampaign)
		creator.GET("/ppv-campaigns", messageService.GetPPVCampaigns)
	}

	// Moderation and safety routes
	moderation := r.Group("/moderation")
	{
		moderation.GET("/reported-messages", middleware.RequireRole("admin"), messageService.GetReportedMessages)
		moderation.PUT("/messages/:id/moderate", middleware.RequireRole("admin"), messageService.ModerateMessage)
		moderation.GET("/spam-detection", messageService.GetSpamDetectionSettings)
		moderation.PUT("/spam-detection", messageService.UpdateSpamDetectionSettings)
		moderation.POST("/block-keywords", messageService.AddBlockedKeyword)
		moderation.DELETE("/block-keywords/:id", messageService.RemoveBlockedKeyword)
		moderation.GET("/block-keywords", messageService.GetBlockedKeywords)
	}

	// Message templates and quick replies
	templates := r.Group("/templates")
	{
		templates.GET("", messageService.GetMessageTemplates)
		templates.POST("", messageService.CreateMessageTemplate)
		templates.PUT("/:id", messageService.UpdateMessageTemplate)
		templates.DELETE("/:id", messageService.DeleteMessageTemplate)
		templates.POST("/:id/use", messageService.UseMessageTemplate)
	}

	// Analytics routes
	analytics := r.Group("/analytics")
	analytics.Use(middleware.RequireRole("creator", "admin"))
	{
		analytics.GET("/messaging-stats", messageService.GetMessagingStats)
		analytics.GET("/response-times", messageService.GetResponseTimeStats)
		analytics.GET("/engagement-metrics", messageService.GetEngagementMetrics)
		analytics.GET("/revenue-by-messages", messageService.GetMessageRevenueStats)
		analytics.GET("/fan-activity", messageService.GetFanActivityStats)
	}

	// Admin messaging management
	admin := r.Group("/admin")
	admin.Use(middleware.RequireRole("admin"))
	{
		admin.GET("/conversations", conversationService.GetAllConversations)
		admin.GET("/messages/flagged", messageService.GetFlaggedMessages)
		admin.PUT("/users/:id/messaging-restrictions", messageService.SetMessagingRestrictions)
		admin.GET("/platform-messaging-stats", messageService.GetPlatformMessagingStats)
		admin.GET("/spam-reports", messageService.GetSpamReports)
		admin.PUT("/spam-reports/:id/resolve", messageService.ResolveSpamReport)
	}

	// Backup and data export
	backup := r.Group("/backup")
	{
		backup.POST("/export", messageService.ExportUserMessages)
		backup.GET("/export/:id/status", messageService.GetExportStatus)
		backup.GET("/export/:id/download", messageService.DownloadExport)
		backup.DELETE("/export/:id", messageService.DeleteExport)
	}
}

// healthCheck returns the health status of the Messaging Service
func healthCheck(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"status":    "healthy",
		"service":   "messaging-service",
		"timestamp": time.Now().Unix(),
	})
}

// rootHandler returns service information
func rootHandler(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"name":        "Fanz OS Messaging Service",
		"version":     "1.0.0",
		"description": "Real-time messaging, chat, and communication platform",
		"endpoints": gin.H{
			"health":        "/health",
			"conversations": "/conversations",
			"messages":      "/messages",
			"groups":        "/groups",
			"media":         "/media",
			"realtime":      "/realtime",
			"notifications": "/notifications",
			"search":        "/search",
			"creator":       "/creator",
		},
	})
}