package main

import (
	"database/sql"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/shopspring/decimal"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// MessageService handles messaging operations
type MessageService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewMessageService creates a new message service instance
func NewMessageService(db *database.DB, redis *cache.RedisClient) *MessageService {
	return &MessageService{
		db:    db,
		redis: redis,
	}
}

// SendMessage sends a message to another user
func (s *MessageService) SendMessage(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	var req models.CreateMessageRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Validate required fields
	if req.RecipientID == "" {
		utils.BadRequestError(c, "Recipient ID is required")
		return
	}

	if userID == req.RecipientID {
		utils.BadRequestError(c, "Cannot send message to yourself")
		return
	}

	if strings.TrimSpace(req.Content) == "" && req.MediaURL == "" {
		utils.BadRequestError(c, "Message content or media is required")
		return
	}

	// Check if users can message each other
	canMessage, err := s.canUsersMessage(userID, req.RecipientID)
	if err != nil {
		utils.InternalServerError(c, "Failed to check messaging permissions")
		return
	}
	if !canMessage {
		utils.ForbiddenError(c, "You cannot send messages to this user")
		return
	}

	// Validate PPV price if message type is PPV
	if req.MessageType == models.MessageTypePPV && (req.PPVPrice == nil || req.PPVPrice.LessThanOrEqual(decimal.Zero)) {
		utils.BadRequestError(c, "PPV price must be greater than 0 for PPV messages")
		return
	}

	// Create message
	messageID := uuid.New().String()
	now := time.Now()

	query := `
		INSERT INTO messages (
			id, sender_id, recipient_id, conversation_id, content, media_url,
			media_type, message_type, ppv_price, created_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
	`

	// Get or create conversation ID
	conversationID, err := s.getOrCreateConversationID(userID, req.RecipientID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get conversation")
		return
	}

	_, err = s.db.Exec(query,
		messageID, userID, req.RecipientID, conversationID, req.Content,
		req.MediaURL, req.MediaType, req.MessageType, req.PPVPrice, now,
	)

	if err != nil {
		utils.InternalServerError(c, "Failed to send message")
		return
	}

	// Update conversation last message
	s.updateConversationLastMessage(conversationID, messageID, now)

	// Get created message
	message, err := s.getMessageByID(messageID)
	if err != nil {
		utils.InternalServerError(c, "Failed to retrieve sent message")
		return
	}

	// TODO: Send real-time notification via WebSocket
	// TODO: Send push notification

	utils.CreatedResponse(c, message)
}

// GetMessage gets a specific message by ID
func (s *MessageService) GetMessage(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	messageID := c.Param("id")
	if messageID == "" {
		utils.BadRequestError(c, "Message ID is required")
		return
	}

	message, err := s.getMessageByID(messageID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Message not found")
		} else {
			utils.InternalServerError(c, "Failed to get message")
		}
		return
	}

	// Check if user has access to this message
	if message.SenderID != userID && message.RecipientID != userID {
		utils.ForbiddenError(c, "You don't have access to this message")
		return
	}

	// Check if PPV message is unlocked
	if message.MessageType == models.MessageTypePPV && message.SenderID != userID {
		hasAccess, err := s.hasAccessToPPVMessage(userID, messageID)
		if err != nil {
			utils.InternalServerError(c, "Failed to check message access")
			return
		}
		if !hasAccess {
			// Return limited message info for locked PPV content
			message.Content = "This message is locked. Unlock to view."
			message.MediaURL = nil
		}
	}

	utils.SuccessResponse(c, message)
}

// MarkMessageAsRead marks a message as read
func (s *MessageService) MarkMessageAsRead(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	messageID := c.Param("id")
	if messageID == "" {
		utils.BadRequestError(c, "Message ID is required")
		return
	}

	// Verify message exists and user is the recipient
	message, err := s.getMessageByID(messageID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Message not found")
		} else {
			utils.InternalServerError(c, "Failed to get message")
		}
		return
	}

	if message.RecipientID != userID {
		utils.ForbiddenError(c, "You can only mark messages sent to you as read")
		return
	}

	// Mark message as read
	_, err = s.db.Exec(`
		UPDATE messages SET is_read = true, read_at = $1 
		WHERE id = $2 AND is_read = false
	`, time.Now(), messageID)

	if err != nil {
		utils.InternalServerError(c, "Failed to mark message as read")
		return
	}

	utils.SuccessResponse(c, gin.H{"message": "Message marked as read"})
}

// DeleteMessage deletes a message
func (s *MessageService) DeleteMessage(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	messageID := c.Param("id")
	if messageID == "" {
		utils.BadRequestError(c, "Message ID is required")
		return
	}

	// Verify message exists and user is the sender
	message, err := s.getMessageByID(messageID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Message not found")
		} else {
			utils.InternalServerError(c, "Failed to get message")
		}
		return
	}

	if message.SenderID != userID {
		utils.ForbiddenError(c, "You can only delete your own messages")
		return
	}

	// Soft delete the message
	_, err = s.db.Exec(`
		UPDATE messages SET is_deleted = true, deleted_at = $1 
		WHERE id = $2
	`, time.Now(), messageID)

	if err != nil {
		utils.InternalServerError(c, "Failed to delete message")
		return
	}

	utils.SuccessResponse(c, gin.H{"message": "Message deleted successfully"})
}

// UnlockPPVMessage unlocks a PPV message
func (s *MessageService) UnlockPPVMessage(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	messageID := c.Param("id")
	if messageID == "" {
		utils.BadRequestError(c, "Message ID is required")
		return
	}

	// Get message
	message, err := s.getMessageByID(messageID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Message not found")
		} else {
			utils.InternalServerError(c, "Failed to get message")
		}
		return
	}

	if message.MessageType != models.MessageTypePPV {
		utils.BadRequestError(c, "This message is not pay-per-view")
		return
	}

	if message.SenderID == userID {
		utils.BadRequestError(c, "You cannot unlock your own message")
		return
	}

	if message.RecipientID != userID {
		utils.ForbiddenError(c, "You can only unlock messages sent to you")
		return
	}

	// Check if already unlocked
	hasAccess, err := s.hasAccessToPPVMessage(userID, messageID)
	if err != nil {
		utils.InternalServerError(c, "Failed to check access")
		return
	}
	if hasAccess {
		utils.ConflictError(c, "Message already unlocked")
		return
	}

	// Create PPV unlock record
	unlockID := uuid.New().String()
	_, err = s.db.Exec(`
		INSERT INTO ppv_unlocks (id, user_id, message_id, price, created_at)
		VALUES ($1, $2, $3, $4, $5)
	`, unlockID, userID, messageID, message.PPVPrice, time.Now())

	if err != nil {
		utils.InternalServerError(c, "Failed to unlock message")
		return
	}

	utils.SuccessResponse(c, gin.H{
		"message":   "Message unlocked successfully",
		"unlock_id": unlockID,
	})
}

// SearchMessages searches user's messages
func (s *MessageService) SearchMessages(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	query := c.Query("q")
	if query == "" {
		utils.BadRequestError(c, "Search query is required")
		return
	}

	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))

	// Validate pagination
	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 50 {
		limit = 20
	}

	offset := (page - 1) * limit

	// Search messages
	searchQuery := `
		SELECT id, sender_id, recipient_id, conversation_id, content, 
			   media_url, media_type, message_type, ppv_price, is_read,
			   created_at, read_at
		FROM messages 
		WHERE (sender_id = $1 OR recipient_id = $1) 
		AND is_deleted = false
		AND content ILIKE $2
		ORDER BY created_at DESC
		LIMIT $3 OFFSET $4
	`

	rows, err := s.db.Query(searchQuery, userID, "%"+query+"%", limit, offset)
	if err != nil {
		utils.InternalServerError(c, "Failed to search messages")
		return
	}
	defer rows.Close()

	var messages []models.Message
	for rows.Next() {
		var message models.Message
		err := rows.Scan(
			&message.ID, &message.SenderID, &message.RecipientID,
			&message.ConversationID, &message.Content, &message.MediaURL,
			&message.MediaType, &message.MessageType, &message.PPVPrice,
			&message.IsRead, &message.CreatedAt, &message.ReadAt,
		)
		if err != nil {
			continue
		}
		messages = append(messages, message)
	}

	utils.SuccessResponse(c, messages)
}

// Helper functions

func (s *MessageService) getMessageByID(messageID string) (*models.Message, error) {
	var message models.Message
	err := s.db.QueryRow(`
		SELECT id, sender_id, recipient_id, conversation_id, content, 
			   media_url, media_type, message_type, ppv_price, is_read,
			   created_at, read_at
		FROM messages WHERE id = $1 AND is_deleted = false
	`, messageID).Scan(
		&message.ID, &message.SenderID, &message.RecipientID,
		&message.ConversationID, &message.Content, &message.MediaURL,
		&message.MediaType, &message.MessageType, &message.PPVPrice,
		&message.IsRead, &message.CreatedAt, &message.ReadAt,
	)
	return &message, err
}

func (s *MessageService) canUsersMessage(senderID, recipientID string) (bool, error) {
	// Check if users are blocked
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM blocked_users 
		WHERE (blocker_id = $1 AND blocked_id = $2) 
		OR (blocker_id = $2 AND blocked_id = $1)
	`, senderID, recipientID).Scan(&count)
	
	return count == 0, err
}

func (s *MessageService) getOrCreateConversationID(user1ID, user2ID string) (string, error) {
	// Try to find existing conversation
	var conversationID string
	err := s.db.QueryRow(`
		SELECT id FROM conversations 
		WHERE (user1_id = $1 AND user2_id = $2) 
		OR (user1_id = $2 AND user2_id = $1)
	`, user1ID, user2ID).Scan(&conversationID)

	if err == sql.ErrNoRows {
		// Create new conversation
		conversationID = uuid.New().String()
		_, err = s.db.Exec(`
			INSERT INTO conversations (id, user1_id, user2_id, created_at)
			VALUES ($1, $2, $3, $4)
		`, conversationID, user1ID, user2ID, time.Now())
		return conversationID, err
	}

	return conversationID, err
}

func (s *MessageService) updateConversationLastMessage(conversationID, messageID string, timestamp time.Time) {
	s.db.Exec(`
		UPDATE conversations 
		SET last_message_id = $1, last_message_at = $2, updated_at = $3
		WHERE id = $4
	`, messageID, timestamp, timestamp, conversationID)
}

func (s *MessageService) hasAccessToPPVMessage(userID, messageID string) (bool, error) {
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM ppv_unlocks 
		WHERE user_id = $1 AND message_id = $2
	`, userID, messageID).Scan(&count)
	return count > 0, err
}

// Placeholder implementations for remaining methods
func (s *MessageService) EditMessage(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Edit message not yet implemented")
}

func (s *MessageService) ReactToMessage(c *gin.Context) {
	utils.ServiceUnavailableError(c, "React to message not yet implemented")
}

func (s *MessageService) RemoveReaction(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Remove reaction not yet implemented")
}

func (s *MessageService) ReportMessage(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Report message not yet implemented")
}

func (s *MessageService) ForwardMessage(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Forward message not yet implemented")
}

func (s *MessageService) GetPPVMessageStatus(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get PPV message status not yet implemented")
}

func (s *MessageService) UploadMessageMedia(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Upload message media not yet implemented")
}

func (s *MessageService) GetMediaFile(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get media file not yet implemented")
}

func (s *MessageService) DeleteMediaFile(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Delete media file not yet implemented")
}

func (s *MessageService) SendVoiceNote(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Send voice note not yet implemented")
}

func (s *MessageService) ShareLocation(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Share location not yet implemented")
}

func (s *MessageService) ShareContact(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Share contact not yet implemented")
}

func (s *MessageService) StartTyping(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Start typing not yet implemented")
}

func (s *MessageService) StopTyping(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Stop typing not yet implemented")
}

func (s *MessageService) SetOnline(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Set online not yet implemented")
}

func (s *MessageService) SetOffline(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Set offline not yet implemented")
}

func (s *MessageService) GetUserPresence(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get user presence not yet implemented")
}

func (s *MessageService) GetCreatorInbox(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get creator inbox not yet implemented")
}

func (s *MessageService) BroadcastMessage(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Broadcast message not yet implemented")
}

func (s *MessageService) GetMassMessages(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get mass messages not yet implemented")
}

func (s *MessageService) SetAutoReply(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Set auto reply not yet implemented")
}

func (s *MessageService) GetAutoReply(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get auto reply not yet implemented")
}

func (s *MessageService) DisableAutoReply(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Disable auto reply not yet implemented")
}

func (s *MessageService) GetMessageAnalytics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get message analytics not yet implemented")
}

func (s *MessageService) GetFanEngagementStats(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get fan engagement stats not yet implemented")
}

func (s *MessageService) CreatePPVCampaign(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Create PPV campaign not yet implemented")
}

func (s *MessageService) GetPPVCampaigns(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get PPV campaigns not yet implemented")
}

func (s *MessageService) GetReportedMessages(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get reported messages not yet implemented")
}

func (s *MessageService) ModerateMessage(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Moderate message not yet implemented")
}

func (s *MessageService) GetSpamDetectionSettings(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get spam detection settings not yet implemented")
}

func (s *MessageService) UpdateSpamDetectionSettings(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Update spam detection settings not yet implemented")
}

func (s *MessageService) AddBlockedKeyword(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Add blocked keyword not yet implemented")
}

func (s *MessageService) RemoveBlockedKeyword(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Remove blocked keyword not yet implemented")
}

func (s *MessageService) GetBlockedKeywords(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get blocked keywords not yet implemented")
}

func (s *MessageService) GetMessageTemplates(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get message templates not yet implemented")
}

func (s *MessageService) CreateMessageTemplate(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Create message template not yet implemented")
}

func (s *MessageService) UpdateMessageTemplate(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Update message template not yet implemented")
}

func (s *MessageService) DeleteMessageTemplate(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Delete message template not yet implemented")
}

func (s *MessageService) UseMessageTemplate(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Use message template not yet implemented")
}

func (s *MessageService) GetMessagingStats(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get messaging stats not yet implemented")
}

func (s *MessageService) GetResponseTimeStats(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get response time stats not yet implemented")
}

func (s *MessageService) GetEngagementMetrics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get engagement metrics not yet implemented")
}

func (s *MessageService) GetMessageRevenueStats(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get message revenue stats not yet implemented")
}

func (s *MessageService) GetFanActivityStats(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get fan activity stats not yet implemented")
}

func (s *MessageService) GetFlaggedMessages(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get flagged messages not yet implemented")
}

func (s *MessageService) SetMessagingRestrictions(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Set messaging restrictions not yet implemented")
}

func (s *MessageService) GetPlatformMessagingStats(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get platform messaging stats not yet implemented")
}

func (s *MessageService) GetSpamReports(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get spam reports not yet implemented")
}

func (s *MessageService) ResolveSpamReport(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Resolve spam report not yet implemented")
}

func (s *MessageService) ExportUserMessages(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Export user messages not yet implemented")
}

func (s *MessageService) GetExportStatus(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get export status not yet implemented")
}

func (s *MessageService) DownloadExport(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Download export not yet implemented")
}

func (s *MessageService) DeleteExport(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Delete export not yet implemented")
}