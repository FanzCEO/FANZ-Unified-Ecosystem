package main

import (
	"database/sql"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// InteractionService handles content interactions (likes, comments, etc.)
type InteractionService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewInteractionService creates a new interaction service instance
func NewInteractionService(db *database.DB, redis *cache.RedisClient) *InteractionService {
	return &InteractionService{
		db:    db,
		redis: redis,
	}
}

// LikePost likes a post
func (s *InteractionService) LikePost(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	postID := c.Param("id")
	if postID == "" {
		utils.BadRequestError(c, "Post ID is required")
		return
	}

	// Check if already liked
	exists, err := s.isPostLiked(userID, postID)
	if err != nil {
		utils.InternalServerError(c, "Failed to check like status")
		return
	}
	if exists {
		utils.ConflictError(c, "Post already liked")
		return
	}

	// Create like
	likeID := uuid.New().String()
	_, err = s.db.Exec(`
		INSERT INTO likes (id, user_id, post_id, created_at)
		VALUES ($1, $2, $3, $4)
	`, likeID, userID, postID, time.Now())

	if err != nil {
		utils.InternalServerError(c, "Failed to like post")
		return
	}

	// Update post likes count
	s.db.Exec(`
		UPDATE posts SET likes_count = likes_count + 1 
		WHERE id = $1
	`, postID)

	utils.SuccessResponse(c, gin.H{"message": "Post liked successfully"})
}

// UnlikePost unlikes a post
func (s *InteractionService) UnlikePost(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	postID := c.Param("id")
	if postID == "" {
		utils.BadRequestError(c, "Post ID is required")
		return
	}

	// Remove like
	result, err := s.db.Exec(`
		DELETE FROM likes WHERE user_id = $1 AND post_id = $2
	`, userID, postID)

	if err != nil {
		utils.InternalServerError(c, "Failed to unlike post")
		return
	}

	rowsAffected, _ := result.RowsAffected()
	if rowsAffected == 0 {
		utils.NotFoundError(c, "Like not found")
		return
	}

	// Update post likes count
	s.db.Exec(`
		UPDATE posts SET likes_count = GREATEST(likes_count - 1, 0) 
		WHERE id = $1
	`, postID)

	utils.SuccessResponse(c, gin.H{"message": "Post unliked successfully"})
}

// CommentOnPost creates a comment on a post
func (s *InteractionService) CommentOnPost(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	postID := c.Param("id")
	if postID == "" {
		utils.BadRequestError(c, "Post ID is required")
		return
	}

	var req models.CreateCommentRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	if req.Content == "" {
		utils.BadRequestError(c, "Comment content is required")
		return
	}

	// Create comment
	commentID := uuid.New().String()
	_, err = s.db.Exec(`
		INSERT INTO comments (id, user_id, post_id, content, created_at)
		VALUES ($1, $2, $3, $4, $5)
	`, commentID, userID, postID, req.Content, time.Now())

	if err != nil {
		utils.InternalServerError(c, "Failed to create comment")
		return
	}

	// Update post comments count
	s.db.Exec(`
		UPDATE posts SET comments_count = comments_count + 1 
		WHERE id = $1
	`, postID)

	// Get created comment
	comment, err := s.getCommentByID(commentID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get created comment")
		return
	}

	utils.CreatedResponse(c, comment)
}

// GetPostComments gets comments for a post
func (s *InteractionService) GetPostComments(c *gin.Context) {
	postID := c.Param("id")
	if postID == "" {
		utils.BadRequestError(c, "Post ID is required")
		return
	}

	rows, err := s.db.Query(`
		SELECT id, user_id, post_id, content, created_at
		FROM comments 
		WHERE post_id = $1
		ORDER BY created_at DESC
		LIMIT 50
	`, postID)

	if err != nil {
		utils.InternalServerError(c, "Failed to get comments")
		return
	}
	defer rows.Close()

	var comments []models.Comment
	for rows.Next() {
		var comment models.Comment
		err := rows.Scan(
			&comment.ID, &comment.UserID, &comment.PostID,
			&comment.Content, &comment.CreatedAt,
		)
		if err != nil {
			continue
		}
		comments = append(comments, comment)
	}

	utils.SuccessResponse(c, comments)
}

// ReactToShortVideo creates a reaction to a short video
func (s *InteractionService) ReactToShortVideo(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	videoID := c.Param("id")
	if videoID == "" {
		utils.BadRequestError(c, "Video ID is required")
		return
	}

	var req struct {
		ReactionType models.ReactionType `json:"reactionType" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Create or update reaction
	reactionID := uuid.New().String()
	_, err = s.db.Exec(`
		INSERT INTO short_video_reactions (id, user_id, short_video_id, reaction_type, created_at)
		VALUES ($1, $2, $3, $4, $5)
		ON CONFLICT (user_id, short_video_id) 
		DO UPDATE SET reaction_type = $4, created_at = $5
	`, reactionID, userID, videoID, req.ReactionType, time.Now())

	if err != nil {
		utils.InternalServerError(c, "Failed to react to short video")
		return
	}

	// Update video likes count (assuming like is the main reaction)
	if req.ReactionType == models.ReactionTypeLike {
		s.db.Exec(`
			UPDATE short_videos SET likes_count = likes_count + 1 
			WHERE id = $1
		`, videoID)
	}

	utils.SuccessResponse(c, gin.H{"message": "Reaction added successfully"})
}

// CommentOnShortVideo creates a comment on a short video
func (s *InteractionService) CommentOnShortVideo(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	videoID := c.Param("id")
	if videoID == "" {
		utils.BadRequestError(c, "Video ID is required")
		return
	}

	var req models.CreateCommentRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	if req.Content == "" {
		utils.BadRequestError(c, "Comment content is required")
		return
	}

	// Create comment
	commentID := uuid.New().String()
	_, err = s.db.Exec(`
		INSERT INTO comments (id, user_id, short_video_id, content, created_at)
		VALUES ($1, $2, $3, $4, $5)
	`, commentID, userID, videoID, req.Content, time.Now())

	if err != nil {
		utils.InternalServerError(c, "Failed to create comment")
		return
	}

	// Update video comments count
	s.db.Exec(`
		UPDATE short_videos SET comments_count = comments_count + 1 
		WHERE id = $1
	`, videoID)

	// Get created comment
	comment, err := s.getCommentByID(commentID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get created comment")
		return
	}

	utils.CreatedResponse(c, comment)
}

// GetShortVideoComments gets comments for a short video
func (s *InteractionService) GetShortVideoComments(c *gin.Context) {
	videoID := c.Param("id")
	if videoID == "" {
		utils.BadRequestError(c, "Video ID is required")
		return
	}

	rows, err := s.db.Query(`
		SELECT id, user_id, short_video_id, content, created_at
		FROM comments 
		WHERE short_video_id = $1
		ORDER BY created_at DESC
		LIMIT 50
	`, videoID)

	if err != nil {
		utils.InternalServerError(c, "Failed to get comments")
		return
	}
	defer rows.Close()

	var comments []models.Comment
	for rows.Next() {
		var comment models.Comment
		err := rows.Scan(
			&comment.ID, &comment.UserID, &comment.ShortVideoID,
			&comment.Content, &comment.CreatedAt,
		)
		if err != nil {
			continue
		}
		comments = append(comments, comment)
	}

	utils.SuccessResponse(c, comments)
}

// Helper functions

func (s *InteractionService) isPostLiked(userID, postID string) (bool, error) {
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM likes 
		WHERE user_id = $1 AND post_id = $2
	`, userID, postID).Scan(&count)
	return count > 0, err
}

func (s *InteractionService) getCommentByID(commentID string) (*models.Comment, error) {
	var comment models.Comment
	err := s.db.QueryRow(`
		SELECT id, user_id, post_id, short_video_id, content, created_at
		FROM comments WHERE id = $1
	`, commentID).Scan(
		&comment.ID, &comment.UserID, &comment.PostID,
		&comment.ShortVideoID, &comment.Content, &comment.CreatedAt,
	)
	return &comment, err
}

// Placeholder implementations for remaining methods
func (s *InteractionService) SharePost(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Share post not yet implemented")
}

func (s *InteractionService) ShareShortVideo(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Share short video not yet implemented")
}

func (s *InteractionService) GetTrendingHashtags(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Trending hashtags not yet implemented")
}

func (s *InteractionService) SearchHashtags(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Search hashtags not yet implemented")
}

func (s *InteractionService) GetRecommendations(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Content recommendations not yet implemented")
}

func (s *InteractionService) UpdateAlgorithmPreferences(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Algorithm preferences update not yet implemented")
}

func (s *InteractionService) GetAlgorithmPreferences(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Algorithm preferences not yet implemented")
}

func (s *InteractionService) SubmitAlgorithmFeedback(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Algorithm feedback not yet implemented")
}

func (s *InteractionService) SearchContent(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Content search not yet implemented")
}

func (s *InteractionService) SearchCreators(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Creator search not yet implemented")
}

func (s *InteractionService) GetFlaggedContent(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Flagged content not yet implemented")
}

func (s *InteractionService) ModerateContent(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Content moderation not yet implemented")
}

func (s *InteractionService) GetContentReports(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Content reports not yet implemented")
}

func (s *InteractionService) ResolveContentReport(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Resolve content report not yet implemented")
}