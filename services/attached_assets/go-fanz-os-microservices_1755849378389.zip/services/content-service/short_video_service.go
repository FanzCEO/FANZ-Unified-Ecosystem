package main

import (
	"database/sql"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/shopspring/decimal"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// ShortVideoService handles short video operations
type ShortVideoService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewShortVideoService creates a new short video service instance
func NewShortVideoService(db *database.DB, redis *cache.RedisClient) *ShortVideoService {
	return &ShortVideoService{
		db:    db,
		redis: redis,
	}
}

// CreateShortVideo creates a new short video
func (s *ShortVideoService) CreateShortVideo(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	var req models.CreateShortVideoRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Validate required fields
	if req.VideoURL == "" {
		utils.BadRequestError(c, "Video URL is required")
		return
	}

	if req.Duration <= 0 || req.Duration > 300 { // Max 5 minutes
		utils.BadRequestError(c, "Duration must be between 1 and 300 seconds")
		return
	}

	// Create short video
	videoID := uuid.New().String()
	now := time.Now()

	query := `
		INSERT INTO short_videos (
			id, creator_id, title, description, tags, video_url, thumbnail_url,
			duration, aspect_ratio, resolution, status, is_public, allow_comments,
			allow_duets, allow_remix, created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
	`

	_, err = s.db.Exec(query,
		videoID, userID, req.Title, req.Description, req.Tags, req.VideoURL,
		req.ThumbnailURL, req.Duration, req.AspectRatio, req.Resolution,
		models.ShortVideoStatusProcessing, req.IsPublic, req.AllowComments,
		req.AllowDuets, req.AllowRemix, now, now,
	)

	if err != nil {
		utils.InternalServerError(c, "Failed to create short video")
		return
	}

	// Get created short video
	video, err := s.getShortVideoByID(videoID)
	if err != nil {
		utils.InternalServerError(c, "Failed to retrieve created short video")
		return
	}

	utils.CreatedResponse(c, video)
}

// GetShortVideos gets short videos with pagination and filtering
func (s *ShortVideoService) GetShortVideos(c *gin.Context) {
	// Get query parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	creatorID := c.Query("creator_id")
	status := c.Query("status")

	// Validate pagination
	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 50 {
		limit = 20
	}

	offset := (page - 1) * limit

	// Build query
	whereClause := []string{"is_public = true", "status = 'published'"}
	args := []interface{}{}
	argIndex := 1

	// Filter by creator
	if creatorID != "" {
		whereClause = append(whereClause, fmt.Sprintf("creator_id = $%d", argIndex))
		args = append(args, creatorID)
		argIndex++
	}

	// Admin can filter by status
	userID, userRole, _ := middleware.GetUserFromContext(c)
	if userRole == models.UserRoleAdmin && status != "" {
		// Remove the default status filter for admins
		whereClause = whereClause[:len(whereClause)-1]
		whereClause = append(whereClause, fmt.Sprintf("status = $%d", argIndex))
		args = append(args, status)
		argIndex++
	}

	// Get total count
	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM short_videos WHERE %s", strings.Join(whereClause, " AND "))
	var total int
	err := s.db.QueryRow(countQuery, args...).Scan(&total)
	if err != nil {
		utils.InternalServerError(c, "Failed to count short videos")
		return
	}

	// Get short videos
	query := fmt.Sprintf(`
		SELECT id, creator_id, title, description, tags, video_url, thumbnail_url,
			   duration, aspect_ratio, resolution, status, is_public, allow_comments,
			   allow_duets, allow_remix, views_count, likes_count, comments_count,
			   shares_count, engagement_score, algorithm_boost, created_at,
			   published_at, updated_at
		FROM short_videos 
		WHERE %s
		ORDER BY created_at DESC
		LIMIT $%d OFFSET $%d
	`, strings.Join(whereClause, " AND "), argIndex, argIndex+1)

	args = append(args, limit, offset)

	rows, err := s.db.Query(query, args...)
	if err != nil {
		utils.InternalServerError(c, "Failed to get short videos")
		return
	}
	defer rows.Close()

	var videos []models.ShortVideo
	for rows.Next() {
		var video models.ShortVideo
		err := rows.Scan(
			&video.ID, &video.CreatorID, &video.Title, &video.Description,
			&video.Tags, &video.VideoURL, &video.ThumbnailURL, &video.Duration,
			&video.AspectRatio, &video.Resolution, &video.Status, &video.IsPublic,
			&video.AllowComments, &video.AllowDuets, &video.AllowRemix,
			&video.ViewsCount, &video.LikesCount, &video.CommentsCount,
			&video.SharesCount, &video.EngagementScore, &video.AlgorithmBoost,
			&video.CreatedAt, &video.PublishedAt, &video.UpdatedAt,
		)
		if err != nil {
			continue
		}

		videos = append(videos, video)
	}

	// Calculate pagination metadata
	totalPages := (total + limit - 1) / limit
	meta := &utils.Meta{
		Page:       page,
		Limit:      limit,
		Total:      total,
		TotalPages: totalPages,
	}

	utils.SuccessResponseWithMeta(c, videos, meta)
}

// GetShortVideo gets a specific short video by ID
func (s *ShortVideoService) GetShortVideo(c *gin.Context) {
	videoID := c.Param("id")
	if videoID == "" {
		utils.BadRequestError(c, "Video ID is required")
		return
	}

	video, err := s.getShortVideoByID(videoID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Short video not found")
		} else {
			utils.InternalServerError(c, "Failed to get short video")
		}
		return
	}

	// Check if video is public or user has access
	userID, _, _ := middleware.GetUserFromContext(c)
	if !video.IsPublic && userID != video.CreatorID {
		utils.ForbiddenError(c, "This video is private")
		return
	}

	// Increment view count
	if userID != "" {
		s.recordShortVideoView(videoID, userID)
	}

	utils.SuccessResponse(c, video)
}

// UpdateShortVideo updates an existing short video
func (s *ShortVideoService) UpdateShortVideo(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	videoID := c.Param("id")
	if videoID == "" {
		utils.BadRequestError(c, "Video ID is required")
		return
	}

	// Check if user owns the video
	video, err := s.getShortVideoByID(videoID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Short video not found")
		} else {
			utils.InternalServerError(c, "Failed to get short video")
		}
		return
	}

	if video.CreatorID != userID {
		utils.ForbiddenError(c, "You can only update your own videos")
		return
	}

	var req models.CreateShortVideoRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Update short video
	_, err = s.db.Exec(`
		UPDATE short_videos 
		SET title = $1, description = $2, tags = $3, thumbnail_url = $4,
			is_public = $5, allow_comments = $6, allow_duets = $7,
			allow_remix = $8, updated_at = $9
		WHERE id = $10
	`, req.Title, req.Description, req.Tags, req.ThumbnailURL,
		req.IsPublic, req.AllowComments, req.AllowDuets, req.AllowRemix,
		time.Now(), videoID)

	if err != nil {
		utils.InternalServerError(c, "Failed to update short video")
		return
	}

	// Get updated video
	updatedVideo, err := s.getShortVideoByID(videoID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get updated short video")
		return
	}

	utils.SuccessResponse(c, updatedVideo)
}

// DeleteShortVideo deletes a short video
func (s *ShortVideoService) DeleteShortVideo(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	videoID := c.Param("id")
	if videoID == "" {
		utils.BadRequestError(c, "Video ID is required")
		return
	}

	// Check if user owns the video
	video, err := s.getShortVideoByID(videoID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Short video not found")
		} else {
			utils.InternalServerError(c, "Failed to get short video")
		}
		return
	}

	if video.CreatorID != userID {
		utils.ForbiddenError(c, "You can only delete your own videos")
		return
	}

	// Delete short video
	_, err = s.db.Exec("DELETE FROM short_videos WHERE id = $1", videoID)
	if err != nil {
		utils.InternalServerError(c, "Failed to delete short video")
		return
	}

	utils.SuccessResponse(c, gin.H{"message": "Short video deleted successfully"})
}

// RecordView records a view for a short video
func (s *ShortVideoService) RecordView(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	videoID := c.Param("id")
	if videoID == "" {
		utils.BadRequestError(c, "Video ID is required")
		return
	}

	var req struct {
		WatchTime int  `json:"watchTime" binding:"required,min=0"`
		Completed bool `json:"completed"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Record the view
	err = s.recordShortVideoViewWithDetails(videoID, userID, req.WatchTime, req.Completed)
	if err != nil {
		utils.InternalServerError(c, "Failed to record view")
		return
	}

	utils.SuccessResponse(c, gin.H{"message": "View recorded successfully"})
}

// Helper functions

func (s *ShortVideoService) getShortVideoByID(videoID string) (*models.ShortVideo, error) {
	var video models.ShortVideo
	err := s.db.QueryRow(`
		SELECT id, creator_id, title, description, tags, video_url, thumbnail_url,
			   duration, aspect_ratio, resolution, status, is_public, allow_comments,
			   allow_duets, allow_remix, views_count, likes_count, comments_count,
			   shares_count, engagement_score, algorithm_boost, created_at,
			   published_at, updated_at
		FROM short_videos WHERE id = $1
	`, videoID).Scan(
		&video.ID, &video.CreatorID, &video.Title, &video.Description,
		&video.Tags, &video.VideoURL, &video.ThumbnailURL, &video.Duration,
		&video.AspectRatio, &video.Resolution, &video.Status, &video.IsPublic,
		&video.AllowComments, &video.AllowDuets, &video.AllowRemix,
		&video.ViewsCount, &video.LikesCount, &video.CommentsCount,
		&video.SharesCount, &video.EngagementScore, &video.AlgorithmBoost,
		&video.CreatedAt, &video.PublishedAt, &video.UpdatedAt,
	)
	return &video, err
}

func (s *ShortVideoService) recordShortVideoView(videoID, userID string) {
	// Simple view increment
	s.db.Exec(`
		UPDATE short_videos SET views_count = views_count + 1 
		WHERE id = $1
	`, videoID)
}

func (s *ShortVideoService) recordShortVideoViewWithDetails(videoID, userID string, watchTime int, completed bool) error {
	viewID := uuid.New().String()
	_, err := s.db.Exec(`
		INSERT INTO short_video_views (id, user_id, short_video_id, watch_time, completed, created_at)
		VALUES ($1, $2, $3, $4, $5, $6)
		ON CONFLICT (user_id, short_video_id) DO UPDATE SET
		watch_time = GREATEST(short_video_views.watch_time, $4),
		completed = short_video_views.completed OR $5
	`, viewID, userID, videoID, watchTime, completed, time.Now())

	if err == nil {
		// Increment view count
		s.db.Exec(`
			UPDATE short_videos SET views_count = views_count + 1 
			WHERE id = $1
		`, videoID)
	}

	return err
}

// Placeholder implementations for remaining methods
func (s *ShortVideoService) GetTrendingShortVideos(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Trending short videos not yet implemented")
}

func (s *ShortVideoService) GetForYouFeed(c *gin.Context) {
	utils.ServiceUnavailableError(c, "For You feed not yet implemented")
}

func (s *ShortVideoService) GetShortVideosByCreator(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Short videos by creator not yet implemented")
}

func (s *ShortVideoService) GetShortVideosByHashtag(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Short videos by hashtag not yet implemented")
}

func (s *ShortVideoService) SearchShortVideos(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Short video search not yet implemented")
}

func (s *ShortVideoService) GetShortVideoAnalytics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Short video analytics not yet implemented")
}