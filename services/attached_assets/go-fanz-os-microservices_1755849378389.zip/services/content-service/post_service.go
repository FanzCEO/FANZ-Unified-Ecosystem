package main

import (
	"database/sql"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/shopspring/decimal"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// PostService handles post-related operations
type PostService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewPostService creates a new post service instance
func NewPostService(db *database.DB, redis *cache.RedisClient) *PostService {
	return &PostService{
		db:    db,
		redis: redis,
	}
}

// CreatePost creates a new post
func (s *PostService) CreatePost(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	var req models.CreatePostRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Validate content
	if strings.TrimSpace(req.Content) == "" {
		utils.BadRequestError(c, "Content is required")
		return
	}

	// Validate PPV price if post type is PPV
	if req.PostType == models.PostTypePPV && (req.PPVPrice == nil || req.PPVPrice.LessThanOrEqual(decimal.Zero)) {
		utils.BadRequestError(c, "PPV price must be greater than 0 for PPV posts")
		return
	}

	// Create post
	postID := uuid.New().String()
	now := time.Now()

	query := `
		INSERT INTO posts (
			id, creator_id, title, content, media_url, media_type, content_type,
			post_type, visibility, tags, ppv_price, created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
	`

	_, err = s.db.Exec(query,
		postID, userID, req.Title, req.Content, req.MediaURL, req.MediaType,
		req.ContentType, req.PostType, req.Visibility, req.Tags, req.PPVPrice,
		now, now,
	)

	if err != nil {
		utils.InternalServerError(c, "Failed to create post")
		return
	}

	// Get created post
	post, err := s.getPostByID(postID)
	if err != nil {
		utils.InternalServerError(c, "Failed to retrieve created post")
		return
	}

	utils.CreatedResponse(c, post)
}

// GetPosts gets posts with pagination and filtering
func (s *PostService) GetPosts(c *gin.Context) {
	// Get query parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	postType := c.Query("type")
	visibility := c.Query("visibility")
	creatorID := c.Query("creator_id")

	// Validate pagination
	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 20
	}

	offset := (page - 1) * limit

	// Build query
	whereClause := []string{"1=1"}
	args := []interface{}{}
	argIndex := 1

	// Filter by post type
	if postType != "" {
		whereClause = append(whereClause, fmt.Sprintf("post_type = $%d", argIndex))
		args = append(args, postType)
		argIndex++
	}

	// Filter by visibility (default to public for non-authenticated users)
	userID, _, _ := middleware.GetUserFromContext(c)
	if userID == "" {
		// Non-authenticated users can only see public free posts
		whereClause = append(whereClause, "visibility = 'public' AND post_type = 'free'")
	} else if visibility != "" {
		whereClause = append(whereClause, fmt.Sprintf("visibility = $%d", argIndex))
		args = append(args, visibility)
		argIndex++
	}

	// Filter by creator
	if creatorID != "" {
		whereClause = append(whereClause, fmt.Sprintf("creator_id = $%d", argIndex))
		args = append(args, creatorID)
		argIndex++
	}

	// Get total count
	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM posts WHERE %s", strings.Join(whereClause, " AND "))
	var total int
	err := s.db.QueryRow(countQuery, args...).Scan(&total)
	if err != nil {
		utils.InternalServerError(c, "Failed to count posts")
		return
	}

	// Get posts
	query := fmt.Sprintf(`
		SELECT id, creator_id, title, content, media_url, media_type, content_type,
			   post_type, visibility, tags, ppv_price, likes_count, comments_count,
			   views_count, shares_count, created_at, updated_at
		FROM posts 
		WHERE %s
		ORDER BY created_at DESC
		LIMIT $%d OFFSET $%d
	`, strings.Join(whereClause, " AND "), argIndex, argIndex+1)

	args = append(args, limit, offset)

	rows, err := s.db.Query(query, args...)
	if err != nil {
		utils.InternalServerError(c, "Failed to get posts")
		return
	}
	defer rows.Close()

	var posts []models.Post
	for rows.Next() {
		var post models.Post
		err := rows.Scan(
			&post.ID, &post.CreatorID, &post.Title, &post.Content,
			&post.MediaURL, &post.MediaType, &post.ContentType,
			&post.PostType, &post.Visibility, &post.Tags, &post.PPVPrice,
			&post.LikesCount, &post.CommentsCount, &post.ViewsCount,
			&post.SharesCount, &post.CreatedAt, &post.UpdatedAt,
		)
		if err != nil {
			continue
		}

		// Check if user has access to PPV content
		if post.PostType == models.PostTypePPV && userID != "" && userID != post.CreatorID {
			hasAccess, _ := s.hasAccessToPPVPost(userID, post.ID)
			if !hasAccess {
				// Hide content for locked PPV posts
				post.Content = "This content is locked. Unlock to view."
				post.MediaURL = nil
			}
		}

		posts = append(posts, post)
	}

	// Calculate pagination metadata
	totalPages := (total + limit - 1) / limit
	meta := &utils.Meta{
		Page:       page,
		Limit:      limit,
		Total:      total,
		TotalPages: totalPages,
	}

	utils.SuccessResponseWithMeta(c, posts, meta)
}

// GetPost gets a specific post by ID
func (s *PostService) GetPost(c *gin.Context) {
	postID := c.Param("id")
	if postID == "" {
		utils.BadRequestError(c, "Post ID is required")
		return
	}

	post, err := s.getPostByID(postID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Post not found")
		} else {
			utils.InternalServerError(c, "Failed to get post")
		}
		return
	}

	// Check access for PPV posts
	userID, _, _ := middleware.GetUserFromContext(c)
	if post.PostType == models.PostTypePPV && userID != "" && userID != post.CreatorID {
		hasAccess, err := s.hasAccessToPPVPost(userID, postID)
		if err != nil {
			utils.InternalServerError(c, "Failed to check access")
			return
		}
		if !hasAccess {
			// Return limited post info for locked PPV content
			post.Content = "This content is locked. Unlock to view."
			post.MediaURL = nil
		}
	} else if post.PostType == models.PostTypePPV && userID == "" {
		// Non-authenticated users cannot access PPV content
		utils.UnauthorizedError(c, "Authentication required to view this content")
		return
	}

	// Increment view count
	if userID != "" {
		s.incrementPostViews(postID)
	}

	utils.SuccessResponse(c, post)
}

// UpdatePost updates an existing post
func (s *PostService) UpdatePost(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	postID := c.Param("id")
	if postID == "" {
		utils.BadRequestError(c, "Post ID is required")
		return
	}

	// Check if user owns the post
	post, err := s.getPostByID(postID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Post not found")
		} else {
			utils.InternalServerError(c, "Failed to get post")
		}
		return
	}

	if post.CreatorID != userID {
		utils.ForbiddenError(c, "You can only update your own posts")
		return
	}

	var req models.CreatePostRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Update post
	_, err = s.db.Exec(`
		UPDATE posts 
		SET title = $1, content = $2, media_url = $3, media_type = $4,
			content_type = $5, post_type = $6, visibility = $7, tags = $8,
			ppv_price = $9, updated_at = $10
		WHERE id = $11
	`, req.Title, req.Content, req.MediaURL, req.MediaType, req.ContentType,
		req.PostType, req.Visibility, req.Tags, req.PPVPrice, time.Now(), postID)

	if err != nil {
		utils.InternalServerError(c, "Failed to update post")
		return
	}

	// Get updated post
	updatedPost, err := s.getPostByID(postID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get updated post")
		return
	}

	utils.SuccessResponse(c, updatedPost)
}

// DeletePost deletes a post
func (s *PostService) DeletePost(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	postID := c.Param("id")
	if postID == "" {
		utils.BadRequestError(c, "Post ID is required")
		return
	}

	// Check if user owns the post
	post, err := s.getPostByID(postID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Post not found")
		} else {
			utils.InternalServerError(c, "Failed to get post")
		}
		return
	}

	if post.CreatorID != userID {
		utils.ForbiddenError(c, "You can only delete your own posts")
		return
	}

	// Delete post
	_, err = s.db.Exec("DELETE FROM posts WHERE id = $1", postID)
	if err != nil {
		utils.InternalServerError(c, "Failed to delete post")
		return
	}

	utils.SuccessResponse(c, gin.H{"message": "Post deleted successfully"})
}

// UnlockPPVPost unlocks a PPV post for the user
func (s *PostService) UnlockPPVPost(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	postID := c.Param("id")
	if postID == "" {
		utils.BadRequestError(c, "Post ID is required")
		return
	}

	// Get post
	post, err := s.getPostByID(postID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Post not found")
		} else {
			utils.InternalServerError(c, "Failed to get post")
		}
		return
	}

	if post.PostType != models.PostTypePPV {
		utils.BadRequestError(c, "This post is not pay-per-view")
		return
	}

	if post.CreatorID == userID {
		utils.BadRequestError(c, "You own this post")
		return
	}

	// Check if already unlocked
	hasAccess, err := s.hasAccessToPPVPost(userID, postID)
	if err != nil {
		utils.InternalServerError(c, "Failed to check access")
		return
	}
	if hasAccess {
		utils.ConflictError(c, "Post already unlocked")
		return
	}

	// Create PPV unlock record
	unlockID := uuid.New().String()
	_, err = s.db.Exec(`
		INSERT INTO ppv_unlocks (id, user_id, post_id, price, created_at)
		VALUES ($1, $2, $3, $4, $5)
	`, unlockID, userID, postID, post.PPVPrice, time.Now())

	if err != nil {
		utils.InternalServerError(c, "Failed to unlock post")
		return
	}

	utils.SuccessResponse(c, gin.H{
		"message": "Post unlocked successfully",
		"unlock_id": unlockID,
	})
}

// Helper functions

func (s *PostService) getPostByID(postID string) (*models.Post, error) {
	var post models.Post
	err := s.db.QueryRow(`
		SELECT id, creator_id, title, content, media_url, media_type, content_type,
			   post_type, visibility, tags, ppv_price, likes_count, comments_count,
			   views_count, shares_count, created_at, updated_at
		FROM posts WHERE id = $1
	`, postID).Scan(
		&post.ID, &post.CreatorID, &post.Title, &post.Content,
		&post.MediaURL, &post.MediaType, &post.ContentType,
		&post.PostType, &post.Visibility, &post.Tags, &post.PPVPrice,
		&post.LikesCount, &post.CommentsCount, &post.ViewsCount,
		&post.SharesCount, &post.CreatedAt, &post.UpdatedAt,
	)
	return &post, err
}

func (s *PostService) hasAccessToPPVPost(userID, postID string) (bool, error) {
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM ppv_unlocks 
		WHERE user_id = $1 AND post_id = $2
	`, userID, postID).Scan(&count)
	return count > 0, err
}

func (s *PostService) incrementPostViews(postID string) {
	s.db.Exec(`
		UPDATE posts SET views_count = views_count + 1 
		WHERE id = $1
	`, postID)
}

// Placeholder implementations for remaining methods
func (s *PostService) GetTrendingPosts(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Trending posts not yet implemented")
}

func (s *PostService) GetPostsByCreator(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Posts by creator not yet implemented")
}

func (s *PostService) GetPostsByHashtag(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Posts by hashtag not yet implemented")
}

func (s *PostService) SearchPosts(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Post search not yet implemented")
}

func (s *PostService) GetPostAnalytics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Post analytics not yet implemented")
}

func (s *PostService) GetCreatorAnalytics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Creator analytics not yet implemented")
}

func (s *PostService) GetContentInsights(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Content insights not yet implemented")
}

func (s *PostService) GetPlatformContentAnalytics(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Platform content analytics not yet implemented")
}