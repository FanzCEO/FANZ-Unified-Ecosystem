package main

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/utils"
)

// setupRoutes configures all Content Service routes
func setupRoutes(
	r *gin.Engine,
	postService *PostService,
	shortVideoService *ShortVideoService,
	mediaService *MediaService,
	interactionService *InteractionService,
) {
	// Health check
	r.GET("/health", healthCheck)
	r.GET("/", rootHandler)

	// Posts routes
	posts := r.Group("/posts")
	{
		// Public post browsing
		posts.GET("", middleware.OptionalAuth(), postService.GetPosts)
		posts.GET("/:id", middleware.OptionalAuth(), postService.GetPost)
		posts.GET("/trending", middleware.OptionalAuth(), postService.GetTrendingPosts)
		posts.GET("/creator/:creatorId", middleware.OptionalAuth(), postService.GetPostsByCreator)
		
		// Authenticated post actions
		postsAuth := posts.Group("")
		postsAuth.Use(middleware.AuthMiddleware())
		{
			// Creator post management
			postsAuth.POST("", middleware.RequireRole("creator", "admin"), postService.CreatePost)
			postsAuth.PUT("/:id", middleware.RequireRole("creator", "admin"), postService.UpdatePost)
			postsAuth.DELETE("/:id", middleware.RequireRole("creator", "admin"), postService.DeletePost)
			
			// Post interactions
			postsAuth.POST("/:id/like", interactionService.LikePost)
			postsAuth.DELETE("/:id/like", interactionService.UnlikePost)
			postsAuth.POST("/:id/comment", interactionService.CommentOnPost)
			postsAuth.GET("/:id/comments", interactionService.GetPostComments)
			postsAuth.POST("/:id/share", interactionService.SharePost)
			
			// PPV unlock
			postsAuth.POST("/:id/unlock", postService.UnlockPPVPost)
		}
	}

	// Short videos routes
	shortVideos := r.Group("/short-videos")
	{
		// Public short video browsing
		shortVideos.GET("", middleware.OptionalAuth(), shortVideoService.GetShortVideos)
		shortVideos.GET("/:id", middleware.OptionalAuth(), shortVideoService.GetShortVideo)
		shortVideos.GET("/trending", middleware.OptionalAuth(), shortVideoService.GetTrendingShortVideos)
		shortVideos.GET("/for-you", middleware.OptionalAuth(), shortVideoService.GetForYouFeed)
		shortVideos.GET("/creator/:creatorId", middleware.OptionalAuth(), shortVideoService.GetShortVideosByCreator)
		
		// Authenticated short video actions
		shortVideosAuth := shortVideos.Group("")
		shortVideosAuth.Use(middleware.AuthMiddleware())
		{
			// Creator short video management
			shortVideosAuth.POST("", middleware.RequireRole("creator", "admin"), shortVideoService.CreateShortVideo)
			shortVideosAuth.PUT("/:id", middleware.RequireRole("creator", "admin"), shortVideoService.UpdateShortVideo)
			shortVideosAuth.DELETE("/:id", middleware.RequireRole("creator", "admin"), shortVideoService.DeleteShortVideo)
			
			// Short video interactions
			shortVideosAuth.POST("/:id/reaction", interactionService.ReactToShortVideo)
			shortVideosAuth.POST("/:id/comment", interactionService.CommentOnShortVideo)
			shortVideosAuth.GET("/:id/comments", interactionService.GetShortVideoComments)
			shortVideosAuth.POST("/:id/share", interactionService.ShareShortVideo)
			shortVideosAuth.POST("/:id/view", shortVideoService.RecordView)
		}
	}

	// Hashtags routes
	hashtags := r.Group("/hashtags")
	{
		hashtags.GET("/trending", interactionService.GetTrendingHashtags)
		hashtags.GET("/:tag/posts", middleware.OptionalAuth(), postService.GetPostsByHashtag)
		hashtags.GET("/:tag/short-videos", middleware.OptionalAuth(), shortVideoService.GetShortVideosByHashtag)
		hashtags.GET("/search", interactionService.SearchHashtags)
	}

	// Media upload routes (with stricter rate limiting)
	upload := r.Group("/upload")
	upload.Use(middleware.AuthMiddleware())
	upload.Use(middleware.RequireRole("creator", "admin"))
	{
		// Image uploads
		upload.POST("/image", mediaService.UploadImage)
		upload.POST("/images/bulk", mediaService.BulkUploadImages)
		
		// Video uploads
		upload.POST("/video", mediaService.UploadVideo)
		upload.POST("/video/process", mediaService.ProcessVideo)
		upload.GET("/video/:id/status", mediaService.GetVideoProcessingStatus)
		
		// Audio uploads
		upload.POST("/audio", mediaService.UploadAudio)
		
		// Avatar and profile images
		upload.POST("/avatar", mediaService.UploadAvatar)
		upload.POST("/cover", mediaService.UploadCoverImage)
		
		// Document uploads (for compliance)
		upload.POST("/document", mediaService.UploadDocument)
	}

	// Media processing routes
	media := r.Group("/media")
	media.Use(middleware.AuthMiddleware())
	{
		media.GET("/assets/:id", mediaService.GetMediaAsset)
		media.DELETE("/assets/:id", middleware.RequireRole("creator", "admin"), mediaService.DeleteMediaAsset)
		media.GET("/assets", mediaService.GetUserMediaAssets)
		media.POST("/assets/:id/optimize", middleware.RequireRole("creator", "admin"), mediaService.OptimizeMedia)
	}

	// Content analytics routes
	analytics := r.Group("/analytics")
	analytics.Use(middleware.AuthMiddleware())
	analytics.Use(middleware.RequireRole("creator", "admin"))
	{
		analytics.GET("/posts/:id", postService.GetPostAnalytics)
		analytics.GET("/short-videos/:id", shortVideoService.GetShortVideoAnalytics)
		analytics.GET("/creator/performance", postService.GetCreatorAnalytics)
		analytics.GET("/content/insights", postService.GetContentInsights)
	}

	// Algorithm and recommendations routes
	algorithm := r.Group("/algorithm")
	algorithm.Use(middleware.AuthMiddleware())
	{
		algorithm.GET("/recommendations", interactionService.GetRecommendations)
		algorithm.POST("/preferences", interactionService.UpdateAlgorithmPreferences)
		algorithm.GET("/preferences", interactionService.GetAlgorithmPreferences)
		algorithm.POST("/feedback", interactionService.SubmitAlgorithmFeedback)
	}

	// Search routes
	search := r.Group("/search")
	{
		search.GET("/posts", middleware.OptionalAuth(), postService.SearchPosts)
		search.GET("/short-videos", middleware.OptionalAuth(), shortVideoService.SearchShortVideos)
		search.GET("/content", middleware.OptionalAuth(), interactionService.SearchContent)
		search.GET("/creators", middleware.OptionalAuth(), interactionService.SearchCreators)
	}

	// Admin content management routes
	admin := r.Group("/admin")
	admin.Use(middleware.AuthMiddleware())
	admin.Use(middleware.RequireRole("admin"))
	{
		admin.GET("/content/flagged", interactionService.GetFlaggedContent)
		admin.PUT("/content/:id/moderate", interactionService.ModerateContent)
		admin.GET("/content/reports", interactionService.GetContentReports)
		admin.PUT("/reports/:id/resolve", interactionService.ResolveContentReport)
		admin.GET("/content/analytics", postService.GetPlatformContentAnalytics)
	}
}

// healthCheck returns the health status of the Content Service
func healthCheck(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"status":    "healthy",
		"service":   "content-service",
		"timestamp": time.Now().Unix(),
	})
}

// rootHandler returns service information
func rootHandler(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"name":        "Fanz OS Content Service",
		"version":     "1.0.0",
		"description": "Content management, media processing, and social interactions",
		"endpoints": gin.H{
			"health":       "/health",
			"posts":        "/posts",
			"short-videos": "/short-videos",
			"hashtags":     "/hashtags",
			"upload":       "/upload",
			"media":        "/media",
			"analytics":    "/analytics",
			"search":       "/search",
		},
	})
}