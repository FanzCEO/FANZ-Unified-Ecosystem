package main

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/utils"
)

// setupRoutes configures all Streaming Service routes
func setupRoutes(
	r *gin.Engine,
	streamService *StreamService,
	chatService *ChatService,
	webrtcService *WebRTCService,
	analyticsService *AnalyticsService,
	recordingService *RecordingService,
	hub *WebSocketHub,
) {
	// Health check
	r.GET("/health", healthCheck)
	r.GET("/", rootHandler)

	// Public stream browsing
	r.GET("/streams", middleware.OptionalAuth(), streamService.GetStreams)
	r.GET("/streams/:id", middleware.OptionalAuth(), streamService.GetStream)
	r.GET("/streams/live", middleware.OptionalAuth(), streamService.GetLiveStreams)
	r.GET("/streams/featured", middleware.OptionalAuth(), streamService.GetFeaturedStreams)

	// Authenticated stream routes
	streams := r.Group("/streams")
	streams.Use(middleware.AuthMiddleware())
	{
		// Creator stream management
		creatorStreams := streams.Group("")
		creatorStreams.Use(middleware.RequireRole("creator", "admin"))
		{
			creatorStreams.POST("", streamService.CreateStream)
			creatorStreams.PUT("/:id", streamService.UpdateStream)
			creatorStreams.DELETE("/:id", streamService.DeleteStream)
			creatorStreams.POST("/:id/start", streamService.StartStream)
			creatorStreams.POST("/:id/end", streamService.EndStream)
			creatorStreams.PUT("/:id/settings", streamService.UpdateStreamSettings)
			creatorStreams.GET("/:id/analytics", analyticsService.GetStreamAnalytics)
			creatorStreams.GET("/my-streams", streamService.GetMyStreams)
		}

		// Viewer interactions
		streams.POST("/:id/join", streamService.JoinStream)
		streams.POST("/:id/leave", streamService.LeaveStream)
		streams.POST("/:id/react", streamService.ReactToStream)
		streams.GET("/:id/viewers", streamService.GetStreamViewers)
		streams.POST("/:id/report", streamService.ReportStream)
	}

	// WebRTC signaling routes
	webrtc := r.Group("/webrtc")
	webrtc.Use(middleware.AuthMiddleware())
	{
		webrtc.POST("/offer", webrtcService.HandleOffer)
		webrtc.POST("/answer", webrtcService.HandleAnswer)
		webrtc.POST("/ice-candidate", webrtcService.HandleICECandidate)
		webrtc.GET("/turn-credentials", webrtcService.GetTURNCredentials)
		webrtc.POST("/start-broadcast", middleware.RequireRole("creator", "admin"), webrtcService.StartBroadcast)
		webrtc.POST("/stop-broadcast", middleware.RequireRole("creator", "admin"), webrtcService.StopBroadcast)
		webrtc.GET("/broadcast-status/:streamId", webrtcService.GetBroadcastStatus)
	}

	// Chat routes
	chat := r.Group("/chat")
	chat.Use(middleware.AuthMiddleware())
	{
		chat.GET("/:streamId/messages", chatService.GetChatMessages)
		chat.POST("/:streamId/send", chatService.SendChatMessage)
		chat.DELETE("/messages/:messageId", chatService.DeleteChatMessage)
		chat.POST("/messages/:messageId/react", chatService.ReactToChatMessage)
		
		// Moderator chat controls
		modChat := chat.Group("")
		modChat.Use(middleware.RequireRole("creator", "admin"))
		{
			modChat.POST("/:streamId/mute/:userId", chatService.MuteUser)
			modChat.POST("/:streamId/unmute/:userId", chatService.UnmuteUser)
			modChat.POST("/:streamId/ban/:userId", chatService.BanUser)
			modChat.POST("/:streamId/unban/:userId", chatService.UnbanUser)
			modChat.PUT("/:streamId/slow-mode", chatService.SetSlowMode)
			modChat.PUT("/:streamId/subscribers-only", chatService.SetSubscribersOnly)
		}
	}

	// Recording routes
	recordings := r.Group("/recordings")
	recordings.Use(middleware.AuthMiddleware())
	{
		recordings.GET("", recordingService.GetRecordings)
		recordings.GET("/:id", recordingService.GetRecording)
		recordings.GET("/:id/download", recordingService.DownloadRecording)
		
		// Creator recording management
		creatorRecordings := recordings.Group("")
		creatorRecordings.Use(middleware.RequireRole("creator", "admin"))
		{
			creatorRecordings.POST("/:streamId/start", recordingService.StartRecording)
			creatorRecordings.POST("/:recordingId/stop", recordingService.StopRecording)
			creatorRecordings.DELETE("/:id", recordingService.DeleteRecording)
			creatorRecordings.PUT("/:id/privacy", recordingService.UpdateRecordingPrivacy)
			creatorRecordings.POST("/:id/publish", recordingService.PublishRecording)
		}
	}

	// Analytics routes
	analytics := r.Group("/analytics")
	analytics.Use(middleware.AuthMiddleware())
	analytics.Use(middleware.RequireRole("creator", "admin"))
	{
		analytics.GET("/streams/:id", analyticsService.GetStreamAnalytics)
		analytics.GET("/creator/performance", analyticsService.GetCreatorStreamingAnalytics)
		analytics.GET("/revenue", analyticsService.GetStreamingRevenue)
		analytics.GET("/audience", analyticsService.GetAudienceAnalytics)
		analytics.GET("/engagement", analyticsService.GetEngagementMetrics)
		analytics.GET("/geographic", analyticsService.GetGeographicAnalytics)
	}

	// Real-time features
	realtime := r.Group("/realtime")
	{
		// WebSocket endpoint for chat and real-time updates
		realtime.GET("/ws/:streamId", middleware.AuthMiddleware(), func(c *gin.Context) {
			streamID := c.Param("streamId")
			userID, _, err := middleware.GetUserFromContext(c)
			if err != nil {
				utils.UnauthorizedError(c, "Authentication required")
				return
			}
			
			hub.HandleWebSocket(c, streamID, userID)
		})

		// Server-sent events for real-time updates
		realtime.GET("/events/:streamId", middleware.AuthMiddleware(), streamService.StreamEvents)
		
		// Real-time viewer count
		realtime.GET("/viewer-count/:streamId", streamService.GetRealtimeViewerCount)
	}

	// Stream discovery and search
	discovery := r.Group("/discovery")
	{
		discovery.GET("/trending", middleware.OptionalAuth(), streamService.GetTrendingStreams)
		discovery.GET("/categories", streamService.GetStreamCategories)
		discovery.GET("/search", middleware.OptionalAuth(), streamService.SearchStreams)
		discovery.GET("/recommendations", middleware.AuthMiddleware(), streamService.GetStreamRecommendations)
		discovery.GET("/schedule", streamService.GetStreamSchedule)
	}

	// Stream quality and technical routes
	quality := r.Group("/quality")
	quality.Use(middleware.AuthMiddleware())
	{
		quality.GET("/:streamId/stats", streamService.GetStreamQualityStats)
		quality.POST("/:streamId/quality", streamService.ChangeStreamQuality)
		quality.GET("/adaptive-bitrates", streamService.GetAdaptiveBitrates)
		quality.POST("/report-issue", streamService.ReportQualityIssue)
	}

	// Admin streaming management
	admin := r.Group("/admin")
	admin.Use(middleware.AuthMiddleware())
	admin.Use(middleware.RequireRole("admin"))
	{
		admin.GET("/streams", streamService.GetAllStreams)
		admin.GET("/streams/flagged", streamService.GetFlaggedStreams)
		admin.PUT("/streams/:id/moderate", streamService.ModerateStream)
		admin.POST("/streams/:id/force-end", streamService.ForceEndStream)
		admin.GET("/streaming-analytics", analyticsService.GetPlatformStreamingAnalytics)
		admin.GET("/bandwidth-usage", analyticsService.GetBandwidthUsage)
		admin.GET("/server-health", streamService.GetStreamingServerHealth)
	}

	// Monetization routes
	monetization := r.Group("/monetization")
	monetization.Use(middleware.AuthMiddleware())
	{
		monetization.GET("/:streamId/donations", streamService.GetStreamDonations)
		monetization.POST("/:streamId/donate", streamService.DonateToStream)
		monetization.GET("/:streamId/subscribers", middleware.RequireRole("creator", "admin"), streamService.GetStreamSubscribers)
		monetization.PUT("/:streamId/pricing", middleware.RequireRole("creator", "admin"), streamService.UpdateStreamPricing)
		monetization.GET("/revenue-stats", middleware.RequireRole("creator", "admin"), analyticsService.GetStreamingRevenue)
	}

	// Notifications and alerts
	notifications := r.Group("/notifications")
	notifications.Use(middleware.AuthMiddleware())
	{
		notifications.POST("/stream-start", middleware.RequireRole("creator", "admin"), streamService.NotifyStreamStart)
		notifications.GET("/followers", streamService.GetFollowerNotifications)
		notifications.PUT("/preferences", streamService.UpdateNotificationPreferences)
	}
}

// healthCheck returns the health status of the Streaming Service
func healthCheck(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"status":    "healthy",
		"service":   "streaming-service",
		"timestamp": time.Now().Unix(),
	})
}

// rootHandler returns service information
func rootHandler(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"name":        "Fanz OS Streaming Service",
		"version":     "1.0.0",
		"description": "Live streaming, WebRTC, chat, and real-time engagement",
		"endpoints": gin.H{
			"health":       "/health",
			"streams":      "/streams",
			"webrtc":       "/webrtc",
			"chat":         "/chat",
			"recordings":   "/recordings",
			"analytics":    "/analytics",
			"realtime":     "/realtime",
			"discovery":    "/discovery",
		},
	})
}