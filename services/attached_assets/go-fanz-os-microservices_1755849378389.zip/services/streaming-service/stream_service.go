package main

import (
	"database/sql"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/shopspring/decimal"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// StreamService handles live stream operations
type StreamService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewStreamService creates a new stream service instance
func NewStreamService(db *database.DB, redis *cache.RedisClient) *StreamService {
	return &StreamService{
		db:    db,
		redis: redis,
	}
}

// CreateStream creates a new live stream
func (s *StreamService) CreateStream(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	var req models.CreateStreamRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Validate required fields
	if strings.TrimSpace(req.Title) == "" {
		utils.BadRequestError(c, "Stream title is required")
		return
	}

	// Check if user already has an active stream
	hasActiveStream, err := s.hasActiveStream(userID)
	if err != nil {
		utils.InternalServerError(c, "Failed to check active streams")
		return
	}
	if hasActiveStream {
		utils.ConflictError(c, "You already have an active stream")
		return
	}

	// Create stream
	streamID := uuid.New().String()
	streamKey := generateStreamKey()
	now := time.Now()

	query := `
		INSERT INTO live_streams (
			id, creator_id, title, description, category, tags, thumbnail_url,
			stream_key, status, is_public, allow_chat, subscriber_only,
			max_viewers, price, scheduled_start, created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
	`

	_, err = s.db.Exec(query,
		streamID, userID, req.Title, req.Description, req.Category, req.Tags,
		req.ThumbnailURL, streamKey, models.StreamStatusScheduled, req.IsPublic,
		req.AllowChat, req.SubscriberOnly, req.MaxViewers, req.Price,
		req.ScheduledStart, now, now,
	)

	if err != nil {
		utils.InternalServerError(c, "Failed to create stream")
		return
	}

	// Get created stream
	stream, err := s.getStreamByID(streamID)
	if err != nil {
		utils.InternalServerError(c, "Failed to retrieve created stream")
		return
	}

	utils.CreatedResponse(c, stream)
}

// GetStreams gets streams with pagination and filtering
func (s *StreamService) GetStreams(c *gin.Context) {
	// Get query parameters
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	limit, _ := strconv.Atoi(c.DefaultQuery("limit", "20"))
	status := c.Query("status")
	category := c.Query("category")
	creatorID := c.Query("creator_id")

	// Validate pagination
	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 50 {
		limit = 20
	}

	offset := (page - 1) * limit

	// Build query
	whereClause := []string{"is_public = true"}
	args := []interface{}{}
	argIndex := 1

	// Filter by status (default to live streams for public viewing)
	if status != "" {
		whereClause = append(whereClause, fmt.Sprintf("status = $%d", argIndex))
		args = append(args, status)
		argIndex++
	} else {
		// Default to live streams
		whereClause = append(whereClause, fmt.Sprintf("status = $%d", argIndex))
		args = append(args, models.StreamStatusLive)
		argIndex++
	}

	// Filter by category
	if category != "" {
		whereClause = append(whereClause, fmt.Sprintf("category = $%d", argIndex))
		args = append(args, category)
		argIndex++
	}

	// Filter by creator
	if creatorID != "" {
		whereClause = append(whereClause, fmt.Sprintf("creator_id = $%d", argIndex))
		args = append(args, creatorID)
		argIndex++
	}

	// Get total count
	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM live_streams WHERE %s", strings.Join(whereClause, " AND "))
	var total int
	err := s.db.QueryRow(countQuery, args...).Scan(&total)
	if err != nil {
		utils.InternalServerError(c, "Failed to count streams")
		return
	}

	// Get streams
	query := fmt.Sprintf(`
		SELECT id, creator_id, title, description, category, tags, thumbnail_url,
			   status, is_public, allow_chat, subscriber_only, max_viewers, price,
			   viewer_count, total_views, likes_count, scheduled_start, started_at,
			   ended_at, created_at, updated_at
		FROM live_streams 
		WHERE %s
		ORDER BY viewer_count DESC, started_at DESC
		LIMIT $%d OFFSET $%d
	`, strings.Join(whereClause, " AND "), argIndex, argIndex+1)

	args = append(args, limit, offset)

	rows, err := s.db.Query(query, args...)
	if err != nil {
		utils.InternalServerError(c, "Failed to get streams")
		return
	}
	defer rows.Close()

	var streams []models.LiveStream
	for rows.Next() {
		var stream models.LiveStream
		err := rows.Scan(
			&stream.ID, &stream.CreatorID, &stream.Title, &stream.Description,
			&stream.Category, &stream.Tags, &stream.ThumbnailURL, &stream.Status,
			&stream.IsPublic, &stream.AllowChat, &stream.SubscriberOnly,
			&stream.MaxViewers, &stream.Price, &stream.ViewerCount, &stream.TotalViews,
			&stream.LikesCount, &stream.ScheduledStart, &stream.StartedAt,
			&stream.EndedAt, &stream.CreatedAt, &stream.UpdatedAt,
		)
		if err != nil {
			continue
		}

		// Hide stream key for security
		stream.StreamKey = nil

		streams = append(streams, stream)
	}

	// Calculate pagination metadata
	totalPages := (total + limit - 1) / limit
	meta := &utils.Meta{
		Page:       page,
		Limit:      limit,
		Total:      total,
		TotalPages: totalPages,
	}

	utils.SuccessResponseWithMeta(c, streams, meta)
}

// GetStream gets a specific stream by ID
func (s *StreamService) GetStream(c *gin.Context) {
	streamID := c.Param("id")
	if streamID == "" {
		utils.BadRequestError(c, "Stream ID is required")
		return
	}

	stream, err := s.getStreamByID(streamID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Stream not found")
		} else {
			utils.InternalServerError(c, "Failed to get stream")
		}
		return
	}

	// Check access permissions
	userID, _, _ := middleware.GetUserFromContext(c)
	if !stream.IsPublic && userID != stream.CreatorID {
		utils.ForbiddenError(c, "This stream is private")
		return
	}

	// Hide stream key unless user is the creator
	if userID != stream.CreatorID {
		stream.StreamKey = nil
	}

	utils.SuccessResponse(c, stream)
}

// StartStream starts a live stream
func (s *StreamService) StartStream(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	streamID := c.Param("id")
	if streamID == "" {
		utils.BadRequestError(c, "Stream ID is required")
		return
	}

	// Get stream and verify ownership
	stream, err := s.getStreamByID(streamID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Stream not found")
		} else {
			utils.InternalServerError(c, "Failed to get stream")
		}
		return
	}

	if stream.CreatorID != userID {
		utils.ForbiddenError(c, "You can only start your own streams")
		return
	}

	if stream.Status == models.StreamStatusLive {
		utils.ConflictError(c, "Stream is already live")
		return
	}

	// Start the stream
	now := time.Now()
	_, err = s.db.Exec(`
		UPDATE live_streams 
		SET status = $1, started_at = $2, updated_at = $3
		WHERE id = $4
	`, models.StreamStatusLive, now, now, streamID)

	if err != nil {
		utils.InternalServerError(c, "Failed to start stream")
		return
	}

	// TODO: Notify followers about stream start
	// TODO: Initialize WebRTC connection

	utils.SuccessResponse(c, gin.H{
		"message":    "Stream started successfully",
		"stream_id":  streamID,
		"started_at": now,
		"stream_url": fmt.Sprintf("rtmp://streaming-server/live/%s", *stream.StreamKey),
	})
}

// EndStream ends a live stream
func (s *StreamService) EndStream(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	streamID := c.Param("id")
	if streamID == "" {
		utils.BadRequestError(c, "Stream ID is required")
		return
	}

	// Get stream and verify ownership
	stream, err := s.getStreamByID(streamID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Stream not found")
		} else {
			utils.InternalServerError(c, "Failed to get stream")
		}
		return
	}

	if stream.CreatorID != userID {
		utils.ForbiddenError(c, "You can only end your own streams")
		return
	}

	if stream.Status != models.StreamStatusLive {
		utils.ConflictError(c, "Stream is not currently live")
		return
	}

	// End the stream
	now := time.Now()
	_, err = s.db.Exec(`
		UPDATE live_streams 
		SET status = $1, ended_at = $2, updated_at = $3
		WHERE id = $4
	`, models.StreamStatusEnded, now, now, streamID)

	if err != nil {
		utils.InternalServerError(c, "Failed to end stream")
		return
	}

	// TODO: Stop WebRTC connections
	// TODO: Save stream analytics

	utils.SuccessResponse(c, gin.H{
		"message":  "Stream ended successfully",
		"stream_id": streamID,
		"ended_at":  now,
	})
}

// JoinStream allows a viewer to join a stream
func (s *StreamService) JoinStream(c *gin.Context) {
	userID, _, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "User not found in context")
		return
	}

	streamID := c.Param("id")
	if streamID == "" {
		utils.BadRequestError(c, "Stream ID is required")
		return
	}

	// Get stream
	stream, err := s.getStreamByID(streamID)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.NotFoundError(c, "Stream not found")
		} else {
			utils.InternalServerError(c, "Failed to get stream")
		}
		return
	}

	if stream.Status != models.StreamStatusLive {
		utils.BadRequestError(c, "Stream is not currently live")
		return
	}

	// Check if stream requires subscription
	if stream.SubscriberOnly {
		isSubscribed, err := s.isSubscribedToCreator(userID, stream.CreatorID)
		if err != nil {
			utils.InternalServerError(c, "Failed to check subscription status")
			return
		}
		if !isSubscribed {
			utils.ForbiddenError(c, "This stream is for subscribers only")
			return
		}
	}

	// Record viewer join
	viewID := uuid.New().String()
	_, err = s.db.Exec(`
		INSERT INTO stream_views (id, user_id, stream_id, joined_at, created_at)
		VALUES ($1, $2, $3, $4, $5)
		ON CONFLICT (user_id, stream_id) DO UPDATE SET
		joined_at = $4, left_at = NULL
	`, viewID, userID, streamID, time.Now(), time.Now())

	if err != nil {
		utils.InternalServerError(c, "Failed to join stream")
		return
	}

	// Increment viewer count
	s.db.Exec(`
		UPDATE live_streams 
		SET viewer_count = viewer_count + 1, total_views = total_views + 1 
		WHERE id = $1
	`, streamID)

	utils.SuccessResponse(c, gin.H{
		"message":   "Successfully joined stream",
		"stream_id": streamID,
		"view_id":   viewID,
	})
}

// Helper functions

func (s *StreamService) getStreamByID(streamID string) (*models.LiveStream, error) {
	var stream models.LiveStream
	err := s.db.QueryRow(`
		SELECT id, creator_id, title, description, category, tags, thumbnail_url,
			   stream_key, status, is_public, allow_chat, subscriber_only, max_viewers,
			   price, viewer_count, total_views, likes_count, scheduled_start,
			   started_at, ended_at, created_at, updated_at
		FROM live_streams WHERE id = $1
	`, streamID).Scan(
		&stream.ID, &stream.CreatorID, &stream.Title, &stream.Description,
		&stream.Category, &stream.Tags, &stream.ThumbnailURL, &stream.StreamKey,
		&stream.Status, &stream.IsPublic, &stream.AllowChat, &stream.SubscriberOnly,
		&stream.MaxViewers, &stream.Price, &stream.ViewerCount, &stream.TotalViews,
		&stream.LikesCount, &stream.ScheduledStart, &stream.StartedAt,
		&stream.EndedAt, &stream.CreatedAt, &stream.UpdatedAt,
	)
	return &stream, err
}

func (s *StreamService) hasActiveStream(userID string) (bool, error) {
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM live_streams 
		WHERE creator_id = $1 AND status IN ($2, $3)
	`, userID, models.StreamStatusLive, models.StreamStatusScheduled).Scan(&count)
	return count > 0, err
}

func (s *StreamService) isSubscribedToCreator(fanID, creatorID string) (bool, error) {
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM subscriptions 
		WHERE fan_id = $1 AND creator_id = $2 AND is_active = true AND end_date > $3
	`, fanID, creatorID, time.Now()).Scan(&count)
	return count > 0, err
}

func generateStreamKey() string {
	return uuid.New().String()
}

// Placeholder implementations for remaining methods
func (s *StreamService) UpdateStream(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Update stream not yet implemented")
}

func (s *StreamService) DeleteStream(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Delete stream not yet implemented")
}

func (s *StreamService) UpdateStreamSettings(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Update stream settings not yet implemented")
}

func (s *StreamService) GetMyStreams(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get my streams not yet implemented")
}

func (s *StreamService) GetLiveStreams(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get live streams not yet implemented")
}

func (s *StreamService) GetFeaturedStreams(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get featured streams not yet implemented")
}

func (s *StreamService) LeaveStream(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Leave stream not yet implemented")
}

func (s *StreamService) ReactToStream(c *gin.Context) {
	utils.ServiceUnavailableError(c, "React to stream not yet implemented")
}

func (s *StreamService) GetStreamViewers(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get stream viewers not yet implemented")
}

func (s *StreamService) ReportStream(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Report stream not yet implemented")
}

func (s *StreamService) StreamEvents(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Stream events not yet implemented")
}

func (s *StreamService) GetRealtimeViewerCount(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get realtime viewer count not yet implemented")
}

func (s *StreamService) GetTrendingStreams(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get trending streams not yet implemented")
}

func (s *StreamService) GetStreamCategories(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get stream categories not yet implemented")
}

func (s *StreamService) SearchStreams(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Search streams not yet implemented")
}

func (s *StreamService) GetStreamRecommendations(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get stream recommendations not yet implemented")
}

func (s *StreamService) GetStreamSchedule(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get stream schedule not yet implemented")
}

func (s *StreamService) GetStreamQualityStats(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get stream quality stats not yet implemented")
}

func (s *StreamService) ChangeStreamQuality(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Change stream quality not yet implemented")
}

func (s *StreamService) GetAdaptiveBitrates(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get adaptive bitrates not yet implemented")
}

func (s *StreamService) ReportQualityIssue(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Report quality issue not yet implemented")
}

func (s *StreamService) GetAllStreams(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get all streams not yet implemented")
}

func (s *StreamService) GetFlaggedStreams(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get flagged streams not yet implemented")
}

func (s *StreamService) ModerateStream(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Moderate stream not yet implemented")
}

func (s *StreamService) ForceEndStream(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Force end stream not yet implemented")
}

func (s *StreamService) GetStreamingServerHealth(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get streaming server health not yet implemented")
}

func (s *StreamService) GetStreamDonations(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get stream donations not yet implemented")
}

func (s *StreamService) DonateToStream(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Donate to stream not yet implemented")
}

func (s *StreamService) GetStreamSubscribers(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get stream subscribers not yet implemented")
}

func (s *StreamService) UpdateStreamPricing(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Update stream pricing not yet implemented")
}

func (s *StreamService) NotifyStreamStart(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Notify stream start not yet implemented")
}

func (s *StreamService) GetFollowerNotifications(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Get follower notifications not yet implemented")
}

func (s *StreamService) UpdateNotificationPreferences(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Update notification preferences not yet implemented")
}