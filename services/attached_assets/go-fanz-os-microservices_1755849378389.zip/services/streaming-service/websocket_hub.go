package main

import (
        "encoding/json"
        "log"
        "net/http"
        "sync"
        "time"

        "github.com/gin-gonic/gin"
        "github.com/gorilla/websocket"
)

// WebSocketHub manages all WebSocket connections
type WebSocketHub struct {
        // Registered clients by stream ID
        clients map[string]map[*Client]bool
        
        // Register requests from clients
        register chan *Client
        
        // Unregister requests from clients
        unregister chan *Client
        
        // Broadcast messages to all clients in a stream
        broadcast chan *BroadcastMessage
        
        // Mutex for thread-safe operations
        mutex sync.RWMutex
}

// Client represents a WebSocket client
type Client struct {
        // The WebSocket connection
        conn *websocket.Conn
        
        // User ID of the connected user
        userID string
        
        // Stream ID the user is connected to
        streamID string
        
        // Buffered channel of outbound messages
        send chan []byte
        
        // Hub reference
        hub *WebSocketHub
}

// BroadcastMessage represents a message to broadcast
type BroadcastMessage struct {
        StreamID string      `json:"stream_id"`
        Type     string      `json:"type"`
        Data     interface{} `json:"data"`
        UserID   string      `json:"user_id,omitempty"`
}

// WebSocket upgrader
var upgrader = websocket.Upgrader{
        ReadBufferSize:  1024,
        WriteBufferSize: 1024,
        CheckOrigin: func(r *http.Request) bool {
                // Allow all origins in development
                // In production, implement proper origin checking
                return true
        },
}

// NewWebSocketHub creates a new WebSocket hub
func NewWebSocketHub() *WebSocketHub {
        return &WebSocketHub{
                clients:    make(map[string]map[*Client]bool),
                register:   make(chan *Client),
                unregister: make(chan *Client),
                broadcast:  make(chan *BroadcastMessage),
        }
}

// Run starts the WebSocket hub
func (h *WebSocketHub) Run() {
        for {
                select {
                case client := <-h.register:
                        h.registerClient(client)
                        
                case client := <-h.unregister:
                        h.unregisterClient(client)
                        
                case message := <-h.broadcast:
                        h.broadcastToStream(message)
                }
        }
}

// registerClient registers a new client
func (h *WebSocketHub) registerClient(client *Client) {
        h.mutex.Lock()
        defer h.mutex.Unlock()
        
        if h.clients[client.streamID] == nil {
                h.clients[client.streamID] = make(map[*Client]bool)
        }
        
        h.clients[client.streamID][client] = true
        
        log.Printf("User %s connected to stream %s", client.userID, client.streamID)
        
        // Notify stream about new viewer
        h.broadcastToStreamNoLock(&BroadcastMessage{
                StreamID: client.streamID,
                Type:     "viewer_joined",
                Data: map[string]interface{}{
                        "user_id":      client.userID,
                        "viewer_count": len(h.clients[client.streamID]),
                },
        })
}

// unregisterClient unregisters a client
func (h *WebSocketHub) unregisterClient(client *Client) {
        h.mutex.Lock()
        defer h.mutex.Unlock()
        
        if clients, ok := h.clients[client.streamID]; ok {
                if _, ok := clients[client]; ok {
                        delete(clients, client)
                        close(client.send)
                        
                        log.Printf("User %s disconnected from stream %s", client.userID, client.streamID)
                        
                        // Clean up empty stream
                        if len(clients) == 0 {
                                delete(h.clients, client.streamID)
                        } else {
                                // Notify stream about viewer leaving
                                h.broadcastToStreamNoLock(&BroadcastMessage{
                                        StreamID: client.streamID,
                                        Type:     "viewer_left",
                                        Data: map[string]interface{}{
                                                "user_id":      client.userID,
                                                "viewer_count": len(clients),
                                        },
                                })
                        }
                }
        }
}

// broadcastToStream broadcasts a message to all clients in a stream
func (h *WebSocketHub) broadcastToStream(message *BroadcastMessage) {
        h.mutex.RLock()
        defer h.mutex.RUnlock()
        h.broadcastToStreamNoLock(message)
}

// broadcastToStreamNoLock broadcasts without acquiring lock (assumes caller has lock)
func (h *WebSocketHub) broadcastToStreamNoLock(message *BroadcastMessage) {
        clients, ok := h.clients[message.StreamID]
        if !ok {
                return
        }
        
        data, err := json.Marshal(message)
        if err != nil {
                log.Printf("Error marshaling broadcast message: %v", err)
                return
        }
        
        for client := range clients {
                select {
                case client.send <- data:
                default:
                        // Client's send channel is full, remove it
                        delete(clients, client)
                        close(client.send)
                }
        }
}

// HandleWebSocket handles WebSocket connections
func (h *WebSocketHub) HandleWebSocket(c *gin.Context, streamID, userID string) {
        conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
        if err != nil {
                log.Printf("WebSocket upgrade error: %v", err)
                return
        }
        
        client := &Client{
                conn:     conn,
                userID:   userID,
                streamID: streamID,
                send:     make(chan []byte, 256),
                hub:      h,
        }
        
        // Register the client
        h.register <- client
        
        // Start goroutines for reading and writing
        go client.writePump()
        go client.readPump()
}

// BroadcastToStream sends a message to all clients in a stream
func (h *WebSocketHub) BroadcastToStream(streamID, messageType string, data interface{}) {
        message := &BroadcastMessage{
                StreamID: streamID,
                Type:     messageType,
                Data:     data,
        }
        
        select {
        case h.broadcast <- message:
        default:
                log.Printf("Broadcast channel full, dropping message")
        }
}

// GetViewerCount gets the number of viewers in a stream
func (h *WebSocketHub) GetViewerCount(streamID string) int {
        h.mutex.RLock()
        defer h.mutex.RUnlock()
        
        if clients, ok := h.clients[streamID]; ok {
                return len(clients)
        }
        return 0
}

// readPump pumps messages from the WebSocket connection to the hub
func (c *Client) readPump() {
        defer func() {
                c.hub.unregister <- c
                c.conn.Close()
        }()
        
        // Set read limits and deadlines
        c.conn.SetReadLimit(512)
        
        for {
                var message map[string]interface{}
                err := c.conn.ReadJSON(&message)
                if err != nil {
                        if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
                                log.Printf("WebSocket error: %v", err)
                        }
                        break
                }
                
                // Handle incoming messages
                c.handleMessage(message)
        }
}

// writePump pumps messages from the hub to the WebSocket connection
func (c *Client) writePump() {
        defer c.conn.Close()
        
        for {
                select {
                case message, ok := <-c.send:
                        if !ok {
                                // Hub closed the channel
                                c.conn.WriteMessage(websocket.CloseMessage, []byte{})
                                return
                        }
                        
                        if err := c.conn.WriteMessage(websocket.TextMessage, message); err != nil {
                                log.Printf("WebSocket write error: %v", err)
                                return
                        }
                }
        }
}

// handleMessage processes incoming WebSocket messages
func (c *Client) handleMessage(message map[string]interface{}) {
        messageType, ok := message["type"].(string)
        if !ok {
                return
        }
        
        switch messageType {
        case "chat_message":
                // Handle chat message
                if content, ok := message["content"].(string); ok {
                        c.handleChatMessage(content)
                }
        case "reaction":
                // Handle stream reaction
                if reaction, ok := message["reaction"].(string); ok {
                        c.handleReaction(reaction)
                }
        case "ping":
                // Handle ping for connection keepalive
                c.sendMessage("pong", map[string]interface{}{
                        "timestamp": message["timestamp"],
                })
        default:
                log.Printf("Unknown message type: %s", messageType)
        }
}

// handleChatMessage processes chat messages
func (c *Client) handleChatMessage(content string) {
        // TODO: Save chat message to database
        // TODO: Apply chat moderation
        
        // Broadcast chat message to all stream viewers
        c.hub.BroadcastToStream(c.streamID, "chat_message", map[string]interface{}{
                "user_id":   c.userID,
                "content":   content,
                "timestamp": time.Now().Unix(),
        })
}

// handleReaction processes stream reactions
func (c *Client) handleReaction(reaction string) {
        // TODO: Save reaction to database
        
        // Broadcast reaction to all stream viewers
        c.hub.BroadcastToStream(c.streamID, "reaction", map[string]interface{}{
                "user_id":  c.userID,
                "reaction": reaction,
                "timestamp": time.Now().Unix(),
        })
}

// sendMessage sends a message to the client
func (c *Client) sendMessage(messageType string, data interface{}) {
        message := map[string]interface{}{
                "type": messageType,
                "data": data,
        }
        
        jsonData, err := json.Marshal(message)
        if err != nil {
                log.Printf("Error marshaling message: %v", err)
                return
        }
        
        select {
        case c.send <- jsonData:
        default:
                // Send channel is full, close the client
                close(c.send)
        }
}