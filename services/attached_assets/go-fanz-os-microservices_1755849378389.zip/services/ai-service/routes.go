package main

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/utils"
)

// setupRoutes configures all AI Service routes
func setupRoutes(
	r *gin.Engine,
	moderationService *ModerationService,
	recommendationService *RecommendationService,
	contentAnalysisService *ContentAnalysisService,
	personalizationService *PersonalizationService,
	insightsService *InsightsService,
	chatbotService *ChatbotService,
) {
	// Health check
	r.GET("/health", healthCheck)
	r.GET("/", rootHandler)

	// Content moderation routes (internal microservice calls)
	moderation := r.Group("/moderation")
	{
		// Image and video analysis
		moderation.POST("/analyze/image", moderationService.AnalyzeImage)
		moderation.POST("/analyze/video", moderationService.AnalyzeVideo)
		moderation.POST("/analyze/audio", moderationService.AnalyzeAudio)
		moderation.POST("/analyze/text", moderationService.AnalyzeText)
		
		// Batch processing
		moderation.POST("/batch/analyze", moderationService.BatchAnalyze)
		moderation.GET("/batch/:id/status", moderationService.GetBatchStatus)
		moderation.GET("/batch/:id/results", moderationService.GetBatchResults)
		
		// Content classification
		moderation.POST("/classify/content", moderationService.ClassifyContent)
		moderation.POST("/detect/nsfw", moderationService.DetectNSFW)
		moderation.POST("/detect/age-verification", moderationService.DetectAgeVerification)
		moderation.POST("/detect/violence", moderationService.DetectViolence)
		moderation.POST("/detect/spam", moderationService.DetectSpam)
		
		// Content fingerprinting for duplicate detection
		moderation.POST("/fingerprint/generate", moderationService.GenerateContentFingerprint)
		moderation.POST("/fingerprint/match", moderationService.MatchContentFingerprint)
		
		// Model training and feedback
		moderation.POST("/feedback", moderationService.SubmitModerationFeedback)
		moderation.GET("/model/stats", moderationService.GetModelStats)
		moderation.POST("/model/retrain", middleware.RequireRole("admin"), moderationService.RetrainModel)
	}

	// Recommendation engine routes
	recommendations := r.Group("/recommendations")
	recommendations.Use(middleware.AuthMiddleware())
	{
		// User-specific recommendations
		recommendations.GET("/content", recommendationService.GetContentRecommendations)
		recommendations.GET("/creators", recommendationService.GetCreatorRecommendations)
		recommendations.GET("/similar-users", recommendationService.GetSimilarUsers)
		recommendations.GET("/trending", recommendationService.GetTrendingContent)
		
		// Creator-specific recommendations
		creator := recommendations.Group("/creator")
		creator.Use(middleware.RequireRole("creator", "admin"))
		{
			creator.GET("/content-ideas", recommendationService.GetContentIdeas)
			creator.GET("/optimal-posting-times", recommendationService.GetOptimalPostingTimes)
			creator.GET("/hashtag-suggestions", recommendationService.GetHashtagSuggestions)
			creator.GET("/pricing-suggestions", recommendationService.GetPricingSuggestions)
			creator.GET("/fan-segments", recommendationService.GetFanSegments)
		}
		
		// Feedback and learning
		recommendations.POST("/feedback/like", recommendationService.RecordLikeFeedback)
		recommendations.POST("/feedback/dislike", recommendationService.RecordDislikeFeedback)
		recommendations.POST("/feedback/view", recommendationService.RecordViewFeedback)
		recommendations.POST("/feedback/purchase", recommendationService.RecordPurchaseFeedback)
	}

	// Content analysis and insights
	analysis := r.Group("/analysis")
	{
		// Content performance analysis
		analysis.POST("/performance/content", middleware.AuthMiddleware(), contentAnalysisService.AnalyzeContentPerformance)
		analysis.POST("/performance/creator", middleware.AuthMiddleware(), contentAnalysisService.AnalyzeCreatorPerformance)
		analysis.POST("/performance/platform", middleware.RequireRole("admin"), contentAnalysisService.AnalyzePlatformPerformance)
		
		// Audience analysis
		analysis.POST("/audience/demographics", middleware.AuthMiddleware(), contentAnalysisService.AnalyzeAudienceDemographics)
		analysis.POST("/audience/behavior", middleware.AuthMiddleware(), contentAnalysisService.AnalyzeAudienceBehavior)
		analysis.POST("/audience/preferences", middleware.AuthMiddleware(), contentAnalysisService.AnalyzeAudiencePreferences)
		
		// Market analysis
		analysis.GET("/market/trends", middleware.AuthMiddleware(), contentAnalysisService.GetMarketTrends)
		analysis.GET("/market/opportunities", middleware.AuthMiddleware(), contentAnalysisService.GetMarketOpportunities)
		analysis.GET("/market/competitive", middleware.AuthMiddleware(), contentAnalysisService.GetCompetitiveAnalysis)
		
		// Content optimization
		analysis.POST("/optimize/title", middleware.AuthMiddleware(), contentAnalysisService.OptimizeTitle)
		analysis.POST("/optimize/description", middleware.AuthMiddleware(), contentAnalysisService.OptimizeDescription)
		analysis.POST("/optimize/tags", middleware.AuthMiddleware(), contentAnalysisService.OptimizeTags)
		analysis.POST("/optimize/thumbnail", middleware.AuthMiddleware(), contentAnalysisService.OptimizeThumbnail)
	}

	// Personalization engine
	personalization := r.Group("/personalization")
	personalization.Use(middleware.AuthMiddleware())
	{
		// User experience personalization
		personalization.GET("/feed", personalizationService.GetPersonalizedFeed)
		personalization.GET("/homepage", personalizationService.GetPersonalizedHomepage)
		personalization.GET("/search-results", personalizationService.GetPersonalizedSearchResults)
		personalization.PUT("/preferences", personalizationService.UpdateUserPreferences)
		personalization.GET("/preferences", personalizationService.GetUserPreferences)
		
		// Dynamic pricing
		personalization.GET("/pricing/:contentId", personalizationService.GetPersonalizedPricing)
		personalization.POST("/pricing/experiment", middleware.RequireRole("creator", "admin"), personalizationService.CreatePricingExperiment)
		
		// A/B testing
		personalization.GET("/experiments", personalizationService.GetActiveExperiments)
		personalization.POST("/experiments/:id/participate", personalizationService.ParticipateInExperiment)
		personalization.POST("/experiments/:id/convert", personalizationService.RecordExperimentConversion)
		
		// User segmentation
		personalization.GET("/segment", personalizationService.GetUserSegment)
		personalization.GET("/segment/features", personalizationService.GetSegmentFeatures)
	}

	// AI-powered insights and analytics
	insights := r.Group("/insights")
	insights.Use(middleware.AuthMiddleware())
	{
		// Business intelligence
		insights.GET("/revenue/predictions", middleware.RequireRole("creator", "admin"), insightsService.GetRevenuePredictions)
		insights.GET("/growth/forecasts", middleware.RequireRole("creator", "admin"), insightsService.GetGrowthForecasts)
		insights.GET("/churn/predictions", middleware.RequireRole("creator", "admin"), insightsService.GetChurnPredictions)
		insights.GET("/lifetime-value", middleware.RequireRole("creator", "admin"), insightsService.GetLifetimeValuePredictions)
		
		// Content insights
		insights.GET("/content/viral-potential", middleware.RequireRole("creator", "admin"), insightsService.GetViralPotential)
		insights.GET("/content/engagement-forecast", middleware.RequireRole("creator", "admin"), insightsService.GetEngagementForecast)
		insights.GET("/content/optimal-schedule", middleware.RequireRole("creator", "admin"), insightsService.GetOptimalContentSchedule)
		
		// Market insights
		insights.GET("/market/sentiment", insightsService.GetMarketSentiment)
		insights.GET("/market/demand", insightsService.GetMarketDemand)
		insights.GET("/market/saturation", insightsService.GetMarketSaturation)
		
		// Anomaly detection
		insights.GET("/anomalies/revenue", middleware.RequireRole("creator", "admin"), insightsService.DetectRevenueAnomalies)
		insights.GET("/anomalies/engagement", middleware.RequireRole("creator", "admin"), insightsService.DetectEngagementAnomalies)
		insights.GET("/anomalies/user-behavior", middleware.RequireRole("admin"), insightsService.DetectUserBehaviorAnomalies)
	}

	// AI Chatbot and virtual assistant
	chatbot := r.Group("/chatbot")
	chatbot.Use(middleware.AuthMiddleware())
	{
		// Chat interface
		chatbot.POST("/chat", chatbotService.Chat)
		chatbot.GET("/conversations", chatbotService.GetConversations)
		chatbot.GET("/conversations/:id", chatbotService.GetConversation)
		chatbot.DELETE("/conversations/:id", chatbotService.DeleteConversation)
		
		// Virtual assistant capabilities
		chatbot.POST("/assistant/content-help", chatbotService.GetContentHelp)
		chatbot.POST("/assistant/marketing-advice", chatbotService.GetMarketingAdvice)
		chatbot.POST("/assistant/analytics-explanation", chatbotService.ExplainAnalytics)
		chatbot.POST("/assistant/platform-guidance", chatbotService.GetPlatformGuidance)
		
		// Automated responses
		chatbot.GET("/auto-responses", middleware.RequireRole("creator", "admin"), chatbotService.GetAutoResponses)
		chatbot.POST("/auto-responses", middleware.RequireRole("creator", "admin"), chatbotService.CreateAutoResponse)
		chatbot.PUT("/auto-responses/:id", middleware.RequireRole("creator", "admin"), chatbotService.UpdateAutoResponse)
		chatbot.DELETE("/auto-responses/:id", middleware.RequireRole("creator", "admin"), chatbotService.DeleteAutoResponse)
		
		// Chatbot training
		chatbot.POST("/training/feedback", chatbotService.SubmitChatbotFeedback)
		chatbot.GET("/training/stats", middleware.RequireRole("admin"), chatbotService.GetChatbotStats)
	}

	// Image and video enhancement
	enhancement := r.Group("/enhancement")
	enhancement.Use(middleware.AuthMiddleware())
	{
		// Image enhancement
		enhancement.POST("/image/upscale", contentAnalysisService.UpscaleImage)
		enhancement.POST("/image/denoise", contentAnalysisService.DenoiseImage)
		enhancement.POST("/image/enhance", contentAnalysisService.EnhanceImage)
		enhancement.POST("/image/background-remove", contentAnalysisService.RemoveBackground)
		enhancement.POST("/image/auto-crop", contentAnalysisService.AutoCropImage)
		
		// Video enhancement
		enhancement.POST("/video/stabilize", contentAnalysisService.StabilizeVideo)
		enhancement.POST("/video/enhance", contentAnalysisService.EnhanceVideo)
		enhancement.POST("/video/thumbnail-generate", contentAnalysisService.GenerateVideoThumbnail)
		enhancement.POST("/video/highlight-extract", contentAnalysisService.ExtractVideoHighlights)
		
		// Audio enhancement
		enhancement.POST("/audio/enhance", contentAnalysisService.EnhanceAudio)
		enhancement.POST("/audio/noise-reduce", contentAnalysisService.ReduceAudioNoise)
		enhancement.POST("/audio/transcribe", contentAnalysisService.TranscribeAudio)
	}

	// Smart automation
	automation := r.Group("/automation")
	automation.Use(middleware.AuthMiddleware())
	automation.Use(middleware.RequireRole("creator", "admin"))
	{
		// Content automation
		automation.POST("/content/auto-tag", contentAnalysisService.AutoTagContent)
		automation.POST("/content/auto-categorize", contentAnalysisService.AutoCategorizeContent)
		automation.POST("/content/auto-description", contentAnalysisService.GenerateContentDescription)
		automation.POST("/content/auto-title", contentAnalysisService.GenerateContentTitle)
		
		// Marketing automation
		automation.POST("/marketing/campaign-optimize", recommendationService.OptimizeMarketingCampaign)
		automation.POST("/marketing/audience-target", recommendationService.TargetAudience)
		automation.POST("/marketing/content-schedule", recommendationService.ScheduleContent)
		
		// Fan engagement automation
		automation.POST("/engagement/welcome-message", chatbotService.GenerateWelcomeMessage)
		automation.POST("/engagement/follow-up", chatbotService.GenerateFollowUpMessage)
		automation.POST("/engagement/retention-campaign", chatbotService.CreateRetentionCampaign)
	}

	// Admin AI management
	admin := r.Group("/admin")
	admin.Use(middleware.AuthMiddleware())
	admin.Use(middleware.RequireRole("admin"))
	{
		// Model management
		admin.GET("/models", moderationService.GetModelStatus)
		admin.POST("/models/:name/retrain", moderationService.RetrainModel)
		admin.PUT("/models/:name/deploy", moderationService.DeployModel)
		admin.GET("/models/:name/metrics", moderationService.GetModelMetrics)
		
		// AI performance monitoring
		admin.GET("/performance/overview", insightsService.GetAIPerformanceOverview)
		admin.GET("/performance/accuracy", insightsService.GetModelAccuracyStats)
		admin.GET("/performance/latency", insightsService.GetModelLatencyStats)
		admin.GET("/performance/usage", insightsService.GetAIUsageStats)
		
		// Training data management
		admin.GET("/training-data/stats", moderationService.GetTrainingDataStats)
		admin.POST("/training-data/export", moderationService.ExportTrainingData)
		admin.POST("/training-data/import", moderationService.ImportTrainingData)
		admin.DELETE("/training-data/cleanup", moderationService.CleanupTrainingData)
		
		// AI system configuration
		admin.GET("/config", insightsService.GetAIConfig)
		admin.PUT("/config", insightsService.UpdateAIConfig)
		admin.POST("/config/reset", insightsService.ResetAIConfig)
	}
}

// healthCheck returns the health status of the AI Service
func healthCheck(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"status":    "healthy",
		"service":   "ai-service",
		"timestamp": time.Now().Unix(),
	})
}

// rootHandler returns service information
func rootHandler(c *gin.Context) {
	utils.SuccessResponse(c, gin.H{
		"name":        "Fanz OS AI Service",
		"version":     "1.0.0",
		"description": "AI-powered content moderation, recommendations, and intelligent features",
		"endpoints": gin.H{
			"health":           "/health",
			"moderation":       "/moderation",
			"recommendations":  "/recommendations",
			"analysis":         "/analysis",
			"personalization":  "/personalization",
			"insights":         "/insights",
			"chatbot":          "/chatbot",
			"enhancement":      "/enhancement",
			"automation":       "/automation",
		},
	})
}