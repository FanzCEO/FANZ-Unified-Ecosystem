package main

import (
        "net/http"
        "time"

        "github.com/gin-gonic/gin"
        "github.com/fanz-os/shared/middleware"
        "github.com/fanz-os/shared/utils"
)

// setupRoutes configures all User Service routes
func setupRoutes(
        r *gin.Engine,
        userService *UserService,
        authService *AuthService,
        complianceService *ComplianceService,
        notificationService *NotificationService,
) {
        // Health check
        r.GET("/health", healthCheck)
        r.GET("/", rootHandler)

        // Authentication routes (no auth required)
        auth := r.Group("/auth")
        {
                auth.POST("/register", authService.Register)
                auth.POST("/login", authService.Login)
                auth.POST("/logout", authService.Logout)
                auth.POST("/refresh", authService.RefreshToken)
                auth.POST("/verify-email", authService.VerifyEmail)
                auth.POST("/verify-phone", authService.VerifyPhone)
                auth.POST("/forgot-password", authService.ForgotPassword)
                auth.POST("/reset-password", authService.ResetPassword)
                
                // 2FA endpoints (require authentication)
                twoFA := auth.Group("/2fa")
                twoFA.Use(middleware.AuthMiddleware())
                {
                        twoFA.POST("/setup", authService.Setup2FA)
                        twoFA.POST("/verify", authService.Verify2FA)
                        twoFA.DELETE("/disable", authService.Disable2FA)
                }
        }

        // User profile routes (authentication required)
        users := r.Group("/users")
        users.Use(middleware.AuthMiddleware())
        {
                users.GET("/profile", userService.GetProfile)
                users.PUT("/profile", userService.UpdateProfile)
                users.POST("/upload-avatar", userService.UploadAvatar)
                users.GET("/settings", userService.GetSettings)
                users.PUT("/settings", userService.UpdateSettings)
                
                // Social features
                users.POST("/follow/:userId", userService.FollowUser)
                users.DELETE("/follow/:userId", userService.UnfollowUser)
                users.GET("/followers", userService.GetFollowers)
                users.GET("/following", userService.GetFollowing)
                users.GET("/search", userService.SearchUsers)
                
                // Creator-specific routes
                creator := users.Group("/creator")
                creator.Use(middleware.RequireRole("creator", "admin"))
                {
                        creator.GET("/stats", userService.GetCreatorStats)
                        creator.GET("/earnings", userService.GetEarnings)
                        creator.PUT("/subscription-price", userService.UpdateSubscriptionPrice)
                        creator.GET("/subscribers", userService.GetSubscribers)
                        creator.GET("/performance", userService.GetPerformanceMetrics)
                }
        }

        // Compliance routes (creators and admins only)
        compliance := r.Group("/compliance")
        compliance.Use(middleware.AuthMiddleware())
        compliance.Use(middleware.RequireRole("creator", "admin"))
        {
                // 2257 Compliance
                compliance.POST("/2257", complianceService.Submit2257Record)
                compliance.GET("/2257", complianceService.Get2257Records)
                compliance.PUT("/2257/:id", complianceService.Update2257Record)
                
                // Co-star verification
                compliance.POST("/costar/invite", complianceService.CreateCostarInvitation)
                compliance.POST("/costar/verify", complianceService.VerifyCostar)
                compliance.GET("/costar/invitations", complianceService.GetCostarInvitations)
                
                // Document management
                compliance.GET("/documents", complianceService.GetDocuments)
                compliance.POST("/documents", complianceService.UploadDocument)
                compliance.DELETE("/documents/:id", complianceService.DeleteDocument)
                compliance.GET("/vault", complianceService.GetCreatorVault)
                
                // VerifyMy integration
                compliance.POST("/verify-my/start", complianceService.StartVerifyMySession)
                compliance.POST("/verify-my/callback", complianceService.HandleVerifyMyCallback)
                compliance.GET("/verify-my/status", complianceService.GetVerifyMyStatus)
        }

        // Notification routes
        notifications := r.Group("/notifications")
        notifications.Use(middleware.AuthMiddleware())
        {
                notifications.GET("", notificationService.GetNotifications)
                notifications.PUT("/:id/read", notificationService.MarkAsRead)
                notifications.PUT("/read-all", notificationService.MarkAllAsRead)
                notifications.POST("/push/subscribe", notificationService.SubscribeToPush)
                notifications.DELETE("/push/unsubscribe", notificationService.UnsubscribeFromPush)
                notifications.PUT("/preferences", notificationService.UpdatePreferences)
                notifications.GET("/preferences", notificationService.GetPreferences)
        }

        // Admin routes for user management (admins only)
        admin := r.Group("/admin/users")
        admin.Use(middleware.AuthMiddleware())
        admin.Use(middleware.RequireRole("admin"))
        {
                admin.GET("", userService.GetAllUsers)
                admin.GET("/:id", userService.GetUserByID)
                admin.PUT("/:id/status", userService.UpdateUserStatus)
                admin.PUT("/:id/role", userService.UpdateUserRole)
                admin.POST("/:id/suspend", userService.SuspendUser)
                admin.POST("/:id/unsuspend", userService.UnsuspendUser)
                admin.GET("/:id/audit-log", userService.GetUserAuditLog)
        }

        // OAuth callback routes
        oauth := r.Group("/oauth")
        {
                oauth.GET("/google/callback", authService.GoogleCallback)
                oauth.GET("/facebook/callback", authService.FacebookCallback)
                oauth.GET("/twitter/callback", authService.TwitterCallback)
                oauth.GET("/discord/callback", authService.DiscordCallback)
        }
}

// healthCheck returns the health status of the User Service
func healthCheck(c *gin.Context) {
        utils.SuccessResponse(c, gin.H{
                "status":    "healthy",
                "service":   "user-service",
                "timestamp": time.Now().Unix(),
        })
}

// rootHandler returns service information
func rootHandler(c *gin.Context) {
        utils.SuccessResponse(c, gin.H{
                "name":        "Fanz OS User Service",
                "version":     "1.0.0",
                "description": "User authentication, profiles, and compliance management",
                "endpoints": gin.H{
                        "health":       "/health",
                        "auth":         "/auth",
                        "users":        "/users",
                        "compliance":   "/compliance",
                        "notifications": "/notifications",
                },
        })
}