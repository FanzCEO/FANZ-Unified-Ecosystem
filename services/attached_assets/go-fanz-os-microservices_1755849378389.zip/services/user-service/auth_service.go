package main

import (
	"database/sql"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	
	"github.com/fanz-os/shared/cache"
	"github.com/fanz-os/shared/database"
	"github.com/fanz-os/shared/middleware"
	"github.com/fanz-os/shared/models"
	"github.com/fanz-os/shared/utils"
)

// AuthService handles authentication operations
type AuthService struct {
	db    *database.DB
	redis *cache.RedisClient
}

// NewAuthService creates a new authentication service instance
func NewAuthService(db *database.DB, redis *cache.RedisClient) *AuthService {
	return &AuthService{
		db:    db,
		redis: redis,
	}
}

// Register handles user registration
func (s *AuthService) Register(c *gin.Context) {
	var req models.CreateUserRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Validate required fields
	if req.Password == "" {
		utils.BadRequestError(c, "Password is required")
		return
	}

	if req.Email == nil && req.PhoneNumber == nil {
		utils.BadRequestError(c, "Email or phone number is required")
		return
	}

	// Validate email format if provided
	if req.Email != nil && !utils.ValidateEmail(*req.Email) {
		utils.BadRequestError(c, "Invalid email format")
		return
	}

	// Validate phone format if provided
	if req.PhoneNumber != nil && !utils.ValidatePhone(*req.PhoneNumber) {
		utils.BadRequestError(c, "Invalid phone number format")
		return
	}

	// Validate password strength
	if err := utils.ValidatePassword(req.Password); err != nil {
		utils.BadRequestError(c, err.Error())
		return
	}

	// Check if user already exists
	exists, err := s.userExists(req.Email, req.PhoneNumber)
	if err != nil {
		utils.InternalServerError(c, "Failed to check user existence")
		return
	}
	if exists {
		utils.ConflictError(c, "User already exists with this email or phone number")
		return
	}

	// Hash password
	hashedPassword, err := utils.HashPassword(req.Password)
	if err != nil {
		utils.InternalServerError(c, "Failed to hash password")
		return
	}

	// Create user
	userID := uuid.New().String()
	now := time.Now()

	_, err = s.db.Exec(`
		INSERT INTO users (
			id, email, phone_number, password_hash, first_name, last_name,
			role, username, display_name, bio, subscription_price,
			created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
	`, userID, req.Email, req.PhoneNumber, hashedPassword, req.FirstName, req.LastName,
		req.Role, req.Username, req.DisplayName, req.Bio, 0, now, now)

	if err != nil {
		utils.InternalServerError(c, "Failed to create user")
		return
	}

	// Generate JWT token
	token, err := middleware.GenerateJWT(userID, req.Role, getStringValue(req.Email))
	if err != nil {
		utils.InternalServerError(c, "Failed to generate token")
		return
	}

	// Get created user
	user, err := s.getUserByID(userID)
	if err != nil {
		utils.InternalServerError(c, "Failed to get created user")
		return
	}

	utils.CreatedResponse(c, gin.H{
		"user":  user.ToUserResponse(),
		"token": token,
	})
}

// Login handles user authentication
func (s *AuthService) Login(c *gin.Context) {
	var req models.LoginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	if req.Password == "" {
		utils.BadRequestError(c, "Password is required")
		return
	}

	if req.Email == nil && req.PhoneNumber == nil {
		utils.BadRequestError(c, "Email or phone number is required")
		return
	}

	// Find user by email or phone
	user, err := s.getUserByEmailOrPhone(req.Email, req.PhoneNumber)
	if err != nil {
		if err == sql.ErrNoRows {
			utils.UnauthorizedError(c, "Invalid credentials")
		} else {
			utils.InternalServerError(c, "Failed to find user")
		}
		return
	}

	// Check password
	if !utils.CheckPasswordHash(req.Password, *user.PasswordHash) {
		utils.UnauthorizedError(c, "Invalid credentials")
		return
	}

	// Generate JWT token
	token, err := middleware.GenerateJWT(user.ID, user.Role, getStringValue(user.Email))
	if err != nil {
		utils.InternalServerError(c, "Failed to generate token")
		return
	}

	utils.SuccessResponse(c, gin.H{
		"user":  user.ToUserResponse(),
		"token": token,
	})
}

// Logout handles user logout (invalidate token)
func (s *AuthService) Logout(c *gin.Context) {
	// In a stateless JWT system, logout is handled client-side
	// Here we could add token to a blacklist in Redis if needed
	utils.SuccessResponse(c, gin.H{"message": "Successfully logged out"})
}

// RefreshToken handles token refresh
func (s *AuthService) RefreshToken(c *gin.Context) {
	userID, role, err := middleware.GetUserFromContext(c)
	if err != nil {
		utils.UnauthorizedError(c, "Invalid token")
		return
	}

	// Get user to ensure they still exist and are active
	user, err := s.getUserByID(userID)
	if err != nil {
		utils.UnauthorizedError(c, "User not found")
		return
	}

	// Generate new token
	token, err := middleware.GenerateJWT(userID, role, getStringValue(user.Email))
	if err != nil {
		utils.InternalServerError(c, "Failed to generate token")
		return
	}

	utils.SuccessResponse(c, gin.H{"token": token})
}

// VerifyEmail handles email verification
func (s *AuthService) VerifyEmail(c *gin.Context) {
	var req struct {
		Email string `json:"email" binding:"required,email"`
		Code  string `json:"code" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Verify the code
	valid, err := s.verifyCode(req.Email, req.Code, "email_verification")
	if err != nil {
		utils.InternalServerError(c, "Failed to verify code")
		return
	}

	if !valid {
		utils.BadRequestError(c, "Invalid or expired verification code")
		return
	}

	// Update user email verification status
	_, err = s.db.Exec(`
		UPDATE users SET email_verified = true, updated_at = $1 
		WHERE email = $2
	`, time.Now(), req.Email)

	if err != nil {
		utils.InternalServerError(c, "Failed to update verification status")
		return
	}

	utils.SuccessResponse(c, gin.H{"message": "Email verified successfully"})
}

// VerifyPhone handles phone verification
func (s *AuthService) VerifyPhone(c *gin.Context) {
	var req struct {
		PhoneNumber string `json:"phoneNumber" binding:"required"`
		Code        string `json:"code" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Verify the code
	valid, err := s.verifyCode(req.PhoneNumber, req.Code, "phone_verification")
	if err != nil {
		utils.InternalServerError(c, "Failed to verify code")
		return
	}

	if !valid {
		utils.BadRequestError(c, "Invalid or expired verification code")
		return
	}

	// Update user phone verification status
	_, err = s.db.Exec(`
		UPDATE users SET phone_verified = true, updated_at = $1 
		WHERE phone_number = $2
	`, time.Now(), req.PhoneNumber)

	if err != nil {
		utils.InternalServerError(c, "Failed to update verification status")
		return
	}

	utils.SuccessResponse(c, gin.H{"message": "Phone verified successfully"})
}

// ForgotPassword handles password reset requests
func (s *AuthService) ForgotPassword(c *gin.Context) {
	var req struct {
		Email string `json:"email" binding:"required,email"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Check if user exists
	exists, err := s.emailExists(req.Email)
	if err != nil {
		utils.InternalServerError(c, "Failed to check user")
		return
	}

	if !exists {
		// Don't reveal that email doesn't exist
		utils.SuccessResponse(c, gin.H{"message": "If the email exists, a reset code has been sent"})
		return
	}

	// Generate reset code
	code, err := utils.GenerateVerificationCode(6)
	if err != nil {
		utils.InternalServerError(c, "Failed to generate reset code")
		return
	}

	// Store reset code
	err = s.storeVerificationCode("", &req.Email, nil, code, "password_reset")
	if err != nil {
		utils.InternalServerError(c, "Failed to store reset code")
		return
	}

	// In production, send email with reset code
	// For now, just return success

	utils.SuccessResponse(c, gin.H{"message": "If the email exists, a reset code has been sent"})
}

// ResetPassword handles password reset
func (s *AuthService) ResetPassword(c *gin.Context) {
	var req struct {
		Email       string `json:"email" binding:"required,email"`
		Code        string `json:"code" binding:"required"`
		NewPassword string `json:"newPassword" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		utils.BadRequestError(c, "Invalid request format")
		return
	}

	// Validate new password
	if err := utils.ValidatePassword(req.NewPassword); err != nil {
		utils.BadRequestError(c, err.Error())
		return
	}

	// Verify reset code
	valid, err := s.verifyCode(req.Email, req.Code, "password_reset")
	if err != nil {
		utils.InternalServerError(c, "Failed to verify reset code")
		return
	}

	if !valid {
		utils.BadRequestError(c, "Invalid or expired reset code")
		return
	}

	// Hash new password
	hashedPassword, err := utils.HashPassword(req.NewPassword)
	if err != nil {
		utils.InternalServerError(c, "Failed to hash password")
		return
	}

	// Update password
	_, err = s.db.Exec(`
		UPDATE users SET password_hash = $1, updated_at = $2 
		WHERE email = $3
	`, hashedPassword, time.Now(), req.Email)

	if err != nil {
		utils.InternalServerError(c, "Failed to update password")
		return
	}

	utils.SuccessResponse(c, gin.H{"message": "Password reset successfully"})
}

// Helper functions

func (s *AuthService) userExists(email, phoneNumber *string) (bool, error) {
	var count int
	if email != nil && phoneNumber != nil {
		err := s.db.QueryRow(`
			SELECT COUNT(*) FROM users 
			WHERE email = $1 OR phone_number = $2
		`, *email, *phoneNumber).Scan(&count)
		return count > 0, err
	} else if email != nil {
		err := s.db.QueryRow(`
			SELECT COUNT(*) FROM users WHERE email = $1
		`, *email).Scan(&count)
		return count > 0, err
	} else if phoneNumber != nil {
		err := s.db.QueryRow(`
			SELECT COUNT(*) FROM users WHERE phone_number = $1
		`, *phoneNumber).Scan(&count)
		return count > 0, err
	}
	return false, nil
}

func (s *AuthService) emailExists(email string) (bool, error) {
	var count int
	err := s.db.QueryRow(`
		SELECT COUNT(*) FROM users WHERE email = $1
	`, email).Scan(&count)
	return count > 0, err
}

func (s *AuthService) getUserByEmailOrPhone(email, phoneNumber *string) (*models.User, error) {
	var user models.User
	var query string
	var args []interface{}

	if email != nil {
		query = `
			SELECT id, email, phone_number, password_hash, first_name, last_name,
				   profile_image_url, role, username, display_name, bio, subscription_price,
				   is_verified, email_verified, phone_verified, two_factor_enabled,
				   balance, total_earnings, subscriber_count, creator_status,
				   last_post_date, weekly_post_count, monthly_post_count,
				   created_at, updated_at
			FROM users WHERE email = $1
		`
		args = []interface{}{*email}
	} else if phoneNumber != nil {
		query = `
			SELECT id, email, phone_number, password_hash, first_name, last_name,
				   profile_image_url, role, username, display_name, bio, subscription_price,
				   is_verified, email_verified, phone_verified, two_factor_enabled,
				   balance, total_earnings, subscriber_count, creator_status,
				   last_post_date, weekly_post_count, monthly_post_count,
				   created_at, updated_at
			FROM users WHERE phone_number = $1
		`
		args = []interface{}{*phoneNumber}
	} else {
		return nil, fmt.Errorf("email or phone number required")
	}

	err := s.db.QueryRow(query, args...).Scan(
		&user.ID, &user.Email, &user.PhoneNumber, &user.PasswordHash,
		&user.FirstName, &user.LastName, &user.ProfileImageURL, &user.Role,
		&user.Username, &user.DisplayName, &user.Bio, &user.SubscriptionPrice,
		&user.IsVerified, &user.EmailVerified, &user.PhoneVerified,
		&user.TwoFactorEnabled, &user.Balance, &user.TotalEarnings,
		&user.SubscriberCount, &user.CreatorStatus, &user.LastPostDate,
		&user.WeeklyPostCount, &user.MonthlyPostCount, &user.CreatedAt, &user.UpdatedAt,
	)
	return &user, err
}

func (s *AuthService) getUserByID(userID string) (*models.User, error) {
	var user models.User
	err := s.db.QueryRow(`
		SELECT id, email, phone_number, first_name, last_name, profile_image_url,
			   role, username, display_name, bio, subscription_price, is_verified,
			   email_verified, phone_verified, two_factor_enabled, balance,
			   total_earnings, subscriber_count, creator_status, last_post_date,
			   weekly_post_count, monthly_post_count, created_at, updated_at
		FROM users WHERE id = $1
	`, userID).Scan(
		&user.ID, &user.Email, &user.PhoneNumber, &user.FirstName, &user.LastName,
		&user.ProfileImageURL, &user.Role, &user.Username, &user.DisplayName,
		&user.Bio, &user.SubscriptionPrice, &user.IsVerified, &user.EmailVerified,
		&user.PhoneVerified, &user.TwoFactorEnabled, &user.Balance, &user.TotalEarnings,
		&user.SubscriberCount, &user.CreatorStatus, &user.LastPostDate,
		&user.WeeklyPostCount, &user.MonthlyPostCount, &user.CreatedAt, &user.UpdatedAt,
	)
	return &user, err
}

func (s *AuthService) storeVerificationCode(userID string, email, phoneNumber *string, code, codeType string) error {
	id := uuid.New().String()
	expiresAt := time.Now().Add(15 * time.Minute) // 15 minutes expiry

	_, err := s.db.Exec(`
		INSERT INTO verification_codes (id, user_id, email, phone_number, code, type, expires_at, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
	`, id, getUserIDOrNil(userID), email, phoneNumber, code, codeType, expiresAt, time.Now())

	return err
}

func (s *AuthService) verifyCode(identifier, code, codeType string) (bool, error) {
	var count int
	var query string

	if utils.ValidateEmail(identifier) {
		query = `
			SELECT COUNT(*) FROM verification_codes 
			WHERE email = $1 AND code = $2 AND type = $3 
			AND expires_at > $4 AND is_used = false
		`
	} else {
		query = `
			SELECT COUNT(*) FROM verification_codes 
			WHERE phone_number = $1 AND code = $2 AND type = $3 
			AND expires_at > $4 AND is_used = false
		`
	}

	err := s.db.QueryRow(query, identifier, code, codeType, time.Now()).Scan(&count)
	if err != nil {
		return false, err
	}

	if count > 0 {
		// Mark code as used
		if utils.ValidateEmail(identifier) {
			_, err = s.db.Exec(`
				UPDATE verification_codes SET is_used = true 
				WHERE email = $1 AND code = $2 AND type = $3
			`, identifier, code, codeType)
		} else {
			_, err = s.db.Exec(`
				UPDATE verification_codes SET is_used = true 
				WHERE phone_number = $1 AND code = $2 AND type = $3
			`, identifier, code, codeType)
		}
		return err == nil, err
	}

	return false, nil
}

func getStringValue(ptr *string) string {
	if ptr == nil {
		return ""
	}
	return *ptr
}

func getUserIDOrNil(userID string) *string {
	if userID == "" {
		return nil
	}
	return &userID
}

// Placeholder implementations for OAuth and 2FA
func (s *AuthService) Setup2FA(c *gin.Context) {
	utils.ServiceUnavailableError(c, "2FA setup not yet implemented")
}

func (s *AuthService) Verify2FA(c *gin.Context) {
	utils.ServiceUnavailableError(c, "2FA verification not yet implemented")
}

func (s *AuthService) Disable2FA(c *gin.Context) {
	utils.ServiceUnavailableError(c, "2FA disable not yet implemented")
}

func (s *AuthService) GoogleCallback(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Google OAuth not yet implemented")
}

func (s *AuthService) FacebookCallback(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Facebook OAuth not yet implemented")
}

func (s *AuthService) TwitterCallback(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Twitter OAuth not yet implemented")
}

func (s *AuthService) DiscordCallback(c *gin.Context) {
	utils.ServiceUnavailableError(c, "Discord OAuth not yet implemented")
}