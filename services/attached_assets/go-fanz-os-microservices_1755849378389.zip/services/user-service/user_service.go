package main

import (
        "context"
        "database/sql"
        "fmt"
        "net/http"
        "strconv"
        "time"

        "github.com/gin-gonic/gin"
        "github.com/google/uuid"
        "github.com/shopspring/decimal"
        
        "github.com/fanz-os/shared/cache"
        "github.com/fanz-os/shared/database"
        "github.com/fanz-os/shared/models"
        "github.com/fanz-os/shared/middleware"
        "github.com/fanz-os/shared/utils"
)

// UserService handles user-related operations
type UserService struct {
        db    *database.DB
        redis *cache.RedisClient
}

// NewUserService creates a new user service instance
func NewUserService(db *database.DB, redis *cache.RedisClient) *UserService {
        return &UserService{
                db:    db,
                redis: redis,
        }
}

// GetProfile gets the current user's profile
func (s *UserService) GetProfile(c *gin.Context) {
        userID, _, err := middleware.GetUserFromContext(c)
        if err != nil {
                utils.UnauthorizedError(c, "User not found in context")
                return
        }

        user, err := s.getUserByID(userID)
        if err != nil {
                if err == sql.ErrNoRows {
                        utils.NotFoundError(c, "User not found")
                } else {
                        utils.InternalServerError(c, "Failed to get user profile")
                }
                return
        }

        utils.SuccessResponse(c, user.ToUserResponse())
}

// UpdateProfile updates the current user's profile
func (s *UserService) UpdateProfile(c *gin.Context) {
        userID, _, err := middleware.GetUserFromContext(c)
        if err != nil {
                utils.UnauthorizedError(c, "User not found in context")
                return
        }

        var req models.UpdateUserRequest
        if err := c.ShouldBindJSON(&req); err != nil {
                utils.BadRequestError(c, "Invalid request format")
                return
        }

        // Build update query dynamically
        setParts := []string{}
        args := []interface{}{}
        argIndex := 1

        if req.FirstName != nil {
                setParts = append(setParts, fmt.Sprintf("first_name = $%d", argIndex))
                args = append(args, *req.FirstName)
                argIndex++
        }
        if req.LastName != nil {
                setParts = append(setParts, fmt.Sprintf("last_name = $%d", argIndex))
                args = append(args, *req.LastName)
                argIndex++
        }
        if req.Username != nil {
                // Check if username is already taken
                if exists, err := s.usernameExists(*req.Username, userID); err != nil {
                        utils.InternalServerError(c, "Failed to check username availability")
                        return
                } else if exists {
                        utils.ConflictError(c, "Username already taken")
                        return
                }
                
                setParts = append(setParts, fmt.Sprintf("username = $%d", argIndex))
                args = append(args, *req.Username)
                argIndex++
        }
        if req.DisplayName != nil {
                setParts = append(setParts, fmt.Sprintf("display_name = $%d", argIndex))
                args = append(args, *req.DisplayName)
                argIndex++
        }
        if req.Bio != nil {
                setParts = append(setParts, fmt.Sprintf("bio = $%d", argIndex))
                args = append(args, *req.Bio)
                argIndex++
        }
        if req.ProfileImageURL != nil {
                setParts = append(setParts, fmt.Sprintf("profile_image_url = $%d", argIndex))
                args = append(args, *req.ProfileImageURL)
                argIndex++
        }
        if req.SubscriptionPrice != nil {
                setParts = append(setParts, fmt.Sprintf("subscription_price = $%d", argIndex))
                args = append(args, *req.SubscriptionPrice)
                argIndex++
        }

        if len(setParts) == 0 {
                utils.BadRequestError(c, "No fields to update")
                return
        }

        // Add updated_at and userID
        setParts = append(setParts, fmt.Sprintf("updated_at = $%d", argIndex))
        args = append(args, time.Now())
        argIndex++
        
        args = append(args, userID)

        query := fmt.Sprintf(`
                UPDATE users 
                SET %s 
                WHERE id = $%d
        `, joinStrings(setParts, ", "), argIndex)

        _, err = s.db.Exec(query, args...)
        if err != nil {
                utils.InternalServerError(c, "Failed to update profile")
                return
        }

        // Get updated user
        user, err := s.getUserByID(userID)
        if err != nil {
                utils.InternalServerError(c, "Failed to get updated profile")
                return
        }

        utils.SuccessResponse(c, user.ToUserResponse())
}

// FollowUser follows another user
func (s *UserService) FollowUser(c *gin.Context) {
        userID, _, err := middleware.GetUserFromContext(c)
        if err != nil {
                utils.UnauthorizedError(c, "User not found in context")
                return
        }

        followingID := c.Param("userId")
        if followingID == "" {
                utils.BadRequestError(c, "User ID is required")
                return
        }

        if userID == followingID {
                utils.BadRequestError(c, "Cannot follow yourself")
                return
        }

        // Check if already following
        exists, err := s.isFollowing(userID, followingID)
        if err != nil {
                utils.InternalServerError(c, "Failed to check follow status")
                return
        }
        if exists {
                utils.ConflictError(c, "Already following this user")
                return
        }

        // Create follow relationship
        followID := uuid.New().String()
        _, err = s.db.Exec(`
                INSERT INTO follows (id, follower_id, following_id, created_at)
                VALUES ($1, $2, $3, $4)
        `, followID, userID, followingID, time.Now())
        
        if err != nil {
                utils.InternalServerError(c, "Failed to follow user")
                return
        }

        utils.SuccessResponse(c, gin.H{"message": "Successfully followed user"})
}

// UnfollowUser unfollows another user
func (s *UserService) UnfollowUser(c *gin.Context) {
        userID, _, err := middleware.GetUserFromContext(c)
        if err != nil {
                utils.UnauthorizedError(c, "User not found in context")
                return
        }

        followingID := c.Param("userId")
        if followingID == "" {
                utils.BadRequestError(c, "User ID is required")
                return
        }

        result, err := s.db.Exec(`
                DELETE FROM follows 
                WHERE follower_id = $1 AND following_id = $2
        `, userID, followingID)
        
        if err != nil {
                utils.InternalServerError(c, "Failed to unfollow user")
                return
        }

        rowsAffected, _ := result.RowsAffected()
        if rowsAffected == 0 {
                utils.NotFoundError(c, "Follow relationship not found")
                return
        }

        utils.SuccessResponse(c, gin.H{"message": "Successfully unfollowed user"})
}

// GetCreatorStats gets creator statistics
func (s *UserService) GetCreatorStats(c *gin.Context) {
        userID, _, err := middleware.GetUserFromContext(c)
        if err != nil {
                utils.UnauthorizedError(c, "User not found in context")
                return
        }

        stats := make(map[string]interface{})

        // Get subscriber count
        var subscriberCount int
        err = s.db.QueryRow(`
                SELECT COUNT(*) FROM subscriptions 
                WHERE creator_id = $1 AND is_active = true
        `, userID).Scan(&subscriberCount)
        if err != nil {
                subscriberCount = 0
        }
        stats["subscriber_count"] = subscriberCount

        // Get total earnings
        var totalEarnings decimal.Decimal
        err = s.db.QueryRow(`
                SELECT COALESCE(SUM(amount), 0) FROM transactions 
                WHERE recipient_id = $1 AND type IN ('subscription', 'tip', 'ppv_unlock')
        `, userID).Scan(&totalEarnings)
        if err != nil {
                totalEarnings = decimal.Zero
        }
        stats["total_earnings"] = totalEarnings

        // Get post count
        var postCount int
        err = s.db.QueryRow(`
                SELECT COUNT(*) FROM posts WHERE creator_id = $1
        `, userID).Scan(&postCount)
        if err != nil {
                postCount = 0
        }
        stats["post_count"] = postCount

        // Get likes received
        var likesReceived int
        err = s.db.QueryRow(`
                SELECT COUNT(*) FROM likes l
                JOIN posts p ON l.post_id = p.id
                WHERE p.creator_id = $1
        `, userID).Scan(&likesReceived)
        if err != nil {
                likesReceived = 0
        }
        stats["likes_received"] = likesReceived

        utils.SuccessResponse(c, stats)
}

// Helper functions

func (s *UserService) getUserByID(userID string) (*models.User, error) {
        var user models.User
        err := s.db.QueryRow(`
                SELECT id, email, phone_number, first_name, last_name, profile_image_url,
                           role, username, display_name, bio, subscription_price, is_verified,
                           email_verified, phone_verified, two_factor_enabled, balance,
                           total_earnings, subscriber_count, creator_status, last_post_date,
                           weekly_post_count, monthly_post_count, created_at, updated_at
                FROM users WHERE id = $1
        `, userID).Scan(
                &user.ID, &user.Email, &user.PhoneNumber, &user.FirstName, &user.LastName,
                &user.ProfileImageURL, &user.Role, &user.Username, &user.DisplayName,
                &user.Bio, &user.SubscriptionPrice, &user.IsVerified, &user.EmailVerified,
                &user.PhoneVerified, &user.TwoFactorEnabled, &user.Balance, &user.TotalEarnings,
                &user.SubscriberCount, &user.CreatorStatus, &user.LastPostDate,
                &user.WeeklyPostCount, &user.MonthlyPostCount, &user.CreatedAt, &user.UpdatedAt,
        )
        return &user, err
}

func (s *UserService) usernameExists(username, excludeUserID string) (bool, error) {
        var count int
        err := s.db.QueryRow(`
                SELECT COUNT(*) FROM users 
                WHERE username = $1 AND id != $2
        `, username, excludeUserID).Scan(&count)
        return count > 0, err
}

func (s *UserService) isFollowing(followerID, followingID string) (bool, error) {
        var count int
        err := s.db.QueryRow(`
                SELECT COUNT(*) FROM follows 
                WHERE follower_id = $1 AND following_id = $2
        `, followerID, followingID).Scan(&count)
        return count > 0, err
}

func joinStrings(strs []string, sep string) string {
        if len(strs) == 0 {
                return ""
        }
        result := strs[0]
        for i := 1; i < len(strs); i++ {
                result += sep + strs[i]
        }
        return result
}

// Placeholder implementations for missing methods
func (s *UserService) UploadAvatar(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Avatar upload not yet implemented")
}

func (s *UserService) GetSettings(c *gin.Context) {
        utils.ServiceUnavailableError(c, "User settings not yet implemented")
}

func (s *UserService) UpdateSettings(c *gin.Context) {
        utils.ServiceUnavailableError(c, "User settings update not yet implemented")
}

func (s *UserService) GetFollowers(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Get followers not yet implemented")
}

func (s *UserService) GetFollowing(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Get following not yet implemented")
}

func (s *UserService) SearchUsers(c *gin.Context) {
        utils.ServiceUnavailableError(c, "User search not yet implemented")
}

func (s *UserService) GetEarnings(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Get earnings not yet implemented")
}

func (s *UserService) UpdateSubscriptionPrice(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Update subscription price not yet implemented")
}

func (s *UserService) GetSubscribers(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Get subscribers not yet implemented")
}

func (s *UserService) GetPerformanceMetrics(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Get performance metrics not yet implemented")
}

func (s *UserService) GetAllUsers(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Get all users not yet implemented")
}

func (s *UserService) GetUserByID(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Get user by ID not yet implemented")
}

func (s *UserService) UpdateUserStatus(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Update user status not yet implemented")
}

func (s *UserService) UpdateUserRole(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Update user role not yet implemented")
}

func (s *UserService) SuspendUser(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Suspend user not yet implemented")
}

func (s *UserService) UnsuspendUser(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Unsuspend user not yet implemented")
}

func (s *UserService) GetUserAuditLog(c *gin.Context) {
        utils.ServiceUnavailableError(c, "Get user audit log not yet implemented")
}