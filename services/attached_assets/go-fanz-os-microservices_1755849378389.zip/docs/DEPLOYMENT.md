# Fanz OS Deployment Guide

Complete production deployment guide for the Fanz Operating System - a high-performance Go microservices platform for adult content creators.

## 🚀 Quick Start

### Prerequisites

Ensure you have the following tools installed:

- **Kubernetes cluster** (v1.25+)
- **kubectl** (v1.25+)
- **Helm** (v3.12+)
- **Docker** (v20.10+)
- **Go** (v1.21+)
- **Git**

### One-Command Deployment

```bash
# Deploy to staging
./scripts/deploy.sh deploy staging v1.0.0

# Deploy to production
./scripts/deploy.sh deploy production v1.0.0
```

## 📋 Architecture Overview

### Microservices

1. **API Gateway** (`:8080`) - Request routing, rate limiting, authentication
2. **User Service** (`:8001`) - User management, authentication, profiles
3. **Content Service** (`:8002`) - Media processing, content management
4. **Payment Service** (`:8003`) - Payment processing, subscriptions, billing
5. **Streaming Service** (`:8004`) - Live streaming, WebRTC, RTMP
6. **Messaging Service** (`:8005`) - Real-time messaging, notifications
7. **Admin Service** (`:8006`) - Administrative functions, compliance
8. **AI Service** (`:8007`) - Content moderation, recommendations

### Infrastructure Components

- **PostgreSQL** - Primary database
- **Redis** - Caching and session storage
- **NGINX Ingress** - Load balancing and SSL termination
- **Prometheus + Grafana** - Monitoring and alerting
- **Jaeger** - Distributed tracing
- **ELK Stack** - Logging aggregation

## 🔧 Pre-deployment Setup

### 1. Kubernetes Cluster Preparation

#### Required Node Configuration

```bash
# Minimum cluster requirements:
# - 3 worker nodes
# - 8 CPU cores per node
# - 32GB RAM per node
# - 500GB SSD storage per node
# - GPU nodes for AI service (optional but recommended)

# Label nodes for specific workloads
kubectl label nodes gpu-node-1 node-type=gpu-enabled
kubectl label nodes admin-node-1 security-zone=trusted
```

#### Storage Classes

```bash
# Create fast SSD storage class (example for AWS EKS)
kubectl apply -f - <<EOF
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: fast-ssd
provisioner: ebs.csi.aws.com
parameters:
  type: gp3
  iops: "3000"
  throughput: "125"
volumeBindingMode: WaitForFirstConsumer
allowVolumeExpansion: true
EOF
```

### 2. Create Required Secrets

#### Database Credentials

```bash
kubectl create secret generic postgresql-auth \
  --from-literal=username=fanz_os_user \
  --from-literal=password="$(openssl rand -base64 32)" \
  --from-literal=database=fanz_os \
  -n fanz-os

kubectl create secret generic redis-auth \
  --from-literal=password="$(openssl rand -base64 32)" \
  -n fanz-os
```

#### Application Secrets

```bash
kubectl create secret generic fanz-os-secrets \
  --from-literal=jwt-secret="$(openssl rand -base64 64)" \
  --from-literal=jwt-refresh-secret="$(openssl rand -base64 64)" \
  --from-literal=encryption-key="$(openssl rand -base64 32)" \
  --from-literal=ccbill-client-id="YOUR_CCBILL_CLIENT_ID" \
  --from-literal=ccbill-client-secret="YOUR_CCBILL_CLIENT_SECRET" \
  --from-literal=stripe-secret-key="YOUR_STRIPE_SECRET_KEY" \
  --from-literal=openai-api-key="YOUR_OPENAI_API_KEY" \
  --from-literal=google-cloud-storage-key="YOUR_GCS_KEY" \
  --from-literal=twilio-account-sid="YOUR_TWILIO_SID" \
  --from-literal=twilio-auth-token="YOUR_TWILIO_TOKEN" \
  --from-literal=sendgrid-api-key="YOUR_SENDGRID_KEY" \
  -n fanz-os
```

#### TLS Certificates (Let's Encrypt)

```bash
# Create certificate issuer
kubectl apply -f k8s/tls/cert-manager-issuer.yaml

# Certificates will be automatically generated via cert-manager
```

### 3. Docker Registry Setup

```bash
# Create registry credentials secret
kubectl create secret docker-registry registry-credentials \
  --docker-server=docker.io \
  --docker-username=YOUR_DOCKER_USERNAME \
  --docker-password=YOUR_DOCKER_PASSWORD \
  --docker-email=YOUR_EMAIL \
  -n fanz-os
```

## 🏗️ Deployment Process

### Step 1: Infrastructure Deployment

```bash
# Deploy cert-manager
helm repo add jetstack https://charts.jetstack.io
helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager \
  --create-namespace \
  --version v1.13.0 \
  --set installCRDs=true

# Deploy ingress-nginx
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm install ingress-nginx ingress-nginx/ingress-nginx \
  --namespace ingress-nginx \
  --create-namespace

# Deploy monitoring stack
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm install prometheus prometheus-community/kube-prometheus-stack \
  --namespace fanz-os-monitoring \
  --create-namespace \
  --values monitoring/prometheus/values.yaml
```

### Step 2: Database Deployment

```bash
# Deploy PostgreSQL
helm repo add bitnami https://charts.bitnami.com/bitnami
helm install postgresql bitnami/postgresql \
  --namespace fanz-os \
  --create-namespace \
  --values helm/fanz-os/values-production.yaml

# Deploy Redis
helm install redis bitnami/redis \
  --namespace fanz-os \
  --values helm/fanz-os/values-production.yaml
```

### Step 3: Application Deployment

```bash
# Deploy Fanz OS using Helm
helm install fanz-os-prod ./helm/fanz-os \
  --namespace fanz-os \
  --create-namespace \
  --values ./helm/fanz-os/values-production.yaml \
  --set image.tag=v1.0.0 \
  --set fanzos.environment=production \
  --set fanzos.domain=fanz-os.com \
  --timeout 15m \
  --wait
```

### Step 4: Post-deployment Verification

```bash
# Check all pods are running
kubectl get pods -n fanz-os

# Check services and ingress
kubectl get svc,ing -n fanz-os

# Verify health endpoints
curl -f https://fanz-os.com/health
curl -f https://api.fanz-os.com/health

# Check metrics
curl -f https://fanz-os.com/metrics
```

## ⚙️ Configuration Management

### Environment-Specific Values

#### Staging (`values-staging.yaml`)

```yaml
fanzos:
  environment: staging
  domain: staging.fanz-os.com

resources:
  limits:
    cpu: 500m
    memory: 512Mi

autoscaling:
  enabled: true
  minReplicas: 1
  maxReplicas: 3

tls:
  issuer: letsencrypt-staging
```

#### Production (`values-production.yaml`)

```yaml
fanzos:
  environment: production
  domain: fanz-os.com

resources:
  limits:
    cpu: 2000m
    memory: 2Gi

autoscaling:
  enabled: true
  minReplicas: 3
  maxReplicas: 20

tls:
  issuer: letsencrypt-prod

monitoring:
  enabled: true
  alerts: true

backup:
  enabled: true
  schedule: "0 */6 * * *"
```

### Feature Flags

```yaml
fanzos:
  features:
    liveStreaming: true
    aiModeration: true
    cryptoPayments: true
    internationalPayments: true
    webrtc: true
    recordKeeping2257: true
    ageVerification: true
```

## 📈 Scaling Configuration

### Horizontal Pod Autoscaling

All services are configured with HPA based on:

- **CPU utilization** (60-80% target)
- **Memory utilization** (70-85% target)
- **Custom metrics** (request rate, queue depth)

```bash
# View current HPA status
kubectl get hpa -n fanz-os

# Manual scaling (emergency)
kubectl scale deployment api-gateway --replicas=10 -n fanz-os
```

### Vertical Pod Autoscaling

VPA is configured for database workloads:

```bash
# Check VPA recommendations
kubectl get vpa -n fanz-os
kubectl describe vpa postgresql-vpa -n fanz-os
```

## 🔐 Security Configuration

### Network Policies

- **Default deny-all** policy in place
- **Service-specific** ingress/egress rules
- **External API access** for payment processors
- **Monitoring access** from dedicated namespace

### RBAC

- **Service accounts** with minimal required permissions
- **Cluster roles** for different service types
- **Admin service** with elevated privileges for compliance

### Pod Security Standards

- **Restricted** pod security standard enforced
- **Non-root** user execution
- **Read-only** root filesystem
- **No privilege escalation**

## 📊 Monitoring and Observability

### Metrics Collection

```bash
# Access Grafana dashboard
kubectl port-forward svc/prometheus-grafana 3000:80 -n fanz-os-monitoring
# Open http://localhost:3000 (admin/prom-operator)
```

### Key Dashboards

1. **System Overview** - Cluster health, resource usage
2. **Application Metrics** - Request rates, response times
3. **Business Metrics** - User activity, revenue, content stats
4. **Security Dashboard** - Failed logins, blocked requests
5. **Adult Content Compliance** - Moderation stats, age verification

### Alerting Rules

- **High error rates** (>5% for 5 minutes)
- **High response times** (>2s for 10 minutes)
- **Resource exhaustion** (CPU/Memory >90%)
- **Pod crashes** (restart loop)
- **Payment failures** (critical)
- **Backup failures** (critical)

### Tracing

```bash
# Access Jaeger UI
kubectl port-forward svc/jaeger-query 16686:16686 -n fanz-os-monitoring
# Open http://localhost:16686
```

## 💾 Backup and Disaster Recovery

### Automated Backups

- **PostgreSQL**: Every 6 hours
- **Redis**: Every 12 hours
- **Media files**: Daily incremental
- **Weekly/Monthly** archives

### Recovery Procedures

#### Database Recovery

```bash
# List available backups
aws s3 ls s3://fanz-os-backups/postgresql/daily/

# Restore from backup
kubectl exec -it postgresql-0 -n fanz-os -- psql -U postgres -c "DROP DATABASE fanz_os;"
kubectl exec -it postgresql-0 -n fanz-os -- psql -U postgres -c "CREATE DATABASE fanz_os;"
aws s3 cp s3://fanz-os-backups/postgresql/daily/backup.sql.gz - | gunzip | kubectl exec -i postgresql-0 -n fanz-os -- psql -U postgres -d fanz_os
```

#### Application Rollback

```bash
# Rollback to previous version
helm rollback fanz-os-prod -n fanz-os

# Deploy specific version
helm upgrade fanz-os-prod ./helm/fanz-os --set image.tag=v0.9.0 -n fanz-os
```

### RTO/RPO Targets

- **Database RTO**: < 1 hour
- **Application RTO**: < 30 minutes
- **Complete disaster RTO**: < 4 hours
- **Database RPO**: < 6 hours
- **Media files RPO**: < 24 hours

## 🔄 CI/CD Pipeline

### GitHub Actions Workflow

The CI/CD pipeline includes:

1. **Security scanning** (gosec, CodeQL, Trivy)
2. **Unit/integration tests** (>80% coverage required)
3. **Docker image builds** (multi-arch: amd64/arm64)
4. **Automated staging deployment** (develop branch)
5. **Production deployment** (release tags)

### Manual Deployment

```bash
# Build and push images
docker build -t fanz-os/api-gateway:v1.0.0 ./services/api-gateway
docker push fanz-os/api-gateway:v1.0.0

# Deploy specific version
helm upgrade fanz-os-prod ./helm/fanz-os \
  --set image.tag=v1.0.0 \
  -n fanz-os
```

## 🚨 Troubleshooting

### Common Issues

#### Pod Startup Failures

```bash
# Check pod logs
kubectl logs -f deployment/api-gateway -n fanz-os

# Check events
kubectl get events --sort-by=.metadata.creationTimestamp -n fanz-os

# Describe pod for detailed info
kubectl describe pod <pod-name> -n fanz-os
```

#### Database Connection Issues

```bash
# Test database connectivity
kubectl exec -it deployment/user-service -n fanz-os -- /bin/sh
# Inside container:
psql -h postgresql -U fanz_os_user -d fanz_os -c "SELECT version();"
```

#### High Memory Usage

```bash
# Check resource usage
kubectl top pods -n fanz-os
kubectl top nodes

# Scale up resources
kubectl patch hpa api-gateway-hpa -n fanz-os --patch '{"spec":{"maxReplicas":20}}'
```

#### SSL Certificate Issues

```bash
# Check certificate status
kubectl get certificates -n fanz-os
kubectl describe certificate fanz-os-tls-cert -n fanz-os

# Force certificate renewal
kubectl delete certificate fanz-os-tls-cert -n fanz-os
# Certificate will be automatically recreated
```

### Health Check Endpoints

- `GET /health` - Basic health check
- `GET /ready` - Readiness probe (includes DB connectivity)
- `GET /metrics` - Prometheus metrics
- `GET /version` - Build version info

### Performance Optimization

#### Database Optimization

```sql
-- Check slow queries
SELECT query, mean_time, calls FROM pg_stat_statements ORDER BY mean_time DESC LIMIT 10;

-- Analyze table statistics
ANALYZE;

-- Check index usage
SELECT schemaname, tablename, attname, n_distinct, correlation FROM pg_stats;
```

#### Redis Optimization

```bash
# Check Redis memory usage
kubectl exec -it redis-master-0 -n fanz-os -- redis-cli INFO memory

# Monitor slow log
kubectl exec -it redis-master-0 -n fanz-os -- redis-cli SLOWLOG GET 10
```

## 🏢 Production Checklist

### Pre-Production

- [ ] All secrets configured
- [ ] SSL certificates issued
- [ ] Database migrations applied
- [ ] Backup strategy implemented
- [ ] Monitoring dashboards configured
- [ ] Load testing completed
- [ ] Security scans passed
- [ ] Compliance requirements verified
- [ ] DNS records configured
- [ ] CDN setup (if applicable)

### Post-Deployment

- [ ] All services healthy
- [ ] Health endpoints responding
- [ ] Metrics being collected
- [ ] Logs flowing to ELK
- [ ] Alerts configured and tested
- [ ] Backup jobs running
- [ ] Performance benchmarks met
- [ ] User acceptance testing passed
- [ ] Documentation updated
- [ ] Team trained on operations

## 📞 Support and Maintenance

### Emergency Contacts

- **DevOps Team**: devops@fanz-os.com
- **Platform Team**: platform@fanz-os.com
- **Security Team**: security@fanz-os.com
- **On-call Phone**: +1-XXX-XXX-XXXX

### Regular Maintenance

#### Weekly Tasks

- Review monitoring dashboards
- Check backup success
- Update security patches
- Review resource usage

#### Monthly Tasks

- Kubernetes version updates
- Dependency updates
- Capacity planning review
- Security audit
- Disaster recovery testing

#### Quarterly Tasks

- Full security penetration testing
- Performance optimization review
- Architecture review
- Business continuity planning

---

## 📚 Additional Resources

- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [Helm Documentation](https://helm.sh/docs/)
- [Prometheus Monitoring](https://prometheus.io/docs/)
- [Adult Content Compliance Guide](./COMPLIANCE.md)
- [Security Best Practices](./SECURITY.md)
- [Development Guide](./DEVELOPMENT.md)

---

**Fanz Operating System** - Production-ready adult content creator platform built with Go microservices, Kubernetes, and comprehensive monitoring.

For technical support: [support@fanz-os.com](mailto:support@fanz-os.com)