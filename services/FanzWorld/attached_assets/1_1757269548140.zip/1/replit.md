# FanzBook Community Platform

## Overview

FanzBook is a full-stack community platform built with modern web technologies. It features a React frontend with TypeScript, an Express.js backend, and PostgreSQL database integration through Drizzle ORM. The application provides three main sections: a forum for discussions, real-time chat rooms, and a marketplace for buying/selling items. The platform is designed to be responsive across desktop and mobile devices with a clean, modern UI built using shadcn/ui components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: TanStack React Query for server state management
- **Real-time Communication**: WebSocket integration for live chat functionality
- **Responsive Design**: Mobile-first approach with dedicated mobile navigation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with WebSocket support for real-time features
- **Request Handling**: Express middleware for JSON parsing, logging, and error handling
- **Development Setup**: Vite integration for hot module replacement in development

### Data Storage Solutions
- **Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Shared schema definitions between frontend and backend
- **Migrations**: Drizzle Kit for database schema migrations
- **Data Models**: Users, forum categories, posts, replies, chat rooms, messages, and marketplace items

### Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL session store (connect-pg-simple)
- **User Management**: User registration, online status tracking, and profile management
- **Security**: CORS handling and secure session configuration

### External Dependencies
- **Database Hosting**: Neon Database (PostgreSQL serverless)
- **Development Tools**: Replit integration with cartographer plugin
- **Build System**: Vite for frontend bundling and esbuild for backend compilation
- **UI Framework**: Radix UI components with class-variance-authority for styling variants
- **Utilities**: Date manipulation with date-fns, class merging with clsx and tailwind-merge
- **Real-time**: WebSocket implementation with ws library
- **Form Handling**: React Hook Form with Zod validation schemas