import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  avatar: text("avatar"),
  isOnline: boolean("is_online").default(false),
  lastSeen: timestamp("last_seen").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  // Social Media Profile Fields  
  firstName: text("first_name"),
  lastName: text("last_name"),
  bio: text("bio"),
  website: text("website"),
  location: text("location"),
  coverImage: text("cover_image"),
  // Social Stats
  followersCount: integer("followers_count").default(0),
  followingCount: integer("following_count").default(0),
  postsCount: integer("posts_count").default(0),
});

export const forumCategories = pgTable("forum_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  icon: text("icon").notNull(),
  postCount: integer("post_count").default(0),
});

export const forumPosts = pgTable("forum_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  content: text("content").notNull(),
  authorId: varchar("author_id").references(() => users.id).notNull(),
  categoryId: varchar("category_id").references(() => forumCategories.id).notNull(),
  replyCount: integer("reply_count").default(0),
  viewCount: integer("view_count").default(0),
  likeCount: integer("like_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const forumReplies = pgTable("forum_replies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  authorId: varchar("author_id").references(() => users.id).notNull(),
  postId: varchar("post_id").references(() => forumPosts.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const chatRooms = pgTable("chat_rooms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  userCount: integer("user_count").default(0),
});

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  authorId: varchar("author_id").references(() => users.id).notNull(),
  roomId: varchar("room_id").references(() => chatRooms.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Chat reactions table for Facebook-like emoji reactions
export const chatReactions = pgTable("chat_reactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messageId: varchar("message_id").references(() => chatMessages.id, { onDelete: "cascade" }).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  emoji: text("emoji").notNull(), // Unicode emoji character
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  // Ensure one reaction per user per message per emoji type
  uniqueUserMessageEmoji: sql`UNIQUE(message_id, user_id, emoji)`,
}));

// Social Media Tables

// User connections/follows table
export const userConnections = pgTable("user_connections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  followerId: varchar("follower_id").references(() => users.id).notNull(),
  followingId: varchar("following_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  // Ensure one connection per user pair
  uniqueConnection: sql`UNIQUE(follower_id, following_id)`,
}));

// Social posts table (news feed posts)
export const socialPosts = pgTable("social_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  authorId: varchar("author_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  videoUrl: text("video_url"),
  linkUrl: text("link_url"),
  linkTitle: text("link_title"),
  linkDescription: text("link_description"),
  postType: text("post_type").default("text"), // text, image, video, story, shared
  privacy: text("privacy").notNull().default("public"), // public, friends, private
  isStory: boolean("is_story").default(false),
  storyExpiresAt: timestamp("story_expires_at"),
  likesCount: integer("likes_count").default(0),
  commentsCount: integer("comments_count").default(0),
  sharesCount: integer("shares_count").default(0),
  reactionsCount: integer("reactions_count").default(0),
  viewsCount: integer("views_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Post reactions table (WoWonder-style emoji reactions)
export const postReactions = pgTable("post_reactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").references(() => socialPosts.id, { onDelete: "cascade" }).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  reactionType: text("reaction_type").notNull(), // like, love, wow, haha, sad, angry
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  // Ensure one reaction per user per post per type
  uniqueUserPostReaction: sql`UNIQUE(post_id, user_id, reaction_type)`,
}));

// Post likes table (legacy, kept for backwards compatibility)
export const postLikes = pgTable("post_likes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").references(() => socialPosts.id, { onDelete: "cascade" }).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  // Ensure one like per user per post
  uniqueUserPostLike: sql`UNIQUE(post_id, user_id)`,
}));

// Post comments table
export const postComments = pgTable("post_comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  postId: varchar("post_id").references(() => socialPosts.id, { onDelete: "cascade" }).notNull(),
  authorId: varchar("author_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  parentId: varchar("parent_id"), // For nested comments - self-reference
  createdAt: timestamp("created_at").defaultNow(),
});

// User social links table
export const userSocialLinks = pgTable("user_social_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  platform: text("platform").notNull(), // twitter, facebook, instagram, linkedin, etc.
  url: text("url").notNull(),
  username: text("username"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const marketplaceItems = pgTable("marketplace_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // price in cents
  category: text("category").notNull(),
  image: text("image"),
  sellerId: varchar("seller_id").references(() => users.id).notNull(),
  isSold: boolean("is_sold").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  lastSeen: true,
});

export const insertForumCategorySchema = createInsertSchema(forumCategories).omit({
  id: true,
  postCount: true,
});

export const insertForumPostSchema = createInsertSchema(forumPosts).omit({
  id: true,
  replyCount: true,
  viewCount: true,
  likeCount: true,
  createdAt: true,
  updatedAt: true,
});

export const insertForumReplySchema = createInsertSchema(forumReplies).omit({
  id: true,
  createdAt: true,
});

export const insertChatRoomSchema = createInsertSchema(chatRooms).omit({
  id: true,
  userCount: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export const insertChatReactionSchema = createInsertSchema(chatReactions).omit({
  id: true,
  createdAt: true,
});

// Social Media Insert Schemas
export const insertUserConnectionSchema = createInsertSchema(userConnections).omit({
  id: true,
  createdAt: true,
});

export const insertSocialPostSchema = createInsertSchema(socialPosts).omit({
  id: true,
  likesCount: true,
  commentsCount: true,
  sharesCount: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPostLikeSchema = createInsertSchema(postLikes).omit({
  id: true,
  createdAt: true,
});

export const insertPostCommentSchema = createInsertSchema(postComments).omit({
  id: true,
  createdAt: true,
});

export const insertUserSocialLinkSchema = createInsertSchema(userSocialLinks).omit({
  id: true,
  createdAt: true,
});

export const insertMarketplaceItemSchema = createInsertSchema(marketplaceItems).omit({
  id: true,
  isSold: true,
  createdAt: true,
});

// Groups table (WoWonder-style)
export const groups = pgTable("groups", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  coverImage: text("cover_image"),
  avatar: text("avatar"),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  isPrivate: boolean("is_private").default(false),
  memberCount: integer("member_count").default(0),
  postCount: integer("post_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Group members table
export const groupMembers = pgTable("group_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  groupId: varchar("group_id").references(() => groups.id, { onDelete: "cascade" }).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  role: text("role").default("member"), // member, admin, moderator
  joinedAt: timestamp("joined_at").defaultNow(),
}, (table) => ({
  uniqueGroupMember: sql`UNIQUE(group_id, user_id)`,
}));

// Pages table (Business/Brand pages)
export const pages = pgTable("pages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull(),
  coverImage: text("cover_image"),
  avatar: text("avatar"),
  website: text("website"),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  isVerified: boolean("is_verified").default(false),
  likesCount: integer("likes_count").default(0),
  followersCount: integer("followers_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Page followers
export const pageFollowers = pgTable("page_followers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pageId: varchar("page_id").references(() => pages.id, { onDelete: "cascade" }).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  followedAt: timestamp("followed_at").defaultNow(),
}, (table) => ({
  uniquePageFollower: sql`UNIQUE(page_id, user_id)`,
}));

// Notifications table
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  fromUserId: varchar("from_user_id").references(() => users.id),
  type: text("type").notNull(), // like, comment, follow, mention, etc.
  title: text("title").notNull(),
  message: text("message").notNull(),
  actionUrl: text("action_url"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// User verification requests
export const verificationRequests = pgTable("verification_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  documentType: text("document_type").notNull(),
  documentUrl: text("document_url").notNull(),
  status: text("status").default("pending"), // pending, approved, rejected
  notes: text("notes"),
  submittedAt: timestamp("submitted_at").defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

// Stories functionality
export const stories = pgTable("stories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  mediaUrl: text("media_url").notNull(),
  mediaType: text("media_type").notNull(), // image, video
  caption: text("caption"),
  viewCount: integer("view_count").default(0),
  isHighlight: boolean("is_highlight").default(false),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Story views
export const storyViews = pgTable("story_views", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  storyId: varchar("story_id").references(() => stories.id, { onDelete: "cascade" }).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  viewedAt: timestamp("viewed_at").defaultNow(),
}, (table) => ({
  uniqueStoryView: sql`UNIQUE(story_id, user_id)`,
}));

// Insert schemas for new tables
export const insertPostReactionSchema = createInsertSchema(postReactions).omit({
  id: true,
  createdAt: true,
});

export const insertGroupSchema = createInsertSchema(groups).omit({
  id: true,
  memberCount: true,
  postCount: true,
  createdAt: true,
});

export const insertGroupMemberSchema = createInsertSchema(groupMembers).omit({
  id: true,
  joinedAt: true,
});

export const insertPageSchema = createInsertSchema(pages).omit({
  id: true,
  isVerified: true,
  likesCount: true,
  followersCount: true,
  createdAt: true,
});

export const insertPageFollowerSchema = createInsertSchema(pageFollowers).omit({
  id: true,
  followedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  isRead: true,
  createdAt: true,
});

export const insertVerificationRequestSchema = createInsertSchema(verificationRequests).omit({
  id: true,
  status: true,
  submittedAt: true,
  reviewedAt: true,
});

export const insertStorySchema = createInsertSchema(stories).omit({
  id: true,
  viewCount: true,
  isHighlight: true,
  createdAt: true,
});

export const insertStoryViewSchema = createInsertSchema(storyViews).omit({
  id: true,
  viewedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type ForumCategory = typeof forumCategories.$inferSelect;
export type InsertForumCategory = z.infer<typeof insertForumCategorySchema>;

export type ForumPost = typeof forumPosts.$inferSelect;
export type InsertForumPost = z.infer<typeof insertForumPostSchema>;

export type ForumReply = typeof forumReplies.$inferSelect;
export type InsertForumReply = z.infer<typeof insertForumReplySchema>;

export type ChatRoom = typeof chatRooms.$inferSelect;
export type InsertChatRoom = z.infer<typeof insertChatRoomSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

export type ChatReaction = typeof chatReactions.$inferSelect;
export type InsertChatReaction = z.infer<typeof insertChatReactionSchema>;

// Social Media Types
export type UserConnection = typeof userConnections.$inferSelect;
export type InsertUserConnection = z.infer<typeof insertUserConnectionSchema>;

export type SocialPost = typeof socialPosts.$inferSelect;
export type InsertSocialPost = z.infer<typeof insertSocialPostSchema>;

export type PostLike = typeof postLikes.$inferSelect;
export type InsertPostLike = z.infer<typeof insertPostLikeSchema>;

export type PostComment = typeof postComments.$inferSelect;
export type InsertPostComment = z.infer<typeof insertPostCommentSchema>;

export type UserSocialLink = typeof userSocialLinks.$inferSelect;
export type InsertUserSocialLink = z.infer<typeof insertUserSocialLinkSchema>;

// Social Media Extended Types
export type SocialPostWithAuthor = SocialPost & {
  author: User;
  isLiked?: boolean;
  userLikesCount?: number;
};

export type PostCommentWithAuthor = PostComment & {
  author: User;
  replies?: PostCommentWithAuthor[];
};

export type MarketplaceItem = typeof marketplaceItems.$inferSelect;
export type InsertMarketplaceItem = z.infer<typeof insertMarketplaceItemSchema>;

// New WoWonder-style types
export type PostReaction = typeof postReactions.$inferSelect;
export type InsertPostReaction = z.infer<typeof insertPostReactionSchema>;

export type Group = typeof groups.$inferSelect;
export type InsertGroup = z.infer<typeof insertGroupSchema>;

export type GroupMember = typeof groupMembers.$inferSelect;
export type InsertGroupMember = z.infer<typeof insertGroupMemberSchema>;

export type Page = typeof pages.$inferSelect;
export type InsertPage = z.infer<typeof insertPageSchema>;

export type PageFollower = typeof pageFollowers.$inferSelect;
export type InsertPageFollower = z.infer<typeof insertPageFollowerSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type VerificationRequest = typeof verificationRequests.$inferSelect;
export type InsertVerificationRequest = z.infer<typeof insertVerificationRequestSchema>;

export type Story = typeof stories.$inferSelect;
export type InsertStory = z.infer<typeof insertStorySchema>;

export type StoryView = typeof storyViews.$inferSelect;
export type InsertStoryView = z.infer<typeof insertStoryViewSchema>;

// Extended types for API responses
export type ForumPostWithAuthor = ForumPost & {
  author: User;
  category: ForumCategory;
};

export type ForumReplyWithAuthor = ForumReply & {
  author: User;
};

export type ChatMessageWithAuthor = ChatMessage & {
  author: User;
};

export type MarketplaceItemWithSeller = MarketplaceItem & {
  seller: User;
};

// WebSocket message schemas for type safety and validation
export const wsAuthMessageSchema = z.object({
  type: z.literal("auth"),
  token: z.string().min(1).max(2048), // JWT tokens
}).strict();

export const wsJoinRoomMessageSchema = z.object({
  type: z.literal("join_room"),
  roomId: z.string().min(1).max(100),
}).strict();

export const wsSendMessageSchema = z.object({
  type: z.literal("send_message"),
  content: z.string().min(1).max(1000), // Cap message length
}).strict();

export const wsPingMessageSchema = z.object({
  type: z.literal("ping"),
  timestamp: z.number().optional(),
}).strict();

export const wsPongMessageSchema = z.object({
  type: z.literal("pong"),
  timestamp: z.number().optional(),
}).strict();

// Reaction WebSocket message schemas
export const wsAddReactionSchema = z.object({
  type: z.literal("add_reaction"),
  messageId: z.string().min(1),
  emoji: z.string().min(1).max(10), // Unicode emoji
}).strict();

export const wsRemoveReactionSchema = z.object({
  type: z.literal("remove_reaction"),
  messageId: z.string().min(1),
  emoji: z.string().min(1).max(10), // Unicode emoji
}).strict();

// Client to server WebSocket messages
export const wsClientMessageSchema = z.discriminatedUnion("type", [
  wsAuthMessageSchema,
  wsJoinRoomMessageSchema,
  wsSendMessageSchema,
  wsPingMessageSchema,
  wsAddReactionSchema,
  wsRemoveReactionSchema,
]);

// Server to client WebSocket messages
export const wsServerMessageSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("auth_success"),
  }).strict(),
  z.object({
    type: z.literal("new_message"),
    message: z.object({
      id: z.string(),
      content: z.string(),
      roomId: z.string(),
      authorId: z.string(),
      createdAt: z.string(),
      author: z.object({
        id: z.string(),
        username: z.string(),
        type: z.enum(["guest", "user"]),
        createdAt: z.string(),
      }).strict(),
    }).strict(),
  }).strict(),
  z.object({
    type: z.literal("user_count_update"),
    count: z.number().int().min(0),
    roomId: z.string(),
  }).strict(),
  z.object({
    type: z.literal("error"),
    message: z.string(),
  }).strict(),
  z.object({
    type: z.literal("reaction_added"),
    messageId: z.string(),
    userId: z.string(),
    emoji: z.string(),
    username: z.string(),
  }).strict(),
  z.object({
    type: z.literal("reaction_removed"),
    messageId: z.string(),
    userId: z.string(),
    emoji: z.string(),
  }).strict(),
  wsPongMessageSchema,
]);

export type WSClientMessage = z.infer<typeof wsClientMessageSchema>;
export type WSServerMessage = z.infer<typeof wsServerMessageSchema>;
