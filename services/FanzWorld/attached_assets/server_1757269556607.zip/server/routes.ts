import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import jwt from "jsonwebtoken";
import { LRUCache } from "lru-cache";
import { storage } from "./storage";
import { insertForumPostSchema, insertForumReplySchema, insertChatMessageSchema, insertMarketplaceItemSchema, insertUserSchema, insertSocialPostSchema, wsClientMessageSchema, type WSClientMessage } from "@shared/schema";

const JWT_SECRET = process.env.JWT_SECRET || "fanzsocial-dev-super-secure-32-char-minimum-secret-key-for-development-only";

// Ensure minimum secret length for security
if (JWT_SECRET.length < 32) {
  throw new Error("JWT_SECRET must be at least 32 characters long");
}

// Warn about using default secret in production
if (!process.env.JWT_SECRET && process.env.NODE_ENV === "production") {
  throw new Error("JWT_SECRET environment variable is required in production");
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure express to trust proxy headers for accurate IP detection
  app.set('trust proxy', true);
  // User routes
  app.get("/api/users/online", async (req, res) => {
    try {
      const users = await storage.getOnlineUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch online users" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  // Advanced rate limiting with LRU cache and TTL
  const guestCreationAttempts = new LRUCache<string, { count: number; resetTime: number }>({
    max: 10000, // Maximum IPs to track
    ttl: 10 * 60 * 1000, // 10 minutes TTL
  });

  const userMessagingRateLimit = new LRUCache<string, { count: number; resetTime: number }>({
    max: 50000, // Maximum users to track  
    ttl: 10 * 60 * 1000, // 10 minutes TTL
  });

  // Per-IP connection tracking for WebSocket abuse prevention  
  // Use Map<IP, Set<WebSocket>> for authoritative connection tracking without TTL drift
  const connectionsByIP = new Map<string, Set<WebSocket>>();

  // Per-connection message rate limiting
  const connectionMessageLimit = new WeakMap<WebSocket, { 
    count: number; 
    resetTime: number; 
    violations: number; 
  }>();

  app.post("/api/users/guest", async (req, res) => {
    try {
      // Rate limiting per IP
      const clientIP = req.ip || req.connection.remoteAddress || "unknown";
      const now = Date.now();
      const rateLimitWindow = 60 * 1000; // 1 minute
      const maxAttempts = 3;

      const rateLimitData = guestCreationAttempts.get(clientIP);
      if (rateLimitData && now < rateLimitData.resetTime) {
        if (rateLimitData.count >= maxAttempts) {
          return res.status(429).json({ 
            error: "Too many guest account creation attempts. Please try again later." 
          });
        }
        rateLimitData.count++;
      } else {
        guestCreationAttempts.set(clientIP, { count: 1, resetTime: now + rateLimitWindow });
      }

      // Generate username with higher entropy to reduce collisions
      let guestUser;
      let usernameAttempts = 0;
      const maxUsernameAttempts = 10;
      
      while (usernameAttempts < maxUsernameAttempts) {
        const randomId = Math.random().toString(36).substring(2, 8).toUpperCase();
        const guestUsername = `Guest-${randomId}`;
        
        try {
          guestUser = await storage.createUser({
            username: guestUsername,
            email: `${guestUsername.toLowerCase()}@fanzsocial.guest`,
            isOnline: true
          });
          break;
        } catch (error) {
          // If user already exists, try again with new username
          usernameAttempts++;
          if (usernameAttempts >= maxUsernameAttempts) {
            return res.status(500).json({ error: "Unable to generate unique username" });
          }
        }
      }

      if (!guestUser) {
        return res.status(500).json({ error: "Failed to create guest user" });
      }

      // Generate JWT token for the user with proper claims
      const token = jwt.sign(
        { 
          sub: guestUser.id, 
          iss: "fanzsocial",
          aud: "ws",
          type: "guest" 
        },
        JWT_SECRET,
        { 
          expiresIn: "2h", // Reduced from 24h for better security
          algorithm: "HS256"
        }
      );

      res.json({ user: guestUser, token });
    } catch (error) {
      console.error("Error creating guest user:", error);
      res.status(500).json({ error: "Failed to create guest user" });
    }
  });

  // Forum routes
  app.get("/api/forum/categories", async (req, res) => {
    try {
      const categories = await storage.getForumCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.get("/api/forum/posts", async (req, res) => {
    try {
      const categoryId = req.query.categoryId as string;
      const posts = await storage.getForumPosts(categoryId);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch posts" });
    }
  });

  app.get("/api/forum/posts/:id", async (req, res) => {
    try {
      const post = await storage.getForumPost(req.params.id);
      if (!post) {
        return res.status(404).json({ error: "Post not found" });
      }
      // Increment view count
      await storage.incrementPostViewCount(req.params.id);
      res.json(post);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch post" });
    }
  });

  app.post("/api/forum/posts", async (req, res) => {
    try {
      const postData = insertForumPostSchema.parse(req.body);
      const post = await storage.createForumPost(postData);
      res.json(post);
    } catch (error) {
      res.status(400).json({ error: "Invalid post data" });
    }
  });

  app.post("/api/forum/posts/:id/like", async (req, res) => {
    try {
      await storage.likeForumPost(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to like post" });
    }
  });

  app.get("/api/forum/posts/:id/replies", async (req, res) => {
    try {
      const replies = await storage.getForumReplies(req.params.id);
      res.json(replies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch replies" });
    }
  });

  app.post("/api/forum/replies", async (req, res) => {
    try {
      const replyData = insertForumReplySchema.parse(req.body);
      const reply = await storage.createForumReply(replyData);
      res.json(reply);
    } catch (error) {
      res.status(400).json({ error: "Invalid reply data" });
    }
  });

  // Chat routes
  app.get("/api/chat/rooms", async (req, res) => {
    try {
      const rooms = await storage.getChatRooms();
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch chat rooms" });
    }
  });

  app.get("/api/chat/rooms/:id/messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages(req.params.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // Marketplace routes
  app.get("/api/marketplace/items", async (req, res) => {
    try {
      const category = req.query.category as string;
      const items = await storage.getMarketplaceItems(category);
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch marketplace items" });
    }
  });

  app.get("/api/marketplace/items/:id", async (req, res) => {
    try {
      const item = await storage.getMarketplaceItem(req.params.id);
      if (!item) {
        return res.status(404).json({ error: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch item" });
    }
  });

  app.post("/api/marketplace/items", async (req, res) => {
    try {
      const itemData = insertMarketplaceItemSchema.parse(req.body);
      const item = await storage.createMarketplaceItem(itemData);
      res.json(item);
    } catch (error) {
      res.status(400).json({ error: "Invalid item data" });
    }
  });

  app.post("/api/marketplace/items/:id/sold", async (req, res) => {
    try {
      await storage.markItemAsSold(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark item as sold" });
    }
  });

  // Search route
  app.get("/api/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Query parameter required" });
      }
      const results = await storage.searchAll(query);
      res.json(results);
    } catch (error) {
      res.status(500).json({ error: "Search failed" });
    }
  });

  // Social Media API Routes
  
  // Get social media news feed
  app.get("/api/social/feed", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const limit = parseInt(req.query.limit as string) || 20;
      const posts = await storage.getSocialPosts(userId, limit);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch social feed" });
    }
  });

  // Create a new social post
  app.post("/api/social/posts", async (req, res) => {
    try {
      const postData = insertSocialPostSchema.parse(req.body);
      const post = await storage.createSocialPost(postData);
      res.json(post);
    } catch (error) {
      res.status(400).json({ error: "Invalid post data" });
    }
  });

  // Like/unlike a post
  app.post("/api/social/posts/:postId/like", async (req, res) => {
    try {
      const { postId } = req.params;
      const { userId } = req.body;
      const success = await storage.likePost(postId, userId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ error: "Failed to like post" });
    }
  });

  app.delete("/api/social/posts/:postId/like", async (req, res) => {
    try {
      const { postId } = req.params;
      const { userId } = req.body;
      const success = await storage.unlikePost(postId, userId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ error: "Failed to unlike post" });
    }
  });

  // Follow/unfollow users
  app.post("/api/social/users/:userId/follow", async (req, res) => {
    try {
      const { userId: followingId } = req.params;
      const { followerId } = req.body;
      const success = await storage.followUser(followerId, followingId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ error: "Failed to follow user" });
    }
  });

  app.delete("/api/social/users/:userId/follow", async (req, res) => {
    try {
      const { userId: followingId } = req.params;
      const { followerId } = req.body;
      const success = await storage.unfollowUser(followerId, followingId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ error: "Failed to unfollow user" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup for real-time chat
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const roomConnections = new Map<string, Set<WebSocket>>();
  const connectionUsers = new Map<WebSocket, string>(); // Map WebSocket to userId
  const userPresence = new Map<string, boolean>(); // Track online status
  // Rate limiting now handled by userMessagingRateLimit LRU cache above

  // Helper function to extract client IP from WebSocket request
  const extractClientIP = (req: any): string => {
    // For security, prefer socket IP unless behind known trusted proxy
    const socketIP = req.socket?.remoteAddress;
    
    // Only trust forwarded headers in development or from localhost/known proxies
    const isDev = process.env.NODE_ENV !== 'production';
    const isLocalProxy = socketIP === '127.0.0.1' || socketIP === '::1';
    
    if (isDev || isLocalProxy) {
      const xff = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim();
      const cf = req.headers['cf-connecting-ip'] as string;
      return xff || cf || socketIP || 'unknown';
    }
    
    return socketIP || 'unknown';
  };

  wss.on("connection", (ws: WebSocket, req) => {
    console.log("New WebSocket connection");
    
    // Extract client IP and enforce per-IP connection limits
    const clientIP = extractClientIP(req);
    const connectionSet = connectionsByIP.get(clientIP) || new Set<WebSocket>();
    const maxConnectionsPerIP = 10;
    
    if (connectionSet.size >= maxConnectionsPerIP) {
      console.warn(`Connection limit exceeded for IP: ${clientIP}`);
      ws.close(1008, "Too many connections from this IP");
      return;
    }
    
    // Add this connection to the set
    connectionSet.add(ws);
    connectionsByIP.set(clientIP, connectionSet);
    
    let currentRoom: string | null = null;
    let userId: string | null = null;
    
    // Initialize per-connection rate limiting
    connectionMessageLimit.set(ws, {
      count: 0,
      resetTime: Date.now() + 2000, // 2 second window
      violations: 0
    });

    // Enhanced WebSocket with message queue protection
    const messageQueue: any[] = [];
    const maxQueueSize = 100;

    const safeSend = (message: any) => {
      if (ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(JSON.stringify(message));
        } catch (error) {
          console.error("Failed to send WebSocket message:", error);
        }
      } else {
        // Queue message if connection is not open, but limit queue size
        if (messageQueue.length < maxQueueSize) {
          messageQueue.push(message);
        } else {
          console.warn("WebSocket message queue overflow, dropping oldest message");
          messageQueue.shift();
          messageQueue.push(message);
        }
      }
    };

    ws.on("message", async (data) => {
      // Per-connection rate limiting - check all messages before processing
      const connectionLimit = connectionMessageLimit.get(ws);
      if (connectionLimit) {
        const now = Date.now();
        if (now < connectionLimit.resetTime) {
          connectionLimit.count++;
          if (connectionLimit.count > 20) { // Max 20 messages per 2 seconds
            connectionLimit.violations++;
            if (connectionLimit.violations > 3) {
              console.warn(`Connection rate limit violations exceeded, terminating connection from IP: ${clientIP}`);
              ws.close(1008, "Rate limit exceeded");
              return;
            }
            // Drop message but don't disconnect yet
            console.warn(`Rate limit exceeded for connection from IP: ${clientIP}`);
            return;
          }
        } else {
          // Reset window
          connectionLimit.count = 1;
          connectionLimit.resetTime = now + 2000;
        }
      }
      
      // Message size limit before JSON parsing (handle different data types)
      let dataSize: number;
      if (typeof data === 'string') {
        dataSize = Buffer.byteLength(data, 'utf8');
      } else if (Buffer.isBuffer(data)) {
        dataSize = data.length;
      } else if (data instanceof ArrayBuffer) {
        dataSize = data.byteLength;
      } else {
        dataSize = data.toString().length;
      }
      
      if (dataSize > 16384) { // 16KB limit
        console.warn(`Message size exceeded from IP: ${clientIP}`);
        ws.close(1009, "Message too large");
        return;
      }
      try {
        const rawMessage = JSON.parse(data.toString());
        
        // Validate message against schema
        const validation = wsClientMessageSchema.safeParse(rawMessage);
        if (!validation.success) {
          console.error("Invalid WebSocket message:", validation.error);
          ws.send(JSON.stringify({
            type: "error",
            message: "Invalid message format"
          }));
          return;
        }

        const message: WSClientMessage = validation.data;
        
        switch (message.type) {
          case "auth":
            // Authenticate user connection with JWT token
            if (message.token) {
              try {
                const decoded = jwt.verify(message.token, JWT_SECRET, {
                  algorithms: ["HS256"],
                  issuer: "fanzsocial",
                  audience: "ws"
                }) as any;
                const user = await storage.getUser(decoded.sub);
                
                if (user) {
                  userId = user.id;
                  connectionUsers.set(ws, userId);
                  userPresence.set(userId, true);
                  await storage.updateUserOnlineStatus(userId, true);
                  
                  safeSend({ type: "auth_success" });
                  console.log(`User ${user.username} authenticated on WebSocket with token`);
                } else {
                  safeSend({ type: "error", message: "Invalid user in token" });
                }
              } catch (error) {
                console.error("JWT verification failed:", error);
                safeSend({ type: "error", message: "Invalid or expired token" });
              }
            } else {
              safeSend({ type: "error", message: "Authentication token required" });
            }
            break;

          case "ping":
            // Respond to heartbeat ping
            safeSend({ type: "pong", timestamp: Date.now() });
            break;

          case "join_room":
            if (!userId) {
              safeSend({ type: "error", message: "Authentication required" });
              break;
            }

            // Validate room exists
            const roomExists = await storage.getChatRoom(message.roomId);
            if (!roomExists) {
              safeSend({ type: "error", message: "Room not found" });
              break;
            }

            // Leave current room if any
            if (currentRoom && roomConnections.has(currentRoom)) {
              roomConnections.get(currentRoom)!.delete(ws);
              await updateRoomUserCount(currentRoom);
            }
            
            // Join new room
            currentRoom = message.roomId;
            if (currentRoom) {
              if (!roomConnections.has(currentRoom)) {
                roomConnections.set(currentRoom, new Set());
              }
              roomConnections.get(currentRoom)!.add(ws);
              await updateRoomUserCount(currentRoom);
              
              // Send room user count update
              broadcastToRoom(currentRoom, {
                type: "user_count_update",
                count: roomConnections.get(currentRoom)!.size,
                roomId: currentRoom
              });
            }
            break;

          case "send_message":
            if (!userId) {
              safeSend({ type: "error", message: "Authentication required" });
              break;
            }

            if (!currentRoom) {
              safeSend({ type: "error", message: "Must join a room first" });
              break;
            }

            // Rate limiting per user
            const now = Date.now();
            const rateLimitWindow = 5000; // 5 seconds
            const maxMessages = 5;
            
            const userRateLimit = userMessagingRateLimit.get(userId);
            if (userRateLimit && now < userRateLimit.resetTime) {
              if (userRateLimit.count >= maxMessages) {
                safeSend({ 
                  type: "error", 
                  message: "Rate limit exceeded. Please slow down." 
                });
                break;
              }
              userRateLimit.count++;
            } else {
              userMessagingRateLimit.set(userId, { count: 1, resetTime: now + rateLimitWindow });
            }

            try {
              // Validate message content
              if (!message.content || message.content.trim().length === 0) {
                safeSend({ type: "error", message: "Message content cannot be empty" });
                break;
              }

              if (message.content.length > 1000) {
                safeSend({ 
                  type: "error", 
                  message: "Message too long. Maximum 1000 characters." 
                });
                break;
              }

              // Use authenticated userId instead of client-provided authorId
              const chatMessage = await storage.createChatMessage({
                content: message.content.trim(),
                authorId: userId, // Use authenticated user ID
                roomId: currentRoom
              });

              // Get user info and broadcast
              const user = await storage.getUser(userId);
              if (user) {
                // Format message to match schema
                const formattedMessage = {
                  id: chatMessage.id,
                  content: chatMessage.content,
                  roomId: chatMessage.roomId,
                  authorId: chatMessage.authorId,
                  createdAt: chatMessage.createdAt instanceof Date ? chatMessage.createdAt.toISOString() : chatMessage.createdAt,
                  author: {
                    id: user.id,
                    username: user.username,
                    type: "guest" as const, // All current users are guests
                    createdAt: user.createdAt instanceof Date ? user.createdAt.toISOString() : user.createdAt
                  }
                };
                
                broadcastToRoom(currentRoom, {
                  type: "new_message",
                  message: formattedMessage
                });
              }
            } catch (error) {
              console.error("Error sending message:", error);
              safeSend({ type: "error", message: "Failed to send message" });
            }
            break;

          default:
            safeSend({ type: "error", message: "Unknown message type" });
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
        safeSend({ type: "error", message: "Invalid message format" });
      }
    });

    ws.on("close", async () => {
      // Clean up connection tracking
      const connectionSet = connectionsByIP.get(clientIP);
      if (connectionSet) {
        connectionSet.delete(ws);
        if (connectionSet.size === 0) {
          connectionsByIP.delete(clientIP);
        }
      }
      
      // Clean up per-connection rate limiting
      connectionMessageLimit.delete(ws);
      // Clean up room connections
      if (currentRoom && roomConnections.has(currentRoom)) {
        roomConnections.get(currentRoom)!.delete(ws);
        await updateRoomUserCount(currentRoom);
        
        if (roomConnections.get(currentRoom)!.size === 0) {
          roomConnections.delete(currentRoom);
        } else {
          broadcastToRoom(currentRoom, {
            type: "user_count_update",
            count: roomConnections.get(currentRoom)!.size,
            roomId: currentRoom
          });
        }
      }

      // Clean up user connection tracking
      if (userId) {
        connectionUsers.delete(ws);
        
        // Check if user has any other active connections
        const hasOtherConnections = Array.from(connectionUsers.values()).includes(userId);
        if (!hasOtherConnections) {
          // User is completely offline
          userPresence.set(userId, false);
          await storage.updateUserOnlineStatus(userId, false);
          console.log(`User ${userId} went offline`);
        }
      }
    });
  });

  function broadcastToRoom(roomId: string, message: any) {
    const connections = roomConnections.get(roomId);
    if (connections) {
      // Pre-stringify message once for efficiency
      const messageStr = JSON.stringify(message);
      const deadConnections = new Set<WebSocket>();
      
      connections.forEach(ws => {
        try {
          // Check if connection is ready and not overwhelmed
          if (ws.readyState === WebSocket.OPEN) {
            // Check backpressure - if buffer is too full, skip or close
            if (ws.bufferedAmount > 1024 * 1024) { // 1MB threshold
              console.warn("WebSocket buffer overwhelmed, closing connection");
              ws.close(1009, "Buffer overflow");
              deadConnections.add(ws);
              return;
            }
            
            ws.send(messageStr);
          } else {
            // Connection is not open, mark for removal
            deadConnections.add(ws);
          }
        } catch (error) {
          console.error("Error broadcasting to WebSocket:", error);
          deadConnections.add(ws);
        }
      });
      
      // Clean up dead connections
      deadConnections.forEach(ws => {
        connections.delete(ws);
        connectionUsers.delete(ws);
      });
      
      // Remove empty room
      if (connections.size === 0) {
        roomConnections.delete(roomId);
      }
    }
  }

  async function updateRoomUserCount(roomId: string) {
    const count = roomConnections.get(roomId)?.size || 0;
    await storage.updateRoomUserCount(roomId, count);
  }

  return httpServer;
}
