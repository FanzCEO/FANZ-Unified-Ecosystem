import { 
  type User, type InsertUser,
  type ForumCategory, type InsertForumCategory,
  type ForumPost, type InsertForumPost, type ForumPostWithAuthor,
  type ForumReply, type InsertForumReply, type ForumReplyWithAuthor,
  type ChatRoom, type InsertChatRoom,
  type ChatMessage, type InsertChatMessage, type ChatMessageWithAuthor,
  type ChatReaction, type InsertChatReaction,
  type MarketplaceItem, type InsertMarketplaceItem, type MarketplaceItemWithSeller,
  type SocialPost, type InsertSocialPost, type SocialPostWithAuthor,
  type UserConnection, type InsertUserConnection,
  type PostLike, type InsertPostLike,
  type PostComment, type InsertPostComment, type PostCommentWithAuthor,
  type UserSocialLink, type InsertUserSocialLink
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserOnlineStatus(id: string, isOnline: boolean): Promise<void>;
  getOnlineUsers(): Promise<User[]>;

  // Forum Categories
  getForumCategories(): Promise<ForumCategory[]>;
  createForumCategory(category: InsertForumCategory): Promise<ForumCategory>;

  // Forum Posts
  getForumPosts(categoryId?: string): Promise<ForumPostWithAuthor[]>;
  getForumPost(id: string): Promise<ForumPostWithAuthor | undefined>;
  createForumPost(post: InsertForumPost): Promise<ForumPost>;
  incrementPostViewCount(id: string): Promise<void>;
  likeForumPost(id: string): Promise<void>;

  // Forum Replies
  getForumReplies(postId: string): Promise<ForumReplyWithAuthor[]>;
  createForumReply(reply: InsertForumReply): Promise<ForumReply>;

  // Chat Rooms
  getChatRooms(): Promise<ChatRoom[]>;
  getChatRoom(id: string): Promise<ChatRoom | undefined>;
  createChatRoom(room: InsertChatRoom): Promise<ChatRoom>;
  updateRoomUserCount(id: string, count: number): Promise<void>;

  // Chat Messages
  getChatMessages(roomId: string, limit?: number): Promise<ChatMessageWithAuthor[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // Chat Reactions
  getMessageReactions(messageId: string): Promise<ChatReaction[]>;
  addReaction(reaction: InsertChatReaction): Promise<ChatReaction>;
  removeReaction(messageId: string, userId: string, emoji: string): Promise<boolean>;

  // Social Media Features
  // Social Posts (News Feed)
  getSocialPosts(userId?: string, limit?: number): Promise<SocialPostWithAuthor[]>;
  getUserPosts(userId: string, limit?: number): Promise<SocialPostWithAuthor[]>;
  createSocialPost(post: InsertSocialPost): Promise<SocialPost>;
  deleteSocialPost(postId: string, userId: string): Promise<boolean>;
  
  // Post Interactions
  likePost(postId: string, userId: string): Promise<boolean>;
  unlikePost(postId: string, userId: string): Promise<boolean>;
  addPostComment(comment: InsertPostComment): Promise<PostComment>;
  getPostComments(postId: string): Promise<PostCommentWithAuthor[]>;
  
  // User Connections
  followUser(followerId: string, followingId: string): Promise<boolean>;
  unfollowUser(followerId: string, followingId: string): Promise<boolean>;
  getFollowers(userId: string): Promise<User[]>;
  getFollowing(userId: string): Promise<User[]>;
  isFollowing(followerId: string, followingId: string): Promise<boolean>;
  
  // Social Links
  getUserSocialLinks(userId: string): Promise<UserSocialLink[]>;
  addSocialLink(link: InsertUserSocialLink): Promise<UserSocialLink>;
  removeSocialLink(linkId: string, userId: string): Promise<boolean>;

  // Marketplace
  getMarketplaceItems(category?: string): Promise<MarketplaceItemWithSeller[]>;
  getMarketplaceItem(id: string): Promise<MarketplaceItemWithSeller | undefined>;
  createMarketplaceItem(item: InsertMarketplaceItem): Promise<MarketplaceItem>;
  markItemAsSold(id: string): Promise<void>;

  // Search
  searchAll(query: string): Promise<{
    posts: ForumPostWithAuthor[];
    items: MarketplaceItemWithSeller[];
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private forumCategories: Map<string, ForumCategory>;
  private forumPosts: Map<string, ForumPost>;
  private forumReplies: Map<string, ForumReply>;
  private chatRooms: Map<string, ChatRoom>;
  private chatMessages: Map<string, ChatMessage>;
  private chatReactions: Map<string, ChatReaction>;
  private marketplaceItems: Map<string, MarketplaceItem>;
  // Social Media Storage
  private socialPosts: Map<string, SocialPost>;
  private userConnections: Map<string, UserConnection>;
  private postLikes: Map<string, PostLike>;
  private postComments: Map<string, PostComment>;
  private userSocialLinks: Map<string, UserSocialLink>;

  constructor() {
    this.users = new Map();
    this.forumCategories = new Map();
    this.forumPosts = new Map();
    this.forumReplies = new Map();
    this.chatRooms = new Map();
    this.chatMessages = new Map();
    this.chatReactions = new Map();
    this.marketplaceItems = new Map();
    // Initialize social media storage
    this.socialPosts = new Map();
    this.userConnections = new Map();
    this.postLikes = new Map();
    this.postComments = new Map();
    this.userSocialLinks = new Map();

    this.initializeDefaultData();
  }

  private async initializeDefaultData() {
    // Create default categories
    const categories = [
      { name: "General Discussion", description: "General community discussions", icon: "fas fa-fire" },
      { name: "Ideas & Feedback", description: "Share your ideas and feedback", icon: "fas fa-lightbulb" },
      { name: "Help & Support", description: "Get help from the community", icon: "fas fa-question-circle" },
      { name: "Announcements", description: "Official announcements", icon: "fas fa-star" }
    ];

    for (const cat of categories) {
      await this.createForumCategory(cat);
    }

    // Create default chat rooms
    const rooms = [
      { name: "General", description: "General chat room" },
      { name: "Gaming", description: "Gaming discussions" },
      { name: "Creative", description: "Creative projects and art" },
      { name: "Marketplace", description: "Buy and sell discussions" }
    ];

    for (const room of rooms) {
      await this.createChatRoom(room);
    }

    // Create a demo user
    const demoUser = await this.createUser({
      username: "DemoUser",
      email: "demo@fanzsocial.com",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
      isOnline: true
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser,
      id,
      avatar: insertUser.avatar || null,
      isOnline: insertUser.isOnline || false,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      bio: insertUser.bio || null,
      website: insertUser.website || null,
      location: insertUser.location || null,
      coverImage: insertUser.coverImage || null,
      followersCount: insertUser.followersCount || 0,
      followingCount: insertUser.followingCount || 0,
      postsCount: insertUser.postsCount || 0,
      createdAt: new Date(),
      lastSeen: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserOnlineStatus(id: string, isOnline: boolean): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      user.isOnline = isOnline;
      user.lastSeen = new Date();
    }
  }

  async getOnlineUsers(): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => user.isOnline);
  }

  async getForumCategories(): Promise<ForumCategory[]> {
    return Array.from(this.forumCategories.values());
  }

  async createForumCategory(category: InsertForumCategory): Promise<ForumCategory> {
    const id = randomUUID();
    const newCategory: ForumCategory = { 
      ...category, 
      id, 
      description: category.description || null,
      postCount: 0 
    };
    this.forumCategories.set(id, newCategory);
    return newCategory;
  }

  async getForumPosts(categoryId?: string): Promise<ForumPostWithAuthor[]> {
    const posts = Array.from(this.forumPosts.values())
      .filter(post => !categoryId || post.categoryId === categoryId)
      .sort((a, b) => new Date(b.updatedAt!).getTime() - new Date(a.updatedAt!).getTime());

    return posts.map(post => ({
      ...post,
      author: this.users.get(post.authorId)!,
      category: this.forumCategories.get(post.categoryId)!
    }));
  }

  async getForumPost(id: string): Promise<ForumPostWithAuthor | undefined> {
    const post = this.forumPosts.get(id);
    if (!post) return undefined;

    return {
      ...post,
      author: this.users.get(post.authorId)!,
      category: this.forumCategories.get(post.categoryId)!
    };
  }

  async createForumPost(insertPost: InsertForumPost): Promise<ForumPost> {
    const id = randomUUID();
    const post: ForumPost = {
      ...insertPost,
      id,
      replyCount: 0,
      viewCount: 0,
      likeCount: 0,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.forumPosts.set(id, post);

    // Update category post count
    const category = this.forumCategories.get(insertPost.categoryId);
    if (category) {
      category.postCount = (category.postCount || 0) + 1;
    }

    return post;
  }

  async incrementPostViewCount(id: string): Promise<void> {
    const post = this.forumPosts.get(id);
    if (post) {
      post.viewCount = (post.viewCount || 0) + 1;
    }
  }

  async likeForumPost(id: string): Promise<void> {
    const post = this.forumPosts.get(id);
    if (post) {
      post.likeCount = (post.likeCount || 0) + 1;
    }
  }

  async getForumReplies(postId: string): Promise<ForumReplyWithAuthor[]> {
    const replies = Array.from(this.forumReplies.values())
      .filter(reply => reply.postId === postId)
      .sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());

    return replies.map(reply => ({
      ...reply,
      author: this.users.get(reply.authorId)!
    }));
  }

  async createForumReply(insertReply: InsertForumReply): Promise<ForumReply> {
    const id = randomUUID();
    const reply: ForumReply = {
      ...insertReply,
      id,
      createdAt: new Date()
    };
    this.forumReplies.set(id, reply);

    // Update post reply count
    const post = this.forumPosts.get(insertReply.postId);
    if (post) {
      post.replyCount = (post.replyCount || 0) + 1;
    }

    return reply;
  }

  async getChatRooms(): Promise<ChatRoom[]> {
    return Array.from(this.chatRooms.values());
  }

  async getChatRoom(id: string): Promise<ChatRoom | undefined> {
    return this.chatRooms.get(id);
  }

  async createChatRoom(insertRoom: InsertChatRoom): Promise<ChatRoom> {
    const id = randomUUID();
    const room: ChatRoom = { 
      ...insertRoom, 
      id, 
      description: insertRoom.description || null,
      userCount: 0 
    };
    this.chatRooms.set(id, room);
    return room;
  }

  async updateRoomUserCount(id: string, count: number): Promise<void> {
    const room = this.chatRooms.get(id);
    if (room) {
      room.userCount = count;
    }
  }

  async getChatMessages(roomId: string, limit: number = 50): Promise<ChatMessageWithAuthor[]> {
    const messages = Array.from(this.chatMessages.values())
      .filter(message => message.roomId === roomId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(0, limit)
      .reverse();

    return messages.map(message => ({
      ...message,
      author: this.users.get(message.authorId)!
    }));
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = {
      ...insertMessage,
      id,
      createdAt: new Date()
    };
    this.chatMessages.set(id, message);
    return message;
  }

  async getMarketplaceItems(category?: string): Promise<MarketplaceItemWithSeller[]> {
    const items = Array.from(this.marketplaceItems.values())
      .filter(item => !item.isSold && (!category || item.category === category))
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());

    return items.map(item => ({
      ...item,
      seller: this.users.get(item.sellerId)!
    }));
  }

  async getMarketplaceItem(id: string): Promise<MarketplaceItemWithSeller | undefined> {
    const item = this.marketplaceItems.get(id);
    if (!item) return undefined;

    return {
      ...item,
      seller: this.users.get(item.sellerId)!
    };
  }

  async createMarketplaceItem(insertItem: InsertMarketplaceItem): Promise<MarketplaceItem> {
    const id = randomUUID();
    const item: MarketplaceItem = {
      ...insertItem,
      id,
      image: insertItem.image || null,
      isSold: false,
      createdAt: new Date()
    };
    this.marketplaceItems.set(id, item);
    return item;
  }

  async markItemAsSold(id: string): Promise<void> {
    const item = this.marketplaceItems.get(id);
    if (item) {
      item.isSold = true;
    }
  }

  async searchAll(query: string): Promise<{
    posts: ForumPostWithAuthor[];
    items: MarketplaceItemWithSeller[];
  }> {
    const lowercaseQuery = query.toLowerCase();

    const posts = (await this.getForumPosts()).filter(post =>
      post.title.toLowerCase().includes(lowercaseQuery) ||
      post.content.toLowerCase().includes(lowercaseQuery)
    );

    const items = (await this.getMarketplaceItems()).filter(item =>
      item.title.toLowerCase().includes(lowercaseQuery) ||
      item.description.toLowerCase().includes(lowercaseQuery)
    );

    return { posts, items };
  }

  // Chat Reactions Implementation
  async getMessageReactions(messageId: string): Promise<ChatReaction[]> {
    return Array.from(this.chatReactions.values())
      .filter(reaction => reaction.messageId === messageId)
      .sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());
  }

  async addReaction(reaction: InsertChatReaction): Promise<ChatReaction> {
    const id = randomUUID();
    const newReaction: ChatReaction = {
      id,
      messageId: reaction.messageId,
      userId: reaction.userId,
      emoji: reaction.emoji,
      createdAt: new Date()
    };

    // Remove existing reaction from this user for this message with same emoji
    const existingKey = Array.from(this.chatReactions.entries())
      .find(([_, r]) => 
        r.messageId === reaction.messageId && 
        r.userId === reaction.userId && 
        r.emoji === reaction.emoji
      )?.[0];
    
    if (existingKey) {
      this.chatReactions.delete(existingKey);
    }

    this.chatReactions.set(id, newReaction);
    return newReaction;
  }

  async removeReaction(messageId: string, userId: string, emoji: string): Promise<boolean> {
    const existingKey = Array.from(this.chatReactions.entries())
      .find(([_, r]) => 
        r.messageId === messageId && 
        r.userId === userId && 
        r.emoji === emoji
      )?.[0];

    if (existingKey) {
      this.chatReactions.delete(existingKey);
      return true;
    }
    return false;
  }

  // Social Media Storage Implementation
  
  // News Feed / Social Posts
  async getSocialPosts(userId?: string, limit: number = 20): Promise<SocialPostWithAuthor[]> {
    let posts = Array.from(this.socialPosts.values());
    
    // For demo purposes, show all public posts and user's own posts
    if (userId) {
      const connections = Array.from(this.userConnections.values())
        .filter(conn => conn.followerId === userId)
        .map(conn => conn.followingId);
      
      posts = posts.filter(post => {
        // Show public posts, user's own posts, and posts from followed users
        if (post.privacy === "public") return true;
        if (post.authorId === userId) return true; // User's own posts
        if (post.privacy === "friends" && connections.includes(post.authorId)) return true;
        return false;
      });
    } else {
      // Public posts only for non-authenticated users
      posts = posts.filter(post => post.privacy === "public");
    }
    
    posts.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
    posts = posts.slice(0, limit);
    
    // Add author information
    const postsWithAuthor: SocialPostWithAuthor[] = [];
    for (const post of posts) {
      const author = this.users.get(post.authorId);
      if (author) {
        const isLiked = userId ? Array.from(this.postLikes.values())
          .some(like => like.postId === post.id && like.userId === userId) : false;
        
        postsWithAuthor.push({
          ...post,
          author,
          isLiked,
        });
      }
    }
    
    return postsWithAuthor;
  }

  async getUserPosts(userId: string, limit: number = 20): Promise<SocialPostWithAuthor[]> {
    const posts = Array.from(this.socialPosts.values())
      .filter(post => post.authorId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(0, limit);
    
    const author = this.users.get(userId);
    if (!author) return [];
    
    return posts.map(post => ({
      ...post,
      author,
      isLiked: false, // User viewing own posts
    }));
  }

  async createSocialPost(post: InsertSocialPost): Promise<SocialPost> {
    const id = randomUUID();
    const newPost: SocialPost = {
      id,
      authorId: post.authorId,
      content: post.content,
      imageUrl: post.imageUrl || null,
      videoUrl: post.videoUrl || null,
      linkUrl: post.linkUrl || null,
      linkTitle: post.linkTitle || null,
      linkDescription: post.linkDescription || null,
      postType: post.postType || "text",
      privacy: post.privacy || "public",
      isStory: post.isStory || false,
      storyExpiresAt: post.storyExpiresAt || null,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      reactionsCount: 0,
      viewsCount: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.socialPosts.set(id, newPost);
    
    // Update user's posts count
    const user = this.users.get(post.authorId);
    if (user && user.postsCount !== null) {
      user.postsCount = (user.postsCount || 0) + 1;
    }
    
    return newPost;
  }

  async deleteSocialPost(postId: string, userId: string): Promise<boolean> {
    const post = this.socialPosts.get(postId);
    if (post && post.authorId === userId) {
      this.socialPosts.delete(postId);
      
      // Update user's posts count
      const user = this.users.get(userId);
      if (user && user.postsCount !== null && user.postsCount > 0) {
        user.postsCount = user.postsCount - 1;
      }
      
      return true;
    }
    return false;
  }

  // Post Interactions
  async likePost(postId: string, userId: string): Promise<boolean> {
    const post = this.socialPosts.get(postId);
    if (!post) return false;
    
    // Check if already liked
    const existingLike = Array.from(this.postLikes.values())
      .find(like => like.postId === postId && like.userId === userId);
    
    if (existingLike) return false;
    
    const likeId = randomUUID();
    const newLike: PostLike = {
      id: likeId,
      postId,
      userId,
      createdAt: new Date(),
    };
    
    this.postLikes.set(likeId, newLike);
    post.likesCount = (post.likesCount || 0) + 1;
    
    return true;
  }

  async unlikePost(postId: string, userId: string): Promise<boolean> {
    const post = this.socialPosts.get(postId);
    if (!post) return false;
    
    const existingLike = Array.from(this.postLikes.entries())
      .find(([_, like]) => like.postId === postId && like.userId === userId);
    
    if (existingLike) {
      this.postLikes.delete(existingLike[0]);
      post.likesCount = Math.max((post.likesCount || 0) - 1, 0);
      return true;
    }
    
    return false;
  }

  async addPostComment(comment: InsertPostComment): Promise<PostComment> {
    const id = randomUUID();
    const newComment: PostComment = {
      id,
      postId: comment.postId,
      authorId: comment.authorId,
      content: comment.content,
      parentId: comment.parentId || null,
      createdAt: new Date(),
    };
    
    this.postComments.set(id, newComment);
    
    // Update post comments count
    const post = this.socialPosts.get(comment.postId);
    if (post) {
      post.commentsCount = (post.commentsCount || 0) + 1;
    }
    
    return newComment;
  }

  async getPostComments(postId: string): Promise<PostCommentWithAuthor[]> {
    const comments = Array.from(this.postComments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());
    
    const commentsWithAuthor: PostCommentWithAuthor[] = [];
    for (const comment of comments) {
      const author = this.users.get(comment.authorId);
      if (author) {
        commentsWithAuthor.push({
          ...comment,
          author,
          replies: [], // TODO: Implement nested replies if needed
        });
      }
    }
    
    return commentsWithAuthor;
  }

  // User Connections
  async followUser(followerId: string, followingId: string): Promise<boolean> {
    if (followerId === followingId) return false;
    
    // Check if already following
    const existingConnection = Array.from(this.userConnections.values())
      .find(conn => conn.followerId === followerId && conn.followingId === followingId);
    
    if (existingConnection) return false;
    
    const id = randomUUID();
    const newConnection: UserConnection = {
      id,
      followerId,
      followingId,
      createdAt: new Date(),
    };
    
    this.userConnections.set(id, newConnection);
    
    // Update follow counts
    const follower = this.users.get(followerId);
    const following = this.users.get(followingId);
    
    if (follower && follower.followingCount !== null) {
      follower.followingCount = (follower.followingCount || 0) + 1;
    }
    if (following && following.followersCount !== null) {
      following.followersCount = (following.followersCount || 0) + 1;
    }
    
    return true;
  }

  async unfollowUser(followerId: string, followingId: string): Promise<boolean> {
    const existingConnection = Array.from(this.userConnections.entries())
      .find(([_, conn]) => conn.followerId === followerId && conn.followingId === followingId);
    
    if (existingConnection) {
      this.userConnections.delete(existingConnection[0]);
      
      // Update follow counts
      const follower = this.users.get(followerId);
      const following = this.users.get(followingId);
      
      if (follower && follower.followingCount !== null && follower.followingCount > 0) {
        follower.followingCount = follower.followingCount - 1;
      }
      if (following && following.followersCount !== null && following.followersCount > 0) {
        following.followersCount = following.followersCount - 1;
      }
      
      return true;
    }
    
    return false;
  }

  async getFollowers(userId: string): Promise<User[]> {
    const followerIds = Array.from(this.userConnections.values())
      .filter(conn => conn.followingId === userId)
      .map(conn => conn.followerId);
    
    return followerIds.map(id => this.users.get(id)!).filter(Boolean);
  }

  async getFollowing(userId: string): Promise<User[]> {
    const followingIds = Array.from(this.userConnections.values())
      .filter(conn => conn.followerId === userId)
      .map(conn => conn.followingId);
    
    return followingIds.map(id => this.users.get(id)!).filter(Boolean);
  }

  async isFollowing(followerId: string, followingId: string): Promise<boolean> {
    return Array.from(this.userConnections.values())
      .some(conn => conn.followerId === followerId && conn.followingId === followingId);
  }

  // Social Links
  async getUserSocialLinks(userId: string): Promise<UserSocialLink[]> {
    return Array.from(this.userSocialLinks.values())
      .filter(link => link.userId === userId)
      .sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());
  }

  async addSocialLink(link: InsertUserSocialLink): Promise<UserSocialLink> {
    const id = randomUUID();
    const newLink: UserSocialLink = {
      id,
      userId: link.userId,
      platform: link.platform,
      url: link.url,
      username: link.username || null,
      createdAt: new Date(),
    };
    
    this.userSocialLinks.set(id, newLink);
    return newLink;
  }

  async removeSocialLink(linkId: string, userId: string): Promise<boolean> {
    const link = this.userSocialLinks.get(linkId);
    if (link && link.userId === userId) {
      this.userSocialLinks.delete(linkId);
      return true;
    }
    return false;
  }
}

export const storage = new MemStorage();
